import { loadEnvConfig } from "@next/env";
import { randomUUID, randomBytes } from "node:crypto";
import { eq, inArray } from "drizzle-orm";

loadEnvConfig(process.cwd(), process.env.NODE_ENV !== "production");

function redact(text: string) {
  for (const key of ["GEMINI_API_KEY", "GROQ_API_KEY", "TAVILY_API_KEY", "AUTH_SECRET", "DATABASE_URL"]) {
    if (process.env[key]) text = text.split(process.env[key]!).join("[REDACTED]");
  }
  return text.replace(/(?:gsk_|tvly-|AIza)[A-Za-z0-9_-]+/g, "[REDACTED]").slice(0, 500);
}

function client(baseUrl: string) {
  let cookie = "";
  async function request<T>(path: string, options: { body?: unknown; method?: string; headers?: Record<string, string> } = {}) {
    const response = await fetch(`${baseUrl}${path}`, {
      method: options.method ?? (options.body === undefined ? "GET" : "POST"),
      headers: {
        "Content-Type": "application/json",
        ...(cookie ? { Cookie: cookie } : {}),
        ...options.headers,
      },
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      signal: AbortSignal.timeout(150_000),
      redirect: "manual",
    });
    const nextCookie = response.headers.get("set-cookie");
    if (nextCookie) cookie = nextCookie.split(";")[0];
    const data = await response.json().catch(() => ({})) as T;
    return { status: response.status, data };
  }
  async function ok<T>(path: string, options: Parameters<typeof request>[1] = {}) {
    const result = await request<T>(path, options);
    if (result.status < 200 || result.status >= 300) {
      const error = result.data as { error?: string };
      throw new Error(`${path}: HTTP ${result.status}${error.error ? ` — ${redact(error.error)}` : ""}`);
    }
    return result.data;
  }
  return { request, ok };
}

function check(condition: unknown, description: string): asserts condition {
  if (!condition) throw new Error(`FAIL: ${description}`);
  console.log(`PASS: ${description}`);
}

type Registered = { user: { id: number }; workspace: { id: number } };
type StrategyResult = { status: string; taskId: number; providerKey?: string; strategyId?: number; reason?: string; attempts?: Array<{ providerKey: string; outcome: string; errorCode?: string }> };

async function main() {
  if (!process.argv.includes("--live")) {
    console.log("No calls made. Explicit --live plus --base-url=https://YOUR_PREVIEW authorizes this smoke test.");
    console.log("Creates temporary, clearly marked test accounts; performs one research run and one strategy task; removes its own records in finally.");
    return;
  }
  const baseArg = process.argv.find((arg) => arg.startsWith("--base-url="))?.slice("--base-url=".length);
  if (!baseArg) throw new Error("Specify the current managed preview URL with --base-url");
  const baseUrl = new URL(baseArg);
  if (baseUrl.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(baseUrl.hostname)) {
    throw new Error("Use HTTPS for a remote preview");
  }

  const { db, pool } = await import("@/db");
  const s = await import("@/db/schema");
  const runId = randomUUID().replace(/-/g, "").slice(0, 18);
  const emails: string[] = [];
  const password = randomBytes(24).toString("base64url");
  const a = client(baseUrl.origin);
  const b = client(baseUrl.origin);
  const anonymous = client(baseUrl.origin);

  async function register(testClient: ReturnType<typeof client>, suffix: string) {
    const email = `serein-diagnostic-${runId}-${suffix}@example.invalid`;
    emails.push(email);
    return testClient.ok<Registered>("/api/auth/register", { body: {
      email, password,
      name: "Temporary diagnostic account",
      workspaceName: `Diagnostic ${runId} ${suffix}`,
    } });
  }

  try {
    console.log(`Phase 3 authenticated smoke test started (${new Date().toISOString()}). No credentials, session cookies, or generated strategy text will be printed.`);
    const health = await anonymous.request<unknown>("/api/health");
    check(health.status === 200, "production health endpoint responds");

    const accountA = await register(a, "a");
    check(Boolean(accountA.user.id && accountA.workspace.id), "registration creates a real workspace and session");
    const me = await a.ok<{ user: { id: number } }>("/api/auth/me");
    check(me.user.id === accountA.user.id, "protected session lookup works");
    const workspaces = await a.ok<{ workspaces: Array<{ id: number; role: string }> }>("/api/workspaces");
    check(workspaces.workspaces.some((workspace) => workspace.id === accountA.workspace.id && workspace.role === "owner"), "workspace membership is persisted");

    const business = await a.ok<{ business: { id: number } }>("/api/businesses", { body: {
      name: `Temporary diagnostic business ${runId}`,
      industry: "Software education test fixture",
      description: "Temporary test fixture, not a real business. Explain public web development documentation accurately; do not invent statistics, guarantees, clients, or performance.",
      targetAudience: "Beginner web developers (test audience)",
      brandVoice: "Plain, cautious, evidence-bounded",
    } });
    const businessId = business.business.id;
    check(Boolean(businessId), "business creation persists inside the active workspace");

    const profile = await a.ok<{ profile: { businessId: number } }>("/api/brand-profiles", { body: {
      businessId, tone: "Calm and precise", audience: "Beginner web developers",
      objectives: "Explain official public documentation without inventing business facts",
      claimsPolicy: "No guarantees, metrics, or commercial claims without evidence",
      restrictedTopics: ["medical advice"], vocabulary: ["documentation", "explain"], styleExamples: [],
    } });
    check(profile.profile.businessId === businessId, "brand profile saves for the selected business");

    const providers = await a.ok<{ providers: Array<{ key: string; configured: boolean }>; settings: { allowPaidProviders: boolean } }>("/api/ai/providers");
    check(["gemini", "groq", "tavily"].every((key) => providers.providers.some((provider) => provider.key === key && provider.configured)), "all three provider keys are visible to the production runtime");
    check(providers.settings.allowPaidProviders === false, "paid-provider authorization remains off");
    for (const key of ["GEMINI_API_KEY", "GROQ_API_KEY", "TAVILY_API_KEY"]) {
      const value = process.env[key];
      check(!value || !JSON.stringify(providers).includes(value), `${key} value is absent from API responses`);
    }

    const research = await a.ok<{ status: string; sources: Array<{ url: string }>; providerKey?: string }>("/api/research", { body: {
      businessId, query: "Next.js official documentation App Router", maxResults: 2,
    } });
    check(research.status === "completed" && research.sources.length > 0 && research.providerKey === "tavily", "live research returns and stores actual Tavily sources");

    const strategy = await a.ok<StrategyResult>("/api/strategy", { body: { businessId } });
    console.log(`Strategy task outcome: ${JSON.stringify({
      status: strategy.status,
      providerKey: strategy.providerKey,
      reason: strategy.reason,
      attempts: strategy.attempts?.map((attempt) => ({ providerKey: attempt.providerKey, outcome: attempt.outcome, errorCode: attempt.errorCode })),
    })}`);
    check(strategy.status === "completed" && Boolean(strategy.strategyId), "strategy generation produces a validated persisted draft");
    check(!["openai", "brave"].includes(strategy.providerKey ?? ""), "strategy uses no paid-only provider");

    const context = await a.ok<{ context: { strategies: Array<{ id: number; status: string }> } }>(`/api/strategy?businessId=${businessId}`);
    check(context.context.strategies.some((item) => item.id === strategy.strategyId && ["draft", "needs_review"].includes(item.status)), "completed output is a human-review draft, never published");
    const tasks = await a.ok<{ tasks: Array<{ id: number; partialResult: unknown; status: string }> }>("/api/agent/tasks");
    check(tasks.tasks.some((task) => task.id === strategy.taskId && task.status === "completed" && Boolean(task.partialResult)), "task history preserves the completed work and attempt record");
    const usage = await a.ok<{ events: Array<{ providerKey: string }> }>("/api/ai/usage");
    check(usage.events.length > 0 && usage.events.every((event) => !["openai", "brave"].includes(event.providerKey)), "actual usage is recorded without a paid-provider call");

    const otherBusiness = await a.ok<{ business: { id: number } }>("/api/businesses", { body: { name: `Other diagnostic brand ${runId}` } });
    const otherResearch = await a.ok<{ sources: unknown[] }>(`/api/research?businessId=${otherBusiness.business.id}`);
    check(otherResearch.sources.length === 0, "research for another business does not include the first brand's sources");

    await register(b, "b");
    const foreignRead = await b.request<unknown>(`/api/businesses/${businessId}`);
    check(foreignRead.status === 404, "a second tenant cannot read the first tenant's business");
    const foreignResearch = await b.request<unknown>("/api/research", { body: { businessId, query: "Next.js official documentation" } });
    check(foreignResearch.status === 404, "a second tenant cannot start research against a foreign business");
    const spoof = await anonymous.request<unknown>("/api/businesses", { headers: {
      "x-user-id": String(accountA.user.id), "x-workspace-id": String(accountA.workspace.id),
    } });
    check(spoof.status === 401, "spoofed identity headers do not authorize an anonymous request");

    await a.ok("/api/auth/logout", { body: {} });
    const afterLogout = await a.request<unknown>("/api/auth/me");
    check(afterLogout.status === 401, "logout removes authenticated access");
    console.log("Authenticated smoke checks passed. This is not a comprehensive browser, concurrency, compliance, or security audit.");
  } finally {
    try {
      for (const email of emails) {
        const [user] = await db.select({ id: s.users.id }).from(s.users).where(eq(s.users.email, email)).limit(1);
        if (!user) continue;
        const rows = await db.select({ id: s.workspaces.id }).from(s.workspaces).where(eq(s.workspaces.ownerId, user.id));
        const ids = rows.map((row) => row.id);
        await db.transaction(async (tx) => {
          if (ids.length) {
            await tx.delete(s.contentStrategies).where(inArray(s.contentStrategies.workspaceId, ids));
            await tx.delete(s.researchSources).where(inArray(s.researchSources.workspaceId, ids));
            await tx.delete(s.researchRuns).where(inArray(s.researchRuns.workspaceId, ids));
            await tx.delete(s.websiteAnalyses).where(inArray(s.websiteAnalyses.workspaceId, ids));
            await tx.delete(s.brandProfiles).where(inArray(s.brandProfiles.workspaceId, ids));
            await tx.delete(s.aiUsageEvents).where(inArray(s.aiUsageEvents.workspaceId, ids));
            await tx.delete(s.notifications).where(inArray(s.notifications.workspaceId, ids));
            await tx.delete(s.aiTasks).where(inArray(s.aiTasks.workspaceId, ids));
            await tx.delete(s.workspaceSettings).where(inArray(s.workspaceSettings.workspaceId, ids));
            await tx.delete(s.businesses).where(inArray(s.businesses.workspaceId, ids));
            await tx.delete(s.workspaceMembers).where(inArray(s.workspaceMembers.workspaceId, ids));
            await tx.delete(s.workspaces).where(inArray(s.workspaces.id, ids));
          }
          await tx.delete(s.userSessions).where(eq(s.userSessions.userId, user.id));
          await tx.delete(s.workspaceMembers).where(eq(s.workspaceMembers.userId, user.id));
          await tx.delete(s.users).where(eq(s.users.id, user.id));
        });
      }
      console.log("Temporary diagnostic accounts and their workspace records removed. Real provider calls remain visible at the provider; no customer records were deleted.");
    } finally {
      await pool.end();
    }
  }
}

main().catch((error: unknown) => {
  console.error(redact(error instanceof Error ? error.message : "Smoke test failed"));
  process.exitCode = 1;
});
