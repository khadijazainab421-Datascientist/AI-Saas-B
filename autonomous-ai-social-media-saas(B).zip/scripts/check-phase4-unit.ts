import { loadEnvConfig } from "@next/env";
import sharp from "sharp";
import { unzipSync } from "fflate";
import { emptyDraft, DEFAULT_STYLE, draftSchema, styleSchema } from "../src/lib/studio/types";
import { scheduleInstant } from "../src/lib/studio/time";
import { graphicSvg } from "../src/lib/studio/graphic-template";

loadEnvConfig(process.cwd());
function check(value: unknown, label: string) { if (!value) throw new Error(`FAIL: ${label}`); console.log(`PASS: ${label}`); }
function rejects(fn: () => unknown, label: string) { let failed = false; try { fn(); } catch { failed = true; } check(failed, label); }
async function main() {
  const { parseStudioOutput } = await import("../src/lib/studio/finalize");
  const { pool } = await import("@/db");
  try {
    const { taskWorkLog } = await import("../src/lib/ai/work-log");
    const work = taskWorkLog({ rawOutput: "prior provider work", note: "retain metadata" });
    check(work.snapshot([]).rawOutput === "prior provider work", "pausing/resuming retains earlier raw provider output");
    work.append("new provider work", "fixture-provider");
    const snapshot = work.snapshot([]);
    check(snapshot.outputs.length === 2 && snapshot.note === "retain metadata", "new provider work appends to history without discarding prior work or metadata");
    check(draftSchema.parse(emptyDraft()).caption === "", "new drafts begin empty rather than with simulated AI text");
    rejects(() => draftSchema.parse({ ...emptyDraft(), platforms: ["instagram", "instagram"] }), "duplicate channel values are rejected");
    rejects(() => draftSchema.parse({ ...emptyDraft(), status: "published" }), "client-provided publishing status cannot be mass-assigned into document data");
    rejects(() => styleSchema.parse({ ...DEFAULT_STYLE, accent: 'red\" onload=\"alert(1)' }), "unsafe non-hex template colors are rejected");
    const caption = parseStudioOutput("studio_caption", '{"caption":"A careful introduction.","hashtags":["#careful","careful"],"platformCaptions":{}}');
    check(Array.isArray(caption.hashtags) && caption.hashtags.length === 1, "AI hashtags are normalized and deduplicated");
    const carousel = parseStudioOutput("studio_carousel", JSON.stringify({ slides: [{ heading: "One", body: "First" }, { heading: "Two", body: "Second" }] }));
    check(Array.isArray(carousel.slides) && carousel.slides.length === 2 && Boolean((carousel.slides[0] as { id: string }).id), "validated carousels receive safe editor slide identifiers");
    rejects(() => parseStudioOutput("studio_carousel", '{"slides":[{"heading":"One","body":"Only"}]}'), "one-slide AI carousels are held as invalid output");
    rejects(() => parseStudioOutput("studio_caption", "not json"), "invalid provider text is not treated as a valid caption");
    const svg = graphicSvg({ brand: '<script>bad</script>', heading: '<img src=x onerror="bad">', body: "A & B", style: DEFAULT_STYLE });
    check(!svg.includes("<script>") && !svg.includes("<img src=x") && svg.includes("&amp;"), "template content is XML-escaped rather than executed as markup");
    const png = await sharp(Buffer.from(svg)).png().toBuffer();
    const info = await sharp(png).metadata();
    check(info.width === 1080 && info.height === 1080 && info.format === "png", "local template rendering produces a real 1080-square PNG");
    check(scheduleInstant("2032-06-10T12:00", "Asia/Karachi", new Date("2032-01-01")).toISOString() === "2032-06-10T07:00:00.000Z", "scheduling converts an IANA wall time to the correct UTC instant");
    rejects(() => scheduleInstant("2032-03-14T02:30", "America/New_York", new Date("2032-01-01")), "nonexistent daylight-saving times are rejected");
    rejects(() => scheduleInstant("2032-11-07T01:30", "America/New_York", new Date("2032-01-01")), "ambiguous daylight-saving times are rejected");
    rejects(() => scheduleInstant("2032-06-10T12:00", "not/a-zone", new Date("2032-01-01")), "invalid calendar time zones are rejected");
    rejects(() => scheduleInstant("2000-01-01T12:00", "UTC"), "past scheduling requests are rejected");
    const { exportGraphics } = await import("../src/lib/studio/graphics");
    const document = { ...emptyDraft("carousel"), slides: [{ id: "one", heading: "One", body: "First thought", altText: "", imageAssetId: null }, { id: "two", heading: "Two", body: "Second thought", altText: "", imageAssetId: null }] };
    const bundle = await exportGraphics(1, "Diagnostic template only", document, DEFAULT_STYLE, true);
    const files = unzipSync(bundle.bytes);
    check(Boolean(files["slide-01.png"] && files["slide-02.png"] && files["caption.txt"] && files["draft.json"]), "carousel export is a real multi-file ZIP, not a simulated download");
    console.log("Phase 4 pure validation/rendering checks passed. No provider call or customer-data mutation was made.");
  } finally { await pool.end(); }
}
main().catch((error: unknown) => { console.error(error instanceof Error ? error.message : "Unit validation failed"); process.exitCode = 1; });
