import { expect, type Browser, type BrowserContext } from "@playwright/test";
import { PREVIEW_SESSION_HEADER } from "../src/lib/session-constants";

type PreviewReply = {
  user: { id: number; email: string };
  sessionTransport: string;
  previewSession: { token: string; expiresInSeconds: number };
  expiresAt: string;
};

type Options = {
  browser: Browser;
  contexts: BrowserContext[];
  origin: string;
  parentUrl: string;
  existingEmail: string;
  newEmail: string;
  password: string;
  foreignBusinessId: number;
};

function check(value: unknown, label: string): asserts value {
  if (!value) throw new Error(`FAIL: ${label}`);
  console.log(`PASS: ${label}`);
}

/** Test-only cookie stripping is supplied by the local TLS proxy, never production routes. */
export async function checkBlockedCookieFlows(options: Options) {
  const { browser, contexts, origin, parentUrl, existingEmail, newEmail, password, foreignBusinessId } = options;
  const blocked = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1366, height: 1000 }, extraHTTPHeaders: { "x-serein-test-no-cookies": "1" } });
  contexts.push(blocked);
  const page = await blocked.newPage();
  let rejectedCookieProbes = 0;
  blocked.on("response", (response) => { if (new URL(response.url()).pathname === "/api/auth/me" && response.status() === 401) rejectedCookieProbes++; });

  await page.goto(`${origin}/register`);
  await page.getByLabel("Your name").fill("Temporary cookie-blocked test");
  await page.getByLabel("Email address").fill(newEmail);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByLabel("First workspace name").fill("Cookie-blocked diagnostic workspace");
  const firstPreviewResponse = page.waitForResponse((response) => new URL(response.url()).pathname === "/api/auth/login" && response.request().postData()?.includes('"sessionTransport":"preview"') === true);
  await page.getByRole("button", { name: "Create account & workspace", exact: true }).click();
  const firstResponse = await firstPreviewResponse;
  check(firstResponse.status() === 200, "cookie-blocked registration can establish a real preview session without registering twice");
  const initial = await firstResponse.json() as PreviewReply;
  let token = initial.previewSession.token;
  check(initial.user.email === newEmail && initial.sessionTransport === "preview" && /^p1_[A-Za-z0-9_-]{43}$/.test(token), "preview credential belongs to the actually registered diagnostic account");
  check(initial.previewSession.expiresInSeconds > 0 && initial.previewSession.expiresInSeconds <= 1800, "server reports at most thirty minutes for the temporary session");
  await expect(page.getByRole("button", { name: "Account and workspaces" })).toBeVisible({ timeout: 25_000 });
  await expect(page.getByText("Temporary preview session.", { exact: true })).toBeVisible();
  check(rejectedCookieProbes > 0, "the missing-cookie failure is reproduced before automatic preview recovery");
  check((await blocked.cookies(origin)).every((cookie) => cookie.name !== "serein_session"), "authenticated dashboard works while the session cookie is completely absent");

  await page.getByRole("link", { name: "Businesses", exact: true }).click();
  await page.getByRole("button", { name: "Add business", exact: true }).click();
  const businessName = "Cookie-free private business fixture";
  await page.getByLabel("Business name *", { exact: true }).fill(businessName);
  const saveResponsePromise = page.waitForResponse((response) => new URL(response.url()).pathname === "/api/businesses" && response.request().method() === "POST");
  await page.getByRole("button", { name: "Save business", exact: true }).click();
  const saveResponse = await saveResponsePromise;
  check(saveResponse.status() === 201 && Boolean(saveResponse.request().headers()[PREVIEW_SESSION_HEADER]), "business creation uses an authenticated header instead of a missing cookie");
  await expect(page.getByRole("heading", { name: businessName, exact: true })).toBeVisible();
  check(true, "cookie-free business creation persists and reloads from the private API");

  const providersResponse = page.waitForResponse((response) => new URL(response.url()).pathname === "/api/ai/providers");
  await page.getByRole("link", { name: "AI engine", exact: true }).click();
  check((await providersResponse).status() === 200, "AI Engine private metadata remains usable without session cookies");

  const privateHeaders = () => ({ [PREVIEW_SESSION_HEADER]: token, Origin: origin });
  check((await blocked.request.get(`${origin}/api/businesses/${foreignBusinessId}`, { headers: privateHeaders() })).status() === 404, "a valid preview session still cannot read another tenant's business");
  check((await blocked.request.put(`${origin}/api/businesses/${foreignBusinessId}`, { data: { name: "must not be changed" }, headers: privateHeaders() })).status() === 404, "a valid preview session still cannot edit another tenant's business");
  check((await blocked.request.post(`${origin}/api/workspaces`, { data: { name: "must not be created" }, headers: { ...privateHeaders(), Origin: "https://untrusted.invalid" } })).status() === 403, "preview session headers do not bypass mutation origin protection");

  await page.getByRole("button", { name: "Account and workspaces" }).click();
  await page.getByRole("button", { name: "New workspace", exact: true }).click();
  await page.getByLabel("New workspace name").fill("Cookie-free second workspace");
  const rotatedResponse = page.waitForResponse((response) => new URL(response.url()).pathname === "/api/auth/switch-workspace");
  await page.getByRole("button", { name: "Create workspace", exact: true }).click();
  const rotated = await (await rotatedResponse).json() as { previewSession: { token: string; expiresInSeconds: number } };
  const oldToken = token;
  token = rotated.previewSession.token;
  await expect(page.getByRole("button", { name: "Account and workspaces" })).toContainText("Cookie-free second workspace", { timeout: 25_000 });
  check(token !== oldToken && /^p1_[A-Za-z0-9_-]{43}$/.test(token), "workspace switching rotates the cookie-free credential");
  check(rotated.previewSession.expiresInSeconds <= initial.previewSession.expiresInSeconds, "workspace switching does not extend the preview's original expiry");
  check((await blocked.request.get(`${origin}/api/auth/me`, { headers: { [PREVIEW_SESSION_HEADER]: oldToken } })).status() === 401, "a rotated-out preview token is no longer valid");

  await page.getByRole("button", { name: "Account and workspaces" }).click();
  await page.getByRole("button", { name: "Sign out", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Sign in to your workspace", exact: true })).toBeVisible();
  check((await blocked.request.get(`${origin}/api/auth/me`, { headers: privateHeaders() })).status() === 401, "logout revokes a cookie-free session on the server");

  // Exact existing-account scenario, inside an iframe, with all persistent browser storage denied.
  const noStorage = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1366, height: 960 }, extraHTTPHeaders: { "x-serein-test-no-cookies": "1" } });
  contexts.push(noStorage);
  await noStorage.addInitScript(() => {
    for (const name of ["localStorage", "sessionStorage"]) {
      Object.defineProperty(window, name, { configurable: true, get() { throw new DOMException("Storage denied by test privacy policy", "SecurityError"); } });
    }
  });
  const embeddedPage = await noStorage.newPage();
  await embeddedPage.goto(parentUrl);
  const frame = embeddedPage.frameLocator("#preview");
  await frame.getByLabel("Email address").fill(existingEmail);
  await frame.getByLabel("Password", { exact: true }).fill("not-the-password");
  await frame.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(frame.locator("#auth-error")).toContainText("Email or password is incorrect");
  check(true, "cookie-free fallback never turns a wrong password into a successful login");
  await frame.getByLabel("Password", { exact: true }).fill(password);
  await frame.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(frame.getByRole("button", { name: "Account and workspaces" })).toBeVisible({ timeout: 25_000 });
  await expect(frame.getByText("Temporary preview session.", { exact: true })).toBeVisible();
  check(true, "existing-account iframe login works with cookies, localStorage, and sessionStorage all unavailable");
  await frame.getByRole("link", { name: "Businesses", exact: true }).click();
  await expect(frame.getByRole("heading", { name: "A separate world for every brand.", exact: true })).toBeVisible();
  check(true, "private app navigation retains the memory-only session without a page reload");
  await embeddedPage.reload();
  await expect(embeddedPage.frameLocator("#preview").getByRole("heading", { name: "Sign in to your workspace", exact: true })).toBeVisible({ timeout: 20_000 });
  check(true, "a full refresh truthfully requests sign-in again instead of retaining an undocumented credential");

  // Direct protocol negatives use only these freshly generated fixture credentials.
  const denied = await blocked.request.post(`${origin}/api/auth/login`, {
    data: { email: existingEmail, password: "wrong-password", sessionTransport: "preview" },
    headers: { Origin: origin, "x-serein-preview-fallback": "1" },
  });
  check(denied.status() === 401 && !(await denied.json()).previewSession, "the preview endpoint releases no credential for an invalid password");
  check((await blocked.request.get(`${origin}/api/auth/me`, { headers: { [PREVIEW_SESSION_HEADER]: `p1_${"A".repeat(43)}` } })).status() === 401, "a syntactically valid but invented preview token is rejected by DB verification");
  const expiring = await blocked.request.post(`${origin}/api/auth/login`, {
    data: { email: existingEmail, password, sessionTransport: "preview", expiresInSeconds: 9999999 },
    headers: { Origin: origin, "x-serein-preview-fallback": "1" },
  });
  check(expiring.status() === 200, "explicit preview sign-in still requires and verifies real fixture credentials");
  const expiryReply = await expiring.json() as PreviewReply;
  check(expiryReply.previewSession.expiresInSeconds <= 1800, "a client-supplied lifetime cannot extend a preview session");
  const { db } = await import("@/db");
  const { userSessions } = await import("@/db/schema");
  const { hashSessionToken } = await import("../src/lib/auth");
  const { and, eq } = await import("drizzle-orm");
  const changed = await db.update(userSessions).set({ expiresAt: new Date(Date.now() - 1000) }).where(and(
    eq(userSessions.userId, expiryReply.user.id), eq(userSessions.tokenHash, hashSessionToken(expiryReply.previewSession.token)),
  )).returning({ id: userSessions.id });
  check(changed.length === 1 && expiryReply.user.email === existingEmail, "expiry fault injection touches only the exact temporary fixture session");
  check((await blocked.request.get(`${origin}/api/auth/me`, { headers: { [PREVIEW_SESSION_HEADER]: expiryReply.previewSession.token } })).status() === 401, "expired preview credentials are rejected server-side");
  console.log("Blocked-cookie checks used actual password/session/database flows. No customer credential, raw session token, AI call, or research call was logged.");
}
