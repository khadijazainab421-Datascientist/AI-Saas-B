import { loadEnvConfig } from "@next/env";
import { resolveStandalonePreviewOrigin } from "../src/lib/preview-origin";

loadEnvConfig(process.cwd());

function check(value: unknown, message: string) {
  if (!value) throw new Error(`FAIL: ${message}`);
  console.log(`PASS: ${message}`);
}

const sandbox = "sandbox-preview-check";
check(resolveStandalonePreviewOrigin({ sandboxId: sandbox }) === `https://3000-${sandbox}.e2b.app`, "sandbox origin follows the official port-specific host format");
check(resolveStandalonePreviewOrigin({ configuredOrigin: "https://social.example.com", sandboxId: sandbox }) === "https://social.example.com", "explicit public app origin takes precedence");
check(resolveStandalonePreviewOrigin({ configuredOrigin: "javascript:alert(1)" }) === null, "non-HTTP script origins are rejected");
check(resolveStandalonePreviewOrigin({ configuredOrigin: "https://user:password@example.com" }) === null, "credentials are never embedded into an app link");
check(resolveStandalonePreviewOrigin({ configuredOrigin: "https://example.com/?session=not-real" }) === null, "query/session strings are not copied into the standalone origin");
check(resolveStandalonePreviewOrigin({ sandboxId: "bad/id?token=not-real" }) === null, "malformed sandbox identifiers cannot inject an address");
check(resolveStandalonePreviewOrigin({ requestHost: "editor.example/escape", requestProtocol: "https" }) === null, "malformed forwarded hosts are rejected");
check(resolveStandalonePreviewOrigin({ requestHost: "127.0.0.1:3443", requestProtocol: "https" }) === "https://127.0.0.1:3443", "a normal local HTTPS deployment can resolve its own origin");
check(resolveStandalonePreviewOrigin({ requestHost: "localhost:3000", requestProtocol: "http" }) === "http://localhost:3000", "local HTTP development remains supported");
check(resolveStandalonePreviewOrigin({ requestHost: "public.example", requestProtocol: "http" }) === null, "an insecure remote fallback is not presented as a safe standalone address");
const expected = process.argv.find((arg) => arg.startsWith("--expected-origin="))?.slice("--expected-origin=".length);
if (expected) {
  const actual = resolveStandalonePreviewOrigin({
    configuredOrigin: process.env.APP_PUBLIC_ORIGIN,
    sandboxId: process.env.E2B_SANDBOX_ID,
    sandboxDomain: process.env.E2B_DOMAIN,
    port: Number(process.env.PORT || 3000),
  });
  check(actual === new URL(expected).origin, "runtime origin matches the managed preview returned for this Option B sandbox");
}
console.log("Preview address checks complete. No external request, credential, or database mutation was used.");
