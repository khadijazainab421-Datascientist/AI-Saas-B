import { loadEnvConfig } from "@next/env";
import { createSessionToken, hashSessionToken, previewSessionsEnabled, requestSessionToken, sessionCookieOptions, isSameOriginRequest, PREVIEW_SESSION_TTL_SECONDS } from "../src/lib/auth";
import { PREVIEW_SESSION_HEADER } from "../src/lib/session-constants";

loadEnvConfig(process.cwd());
function check(value: unknown, label: string) { if (!value) throw new Error(`FAIL: ${label}`); console.log(`PASS: ${label}`); }
check(!previewSessionsEnabled({}), "normal deployments do not enable cookie-free preview sessions by default");
check(previewSessionsEnabled({ E2B_SANDBOX_ID: "sandbox-policy-check" }), "a recognized sandbox can use preview transport");
check(!previewSessionsEnabled({ E2B_SANDBOX_ID: "sandbox-policy-check", ALLOW_PREVIEW_TOKEN_AUTH: "false" }), "explicit deployment opt-out disables preview transport");
check(previewSessionsEnabled({ ALLOW_PREVIEW_TOKEN_AUTH: "true" }), "a custom preview deployment can explicitly opt in");
check(PREVIEW_SESSION_TTL_SECONDS === 1800, "preview lifetime is bounded to thirty minutes");
const cookie = createSessionToken();
const preview = createSessionToken("preview");
check(/^s1_[A-Za-z0-9_-]{43}$/.test(cookie), "normal sessions retain a 256-bit opaque cookie token");
check(/^p1_[A-Za-z0-9_-]{43}$/.test(preview), "preview tokens have a separate 256-bit opaque namespace");
check(preview !== createSessionToken("preview"), "new preview tokens are independently randomized");
check(/^[a-f0-9]{64}$/.test(hashSessionToken(preview)), "only a SHA-256 token verifier is needed in the existing session table");
const original = process.env.ALLOW_PREVIEW_TOKEN_AUTH;
try {
  process.env.ALLOW_PREVIEW_TOKEN_AUTH = "false";
  check(!requestSessionToken(new Request("https://app.example/api/auth/me", { headers: { [PREVIEW_SESSION_HEADER]: preview } })), "preview headers are ignored when deployment support is disabled");
  process.env.ALLOW_PREVIEW_TOKEN_AUTH = "true";
  check(requestSessionToken(new Request("https://app.example/api/auth/me", { headers: { [PREVIEW_SESSION_HEADER]: preview } })) === preview, "enabled preview transport extracts the exact opaque credential for DB verification");
  check(!requestSessionToken(new Request("https://app.example/api/auth/me", { headers: { [PREVIEW_SESSION_HEADER]: "p1_invalid", Cookie: `serein_session=${cookie}` } })), "invalid preview headers cannot silently change identity through a different cookie");
  check(!requestSessionToken(new Request("https://app.example/api/auth/me", { headers: { Cookie: `serein_session=${preview}` } })), "preview tokens are not accepted through the normal cookie channel");
  const proxyRequest = new Request("http://127.0.0.1:3000/api/auth/login", {
    method: "POST", headers: { host: "127.0.0.1:3000", "x-forwarded-host": "preview.editor.example", origin: "https://preview.editor.example", "x-serein-embedded-preview": "1" },
  });
  const policy = sessionCookieOptions(proxyRequest);
  check(policy.secure && policy.httpOnly && policy.sameSite === "none" && policy.partitioned, "embedded proxy hostnames still get the secure partitioned cookie policy");
  const ordinary = sessionCookieOptions(new Request("https://app.example/api/auth/login", { method: "POST", headers: { origin: "https://app.example" } }));
  check(ordinary.secure && ordinary.httpOnly && ordinary.sameSite === "lax" && !ordinary.partitioned, "ordinary top-level login retains secure HttpOnly SameSite=Lax cookies");
  check(!isSameOriginRequest(new Request("https://app.example/api/businesses", { method: "POST", headers: { origin: "https://untrusted.invalid" } })), "preview support does not disable the mutation origin check");
} finally {
  if (original === undefined) delete process.env.ALLOW_PREVIEW_TOKEN_AUTH;
  else process.env.ALLOW_PREVIEW_TOKEN_AUTH = original;
}
console.log("Session policy checks complete. No login, customer-data mutation, provider call, or secret value was logged.");
