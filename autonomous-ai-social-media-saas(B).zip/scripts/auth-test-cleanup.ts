import { eq, inArray } from "drizzle-orm";

/** Only pass exact, freshly generated diagnostic emails; never accepts a wildcard. */
export async function cleanupAuthFixtures(emails: string[]) {
  const { db, pool } = await import("@/db");
  const s = await import("@/db/schema");
  try {
    for (const email of emails) {
      if (!/^auth-check-[a-f0-9]+-[a-z]+@example\.invalid$/.test(email)) throw new Error("Refusing to clean a non-diagnostic account");
      const [user] = await db.select({ id: s.users.id }).from(s.users).where(eq(s.users.email, email)).limit(1);
      if (!user) continue;
      const rows = await db.select({ id: s.workspaces.id }).from(s.workspaces).where(eq(s.workspaces.ownerId, user.id));
      const ids = rows.map((row) => row.id);
      await db.transaction(async (tx) => {
        if (ids.length) {
          await tx.delete(s.contentStrategies).where(inArray(s.contentStrategies.workspaceId, ids));
          await tx.delete(s.researchSources).where(inArray(s.researchSources.workspaceId, ids));
          await tx.delete(s.researchRuns).where(inArray(s.researchRuns.workspaceId, ids));
          await tx.delete(s.websiteAnalyses).where(inArray(s.websiteAnalyses.workspaceId, ids));
          await tx.delete(s.brandProfiles).where(inArray(s.brandProfiles.workspaceId, ids));
          await tx.delete(s.aiUsageEvents).where(inArray(s.aiUsageEvents.workspaceId, ids));
          await tx.delete(s.notifications).where(inArray(s.notifications.workspaceId, ids));
          await tx.delete(s.aiTasks).where(inArray(s.aiTasks.workspaceId, ids));
          await tx.delete(s.workspaceSettings).where(inArray(s.workspaceSettings.workspaceId, ids));
          await tx.delete(s.businesses).where(inArray(s.businesses.workspaceId, ids));
          await tx.delete(s.userSessions).where(inArray(s.userSessions.workspaceId, ids));
          await tx.delete(s.workspaceMembers).where(inArray(s.workspaceMembers.workspaceId, ids));
          await tx.delete(s.workspaces).where(inArray(s.workspaces.id, ids));
        }
        await tx.delete(s.userSessions).where(eq(s.userSessions.userId, user.id));
        await tx.delete(s.workspaceMembers).where(eq(s.workspaceMembers.userId, user.id));
        await tx.delete(s.users).where(eq(s.users.id, user.id));
      });
    }
  } finally { await pool.end(); }
}
