import { loadEnvConfig } from "@next/env";

loadEnvConfig(process.cwd(), process.env.NODE_ENV !== "production");

const LIVE_KEYS = ["gemini", "groq", "tavily"] as const;
const SECRET_VARIABLES = [
  "GEMINI_API_KEY", "GROQ_API_KEY", "TAVILY_API_KEY",
  "OPENAI_API_KEY", "BRAVE_API_KEY", "AUTH_SECRET", "DATABASE_URL",
];

function redact(value: unknown) {
  let text = String(value);
  for (const variable of SECRET_VARIABLES) {
    const secret = process.env[variable];
    if (secret) text = text.split(secret).join("[REDACTED]");
  }
  return text
    .replace(/AIza[A-Za-z0-9_-]+/g, "[REDACTED]")
    .replace(/(?:gsk_|tvly-)[A-Za-z0-9_-]+/g, "[REDACTED]")
    .replace(/Bearer\s+[^\s"']+/gi, "Bearer [REDACTED]")
    .slice(0, 700);
}

async function main() {
  if (!process.argv.includes("--live")) {
    console.log("No external calls made. Run with --live to authorize the small connection tests.");
    console.log("Tests: one Gemini completion, one Groq completion, one Tavily basic search, plus non-generating credential probes.");
    console.log("OpenAI, Brave, customer information, business records, and publishing are never used by this script.");
    return;
  }

  const { getProvider } = await import("../src/lib/ai/providers");
  const { ProviderError } = await import("../src/lib/ai/types");
  const outcomes: Array<{ provider: string; credentialProbe: string; operation: string; detail: unknown }> = [];

  console.log("Live provider checks started. Secret values and generated text are not logged.");
  console.log("Standalone adapter diagnostics: provider usage is real, but no workspace usage records or business data are created by this script.");

  const selected = process.argv.find((arg) => arg.startsWith("--provider="))?.split("=")[1];
  if (selected && !LIVE_KEYS.some((key) => key === selected)) {
    throw new Error("Only gemini, groq, or tavily may be selected by this diagnostic script");
  }
  const selectedKeys = selected ? LIVE_KEYS.filter((key) => key === selected) : LIVE_KEYS;

  for (const key of selectedKeys) {
    const provider = getProvider(key);
    if (!provider || provider.isPaid) throw new Error("Unexpected provider registry entry");
    if (!provider.configured()) {
      outcomes.push({ provider: key, credentialProbe: "not_configured", operation: "skipped", detail: `${provider.envVar} is missing` });
      console.log(`${key}: not configured; no call made.`);
      continue;
    }

    const health = await provider.healthCheck();
    console.log(`${key}: credential probe ${health.healthy ? "accepted" : "not verified"}. ${redact(health.message)}`);
    const started = Date.now();

    try {
      if (provider.kind === "ai") {
        const result = await provider.complete!({
          system: 'This is a connection test using no business data. Return only a JSON object with one property: "connected": true. Do not include markdown or explanations.',
          prompt: "Confirm the API connection using the requested JSON object.",
          jsonMode: true,
          temperature: 0.1,
          maxTokens: 1024,
        });
        const text = result.text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "");
        let structured = false;
        try {
          const parsed = JSON.parse(text) as { connected?: unknown };
          structured = parsed.connected === true;
        } catch {
          // Preserve the truth: generating text is not proof of valid structured output.
        }
        const detail = {
          model: result.model,
          inputTokens: result.inputTokens,
          outputTokens: result.outputTokens,
          structuredJsonValidated: structured,
          latencyMs: Date.now() - started,
        };
        outcomes.push({ provider: key, credentialProbe: health.healthy ? "accepted" : "not_verified", operation: structured ? "passed" : "invalid_structured_output", detail });
        console.log(`${key}: ${structured ? "generation and structured JSON passed" : "text received, but structured JSON did not validate"}. ${JSON.stringify(detail)}`);
      } else {
        const result = await provider.search!("Next.js official documentation", 2);
        const validSources = result.sources.filter((source) => {
          try {
            return ["https:", "http:"].includes(new URL(source.url).protocol) && source.title.trim().length > 0;
          } catch {
            return false;
          }
        });
        const detail = {
          sourceCount: validSources.length,
          sourceHosts: validSources.map((source) => new URL(source.url).hostname),
          searchDepth: "basic",
          documentedCreditCost: 1,
          latencyMs: Date.now() - started,
        };
        outcomes.push({ provider: key, credentialProbe: health.healthy ? "accepted" : "not_verified", operation: validSources.length > 0 ? "passed" : "empty_results", detail });
        console.log(`${key}: ${validSources.length > 0 ? "live source search passed" : "no usable sources returned"}. ${JSON.stringify(detail)}`);
      }
    } catch (error) {
      const detail = error instanceof ProviderError
        ? { code: error.code, httpStatus: error.httpStatus, retryAfterMs: error.retryAfterMs, message: redact(error.message) }
        : { message: redact(error instanceof Error ? error.message : "Unknown error") };
      outcomes.push({ provider: key, credentialProbe: health.healthy ? "accepted" : "not_verified", operation: "failed", detail });
      console.log(`${key}: live operation failed. ${JSON.stringify(detail)}`);
    }
  }

  console.log("Sanitized summary:");
  console.log(JSON.stringify({ checkedAt: new Date().toISOString(), outcomes }, null, 2));
  if (outcomes.some((outcome) => outcome.operation !== "passed")) process.exitCode = 1;
}

main().catch((error: unknown) => {
  console.error(redact(error instanceof Error ? error.message : "Diagnostics failed"));
  process.exitCode = 1;
});
