import { loadEnvConfig } from "@next/env";
import { randomBytes, randomUUID } from "node:crypto";
import sharp from "sharp";
import { unzipSync } from "fflate";
import { formatInTimeZone } from "date-fns-tz";
import { chromium, expect } from "@playwright/test";
import { emptyDraft, DEFAULT_STYLE, type PostDTO, type GenerationDTO } from "../src/lib/studio/types";
import { cleanupAuthFixtures } from "./auth-test-cleanup";

loadEnvConfig(process.cwd());
function check(value: unknown, label: string): asserts value { if (!value) throw new Error(`FAIL: ${label}`); console.log(`PASS: ${label}`); }
function client(origin: string) {
  let cookie = "";
  async function call(path: string, options: { method?: string; body?: unknown } = {}) {
    const form = options.body instanceof FormData;
    const response = await fetch(`${origin}${path}`, { method: options.method ?? (options.body === undefined ? "GET" : "POST"), credentials: "include", redirect: "manual", headers: { ...(form ? {} : { "Content-Type": "application/json" }), ...(cookie ? { Cookie: cookie } : {}) }, body: options.body === undefined ? undefined : form ? options.body as FormData : JSON.stringify(options.body), signal: AbortSignal.timeout(150000) });
    const received = response.headers.get("set-cookie"); if (received) cookie = received.split(";")[0];
    const isJson = response.headers.get("content-type")?.includes("application/json");
    const data = isJson ? await response.json() : null;
    const bytes = isJson ? null : new Uint8Array(await response.arrayBuffer());
    return { status: response.status, data, bytes, headers: response.headers };
  }
  async function ok<T>(path: string, options: Parameters<typeof call>[1] = {}) { const result = await call(path, options); if (result.status < 200 || result.status >= 300) throw new Error(`${path}: HTTP ${result.status} ${result.data?.error || ""}`); return result.data as T; }
  return { call, ok };
}
async function main() {
  if (!process.argv.includes("--run")) { console.log("No tests run. Use --run against the local managed production app; optional --live-ai makes one real AI task."); return; }
  const origin = "http://127.0.0.1:3000";
  const nonce = randomUUID().replace(/-/g, "").slice(0, 18);
  const emailA = `auth-check-${nonce}-a@example.invalid`, emailB = `auth-check-${nonce}-b@example.invalid`;
  const password = randomBytes(24).toString("base64url");
  const a = client(origin), b = client(origin), anonymous = client(origin);
  const { db } = await import("@/db"); const s = await import("@/db/schema"); const { eq } = await import("drizzle-orm");
  let browser: Awaited<ReturnType<typeof chromium.launch>> | null = null;
  let browserPostId = 0;
  try {
    const accountA = await a.ok<{ user: { id: number }; workspace: { id: number } }>("/api/auth/register", { body: { email: emailA, password, name: "Temporary Phase 4 diagnostic", workspaceName: `Studio ${nonce}` } });
    const accountB = await b.ok<{ user: { id: number }; workspace: { id: number } }>("/api/auth/register", { body: { email: emailB, password, name: "Other temporary diagnostic", workspaceName: `Other studio ${nonce}` } });
    const business = await a.ok<{ business: { id: number } }>("/api/businesses", { body: { name: `Studio fixture ${nonce}`, industry: "Software education test", description: "A temporary test fixture, not a real customer or business. Explain public software concepts without statistics, guarantees, offers or invented evidence.", brandVoice: "Calm and factual" } });
    const businessId = business.business.id;
    check((await anonymous.call("/api/studio")).status === 401, "Studio data requires a valid authenticated session");
    const first = await a.ok<{ post: PostDTO }>("/api/studio", { body: { businessId, document: emptyDraft() } });
    let post = first.post;
    browserPostId = post.id;
    check(post.version === 1 && post.document.caption === "" && post.status === "draft", "draft creation persists an empty real record without sample content");
    check((await b.call(`/api/studio/posts/${post.id}`)).status === 404, "another tenant cannot read a draft");
    check((await b.call(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "archive", version: post.version } })).status === 404, "another tenant cannot mutate a draft");
    check((await a.call(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "schedule", version: post.version, wallTime: "2032-01-01T12:00", timeZone: "UTC" } })).status === 400, "unapproved drafts cannot be scheduled");
    const originalVersion = post.version;
    const saved = await a.ok<{ post: PostDTO }>(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "save", version: post.version, document: { ...post.document, title: `Planned studio test ${nonce}`, caption: "100% guaranteed results" } } });
    post = saved.post;
    check(post.version === 2 && post.reviewFlags.length > 0, "saving a claim-bearing draft records review flags and a new version");
    check((await a.call(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "save", version: originalVersion, document: emptyDraft() } })).status === 409, "stale editor versions cannot overwrite newer saved work");
    check((await a.call(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "approve", version: post.version } })).status === 400, "flagged copy requires an explicit human acknowledgement");
    post = (await a.ok<{ post: PostDTO }>(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "approve", version: post.version, acknowledgeFlags: true } })).post;
    check(post.status === "approved" && post.approvedBy === accountA.user.id, "approval is attributed to the actual workspace reviewer");
    const wallTime = formatInTimeZone(new Date(Date.now() + 2 * 86400000), "Asia/Karachi", "yyyy-MM-dd'T'HH:mm");
    const planned = await a.ok<{ post: PostDTO; publishingEnabled: boolean; notice: string }>(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "schedule", version: post.version, wallTime, timeZone: "Asia/Karachi" } });
    post = planned.post;
    check(post.status === "scheduled" && formatInTimeZone(post.scheduledAt!, "Asia/Karachi", "yyyy-MM-dd'T'HH:mm") === wallTime, "approved scheduling preserves the chosen wall time and IANA zone");
    check(planned.publishingEnabled === false && planned.notice.includes("will not publish"), "scheduling explicitly reports that no publishing worker is connected");
    const start = new Date(Date.now() - 86400000).toISOString(), end = new Date(Date.now() + 7 * 86400000).toISOString();
    const calendar = await a.ok<{ posts: PostDTO[] }>(`/api/studio/calendar?start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`);
    check(calendar.posts.some((item) => item.id === post.id), "the calendar reads the actual saved schedule");
    post = (await a.ok<{ post: PostDTO }>(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "save", version: post.version, document: { ...post.document, caption: "A new factual caption for the saved draft." } } })).post;
    check(post.status === "draft" && !post.approvedAt && !post.scheduledAt, "editing approved/scheduled copy clears its old approval and time");
    const history = await a.ok<{ revisions: Array<{ id: number; version: number }> }>(`/api/studio/posts/${post.id}`);
    check(history.revisions.length >= 5, "revision history preserves actual create/save/review/schedule operations");
    const initialRevision = history.revisions.find((item) => item.version === 1)!;
    post = (await a.ok<{ post: PostDTO }>(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "restore", version: post.version, revisionId: initialRevision.id } })).post;
    check(post.document.caption === "" && post.status === "draft", "restoring history creates a fresh draft without resurrecting approval");

    const image = await sharp({ create: { width: 96, height: 64, channels: 3, background: "#DCEBE4" } }).png().toBuffer();
    const form = new FormData(); form.append("businessId", String(businessId)); form.append("file", new File([new Uint8Array(image)], "owned-test.png", { type: "image/png" }));
    const asset = await a.ok<{ asset: { id: number; mimeType: string } }>("/api/studio/assets", { body: form });
    check(asset.asset.mimeType === "image/webp", "image upload is genuinely decoded and normalized before persistence");
    const privateImage = await a.call(`/api/studio/assets/${asset.asset.id}`);
    check(privateImage.status === 200 && Boolean(privateImage.bytes?.length), "private uploaded media can be read through the authenticated endpoint");
    check((await b.call(`/api/studio/assets/${asset.asset.id}`)).status === 404, "another tenant cannot download uploaded media");
    const spoof = new FormData(); spoof.append("businessId", String(businessId)); spoof.append("file", new File(["<svg onload='bad'/>"] , "fake.png", { type: "image/png" }));
    check((await a.call("/api/studio/assets", { body: spoof })).status === 400, "spoofed image MIME types and uploaded SVG markup are rejected");
    const bootstrap = await a.ok<{ assets: Array<Record<string, unknown>>; capabilities: { stockConfigured: boolean; videoProcessing: boolean } }>(`/api/studio?businessId=${businessId}`);
    check(bootstrap.assets.every((item) => !("body" in item)), "media list responses never serialize private binary bodies");
    check(!bootstrap.capabilities.videoProcessing, "video rendering is honestly unavailable rather than simulated");
    if (!bootstrap.capabilities.stockConfigured) check((await a.call("/api/studio/stock?q=architecture")).status === 424, "missing stock credentials produce an explicit pending response without fake photos");
    await a.ok("/api/studio", { body: { action: "brand_style", businessId, style: { ...DEFAULT_STYLE, logoAssetId: asset.asset.id } } });
    post = (await a.ok<{ post: PostDTO }>(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "save", version: post.version, document: { ...post.document, title: `Planned studio test ${nonce}`, caption: "A thoughtful piece of draft copy.", primaryMediaId: asset.asset.id } } })).post;
    const graphic = await a.call(`/api/studio/export/${post.id}`);
    check(graphic.status === 200 && (await sharp(graphic.bytes!).metadata()).width === 1080, "saved brand/image context exports a real PNG graphic");
    check((await b.call(`/api/studio/export/${post.id}`)).status === 404, "another tenant cannot export a draft's private graphics");
    post = (await a.ok<{ post: PostDTO }>(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "save", version: post.version, document: { ...post.document, format: "carousel", slides: [{ id: "one", heading: "A first thought", body: "First panel", altText: "First panel", imageAssetId: null }, { id: "two", heading: "A second thought", body: "Second panel", altText: "Second panel", imageAssetId: null }] } } })).post;
    const bundle = await a.call(`/api/studio/export/${post.id}?bundle=1`);
    check(bundle.status === 200 && Boolean(unzipSync(bundle.bytes!)["slide-02.png"]), "carousel bundle contains multiple actual PNG slides");

    await db.insert(s.workspaceMembers).values({ workspaceId: accountA.workspace.id, userId: accountB.user.id, role: "member" });
    await b.ok("/api/auth/switch-workspace", { body: { workspaceId: accountA.workspace.id } });
    check((await b.call(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "approve", version: post.version, acknowledgeFlags: true } })).status === 403, "ordinary members cannot impersonate an approving owner/admin");
    check((await b.call("/api/studio", { body: { action: "brand_style", businessId, style: DEFAULT_STYLE } })).status === 403, "ordinary members cannot change the persisted brand kit");

    if (process.argv.includes("--live-ai")) {
      await a.ok("/api/settings", { body: { primaryProvider: "groq", allowPaidProviders: false } });
      const generated = await a.ok<{ status: string; taskId: number; generationId?: number; providerKey?: string; reason?: string }>("/api/studio/generate", { body: { businessId, postId: post.id, kind: "studio_caption", brief: "Write a short neutral educational introduction to this temporary software test fixture. No statistics, promises, real customer claims, or fabricated research." } });
      console.log(`Live AI outcome: ${JSON.stringify({ status: generated.status, taskId: generated.taskId, generationId: generated.generationId, providerKey: generated.providerKey, reason: generated.reason })}`);
      if (generated.status === "completed" && generated.generationId) {
        const result = await a.ok<{ generations: GenerationDTO[] }>(`/api/studio?businessId=${businessId}`);
        check(result.generations.some((item) => item.id === generated.generationId && item.kind === "studio_caption"), "real live AI output is validated and persisted separately from editor content");
        const before = post.document.caption;
        const current = await a.ok<{ post: PostDTO }>(`/api/studio/posts/${post.id}`);
        check(current.post.document.caption === before, "AI generation does not silently overwrite the saved draft");
        post = (await a.ok<{ post: PostDTO }>(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "apply", version: post.version, generationId: generated.generationId } })).post;
        check(post.document.caption.length > 0 && post.status === "draft", "applying a real AI suggestion creates a new unapproved saved draft version");
        check((await a.call(`/api/studio/posts/${post.id}`, { method: "PATCH", body: { action: "apply", version: post.version, generationId: generated.generationId } })).status === 409, "a generated suggestion cannot be applied twice accidentally");
      } else check(generated.status === "paused", "unavailable live providers pause the task instead of fabricating content");
    }

    if (process.argv.includes("--browser")) {
      browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
      const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
      await page.goto(`${origin}/login`);
      await page.getByLabel("Email address").fill(emailA); await page.getByLabel("Password", { exact: true }).fill(password);
      await page.getByRole("button", { name: "Sign in", exact: true }).click();
      await expect(page.getByRole("button", { name: "Account and workspaces" })).toBeVisible({ timeout: 25000 });
      await page.goto(`${origin}/dashboard/studio?post=${browserPostId}`);
      await expect(page.getByRole("textbox", { name: "Draft title", exact: true })).toBeVisible({ timeout: 20000 });
      const title = `Browser-edited draft ${nonce}`;
      await page.getByRole("textbox", { name: "Draft title", exact: true }).fill(title);
      await page.getByRole("button", { name: "Save draft", exact: true }).click();
      await expect(page.getByText(/Draft saved as version/)).toBeVisible();
      check((await a.ok<{ post: PostDTO }>(`/api/studio/posts/${browserPostId}`)).post.title === title, "browser editor saves genuine changes through the protected API");
      await page.getByRole("button", { name: "Carousel", exact: true }).click();
      await expect(page.getByRole("textbox", { name: "Slide 1 heading", exact: true })).toBeVisible();
      await page.getByRole("button", { name: "Media", exact: true }).click();
      await expect(page.getByText("Your image library", { exact: true })).toBeVisible();
      check(true, "carousel builder and authenticated media library render in the actual browser");
      await page.getByRole("button", { name: "Brand kit", exact: true }).click();
      await expect(page.getByRole("combobox", { name: "Brand logo", exact: true })).toBeVisible();
      await page.getByRole("button", { name: "History", exact: true }).click();
      await expect(page.getByText("The work, preserved.", { exact: true })).toBeVisible();
      check(true, "brand kit and saved revision history are usable in the browser");
      await page.screenshot({ path: "/tmp/phase4-studio.png", fullPage: false });
      let forCalendar = (await a.ok<{ post: PostDTO }>(`/api/studio/posts/${browserPostId}`)).post;
      forCalendar = (await a.ok<{ post: PostDTO }>(`/api/studio/posts/${browserPostId}`, { method: "PATCH", body: { action: "approve", version: forCalendar.version, acknowledgeFlags: true } })).post;
      const planTime = new Date(Date.now() + 86400000);
      await a.ok(`/api/studio/posts/${browserPostId}`, { method: "PATCH", body: { action: "schedule", version: forCalendar.version, wallTime: formatInTimeZone(planTime, "UTC", "yyyy-MM-dd'T'HH:mm"), timeZone: "UTC" } });
      await page.getByRole("link", { name: "Calendar", exact: true }).click();
      await expect(page.getByRole("heading", { name: "Make room for the right moment.", exact: true })).toBeVisible();
      check(true, "the real calendar route loads after Studio navigation");
      await page.getByRole("combobox", { name: "Calendar time zone", exact: true }).selectOption("UTC");
      if (planTime.getUTCMonth() !== new Date().getUTCMonth()) await page.getByRole("button", { name: "Next month", exact: true }).click();
      const savedPlanLink = page.getByRole("link").filter({ hasText: title }).first();
      await expect(savedPlanLink).toBeVisible({ timeout: 15000 });
      check(true, "the actual saved plan is visible as a calendar event in the browser");
      await savedPlanLink.click();
      await expect(page.getByRole("textbox", { name: "Draft title", exact: true })).toHaveValue(title);
      check(true, "a saved calendar event opens its correct authorized Studio draft");
    }
    console.log("Phase 4 checks complete. Tests used temporary data only; no social publishing was attempted.");
  } finally {
    if (browser) await browser.close();
    await cleanupAuthFixtures([emailA, emailB]);
    console.log("Temporary Phase 4 accounts and workspace records removed; existing customer data preserved.");
  }
}
main().catch((error: unknown) => {
  let message = error instanceof Error ? error.message : "Phase 4 test failed";
  for (const key of ["DATABASE_URL", "GEMINI_API_KEY", "GROQ_API_KEY", "TAVILY_API_KEY", "UNSPLASH_ACCESS_KEY"]) { const value = process.env[key]; if (value) message = message.split(value).join("[REDACTED]"); }
  console.error(message.slice(0, 2000)); process.exitCode = 1;
});
