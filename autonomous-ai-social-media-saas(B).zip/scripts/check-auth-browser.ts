import { loadEnvConfig } from "@next/env";
import { chromium, expect, type BrowserContext, type Page } from "@playwright/test";
import { createServer as createHttpServer, request as httpRequest, type Server as HttpServer } from "node:http";
import { createServer as createHttpsServer, type Server as HttpsServer } from "node:https";
import { execFileSync } from "node:child_process";
import { randomBytes, randomUUID } from "node:crypto";
import { mkdtemp, readFile, rm, mkdir } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import type { AddressInfo } from "node:net";
import { cleanupAuthFixtures } from "./auth-test-cleanup";
import { checkBlockedCookieFlows } from "./check-cookie-blocked-flow";

loadEnvConfig(process.cwd(), process.env.NODE_ENV !== "production");

function check(value: unknown, label: string): asserts value {
  if (!value) throw new Error(`FAIL: ${label}`);
  console.log(`PASS: ${label}`);
}

async function listen(server: HttpServer | HttpsServer) {
  await new Promise<void>((resolve, reject) => { server.once("error", reject); server.listen(0, "127.0.0.1", resolve); });
  return (server.address() as AddressInfo).port;
}

async function close(server?: HttpServer | HttpsServer) {
  if (!server) return;
  server.closeAllConnections();
  await new Promise<void>((resolve) => server.close(() => resolve()));
}

async function signIn(page: Page, origin: string, email: string, password: string) {
  await page.goto(`${origin}/login`);
  await page.getByLabel("Email address").fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(page.getByRole("button", { name: "Account and workspaces" })).toBeVisible({ timeout: 20_000 });
}

async function main() {
  if (!process.argv.includes("--run")) {
    console.log("No browser or HTTP tests run. Start the managed preview, then explicitly pass --run.");
    return;
  }
  const appOrigin = new URL(process.argv.find((arg) => arg.startsWith("--base-url="))?.slice(11) || "http://127.0.0.1:3000");
  if (!["localhost", "127.0.0.1"].includes(appOrigin.hostname)) throw new Error("Browser fixture proxy is intentionally restricted to a local managed app server");
  const runId = randomUUID().replace(/-/g, "").slice(0, 18);
  const email = `auth-check-${runId}-a@example.invalid`;
  const secondEmail = `auth-check-${runId}-b@example.invalid`;
  const thirdEmail = `auth-check-${runId}-c@example.invalid`;
  const emails = [email, secondEmail, thirdEmail];
  const password = randomBytes(24).toString("base64url");
  const firstWorkspace = `Browser check ${runId}`;
  const secondWorkspace = `Second browser check ${runId}`;
  const directory = await mkdtemp(join(tmpdir(), "serein-auth-test-"));
  let proxy: HttpsServer | undefined;
  let parent: HttpServer | undefined;
  const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
  const contexts: BrowserContext[] = [];
  const browserErrors: string[] = [];

  try {
    execFileSync("openssl", ["req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", join(directory, "key.pem"), "-out", join(directory, "cert.pem"), "-days", "1", "-subj", "/CN=localhost"], { stdio: "ignore" });
    proxy = createHttpsServer({ key: await readFile(join(directory, "key.pem")), cert: await readFile(join(directory, "cert.pem")) }, (request, response) => {
      // Test-only reverse-proxy fault injection: remove both cookie directions.
      const dropCookies = request.headers["x-serein-test-no-cookies"] === "1";
      const upstreamHeaders: Record<string, string | string[] | undefined> = { ...request.headers, "x-forwarded-host": request.headers.host, "x-forwarded-proto": "https" };
      delete upstreamHeaders["x-serein-test-no-cookies"];
      if (dropCookies) delete upstreamHeaders.cookie;
      const forwarded = httpRequest({
        hostname: appOrigin.hostname, port: appOrigin.port || 3000,
        path: request.url, method: request.method, headers: upstreamHeaders,
      }, (upstream) => {
        const outgoingHeaders = { ...upstream.headers };
        if (dropCookies) delete outgoingHeaders["set-cookie"];
        response.writeHead(upstream.statusCode || 502, outgoingHeaders);
        upstream.pipe(response);
      });
      forwarded.on("error", () => { response.writeHead(502); response.end("Local test proxy failed"); });
      request.pipe(forwarded);
    });
    const port = await listen(proxy);
    const origin = `https://127.0.0.1:${port}`;
    const desktop = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1366, height: 960 } });
    contexts.push(desktop);
    const page = await desktop.newPage();
    page.on("pageerror", (error) => browserErrors.push(error.message));
    console.log(`Browser auth checks started. Signing secret configured: ${Boolean(process.env.AUTH_SECRET)}. Provider APIs will not be called.`);

    await page.goto(`${origin}/register`);
    await page.getByLabel("Your name").fill("Temporary browser diagnostic");
    await page.getByLabel("Email address").fill(email.toUpperCase());
    await page.getByLabel("Password", { exact: true }).fill(password);
    await page.getByLabel("First workspace name").fill(firstWorkspace);
    await page.getByRole("button", { name: "Create account & workspace", exact: true }).click();
    await expect(page.getByRole("button", { name: "Account and workspaces" })).toBeVisible({ timeout: 20_000 });
    check(page.url().endsWith("/dashboard"), "browser registration reaches the authenticated dashboard");
    const initialState = await page.evaluate(async () => (await fetch("/api/auth/me", { cache: "no-store" })).json()) as { user: { email: string }; activeWorkspaceId: number };
    check(initialState.user.email === email, "registration normalizes the email without modifying the password");
    const cookies = await desktop.cookies(origin);
    const initialCookie = cookies.find((cookie) => cookie.name === "serein_session");
    check(initialCookie?.httpOnly && initialCookie.secure && initialCookie.sameSite === "Lax", "top-level HTTPS session cookie is HttpOnly, Secure, and SameSite=Lax");
    check(Boolean(initialCookie?.value.startsWith("s1_")), "session is a random opaque token, not a JWT requiring AUTH_SECRET");

    await page.getByRole("button", { name: "Account and workspaces" }).click();
    await page.getByRole("button", { name: "Sign out", exact: true }).click();
    await expect(page.getByRole("heading", { name: "Sign in to your workspace" })).toBeVisible();
    const revoked = await desktop.request.get(`${origin}/api/auth/me`, { headers: { Cookie: `serein_session=${initialCookie!.value}` } });
    check(revoked.status() === 401, "the logged-out token cannot access the session API");

    await page.getByLabel("Email address").fill(email.toUpperCase());
    await page.getByLabel("Password", { exact: true }).fill("definitely-not-the-test-password");
    await page.getByRole("button", { name: "Sign in", exact: true }).click();
    await expect(page.locator("#auth-error")).toContainText("Email or password is incorrect");
    check(page.url().endsWith("/login"), "wrong password shows a clear error without entering the dashboard");
    await page.getByLabel("Password", { exact: true }).fill(password);
    await page.getByRole("button", { name: "Sign in", exact: true }).click();
    await expect(page.getByRole("button", { name: "Account and workspaces" })).toBeVisible({ timeout: 20_000 });
    check(page.url().endsWith("/dashboard"), "existing account can sign in using a differently capitalized email");

    const rapid = await Promise.all([1, 2].map(() => desktop.request.post(`${origin}/api/auth/login`, { data: { email, password }, headers: { Origin: origin } })));
    check(rapid.every((response) => response.status() === 200), "two rapid sign-ins both succeed without token collisions");
    const tokenHeaders = rapid.map((response) => response.headers()["set-cookie"]?.split(";")[0]);
    check(Boolean(tokenHeaders[0] && tokenHeaders[1] && tokenHeaders[0] !== tokenHeaders[1]), "simultaneous sessions receive different random tokens");
    await page.reload();
    await expect(page.getByRole("button", { name: "Account and workspaces" })).toBeVisible();
    check(true, "session remains authenticated after browser refresh");

    await page.getByRole("button", { name: "Account and workspaces" }).click();
    await page.getByRole("button", { name: "New workspace", exact: true }).click();
    await page.getByLabel("New workspace name").fill(secondWorkspace);
    await page.getByRole("button", { name: "Create workspace", exact: true }).click();
    await expect(page.getByRole("button", { name: "Account and workspaces" })).toContainText(secondWorkspace, { timeout: 20_000 });
    const secondState = await page.evaluate(async () => (await fetch("/api/auth/me", { cache: "no-store" })).json()) as { activeWorkspaceId: number };
    check(secondState.activeWorkspaceId !== initialState.activeWorkspaceId, "workspace creation and switch persist the selected workspace on the server");

    const device = await browser.newContext({ ignoreHTTPSErrors: true }); contexts.push(device);
    const devicePage = await device.newPage();
    await signIn(devicePage, origin, email, password);
    await page.getByRole("button", { name: "Account and workspaces" }).click();
    await page.getByRole("button", { name: `Switch to workspace ${firstWorkspace}`, exact: true }).click();
    await expect(page.getByRole("button", { name: "Account and workspaces" })).toContainText(firstWorkspace, { timeout: 20_000 });
    const switched = await page.evaluate(async () => (await fetch("/api/auth/me", { cache: "no-store" })).json()) as { activeWorkspaceId: number };
    check(switched.activeWorkspaceId === initialState.activeWorkspaceId, "active workspace label matches the persisted workspace after switching");
    check((await device.request.get(`${origin}/api/auth/me`)).status() === 200, "workspace switching does not sign out another browser/device");
    const crossOrigin = await desktop.request.post(`${origin}/api/workspaces`, { data: { name: "must not be created" }, headers: { Origin: "https://untrusted.invalid" } });
    check(crossOrigin.status() === 403, "cross-origin mutation is rejected even with a valid session cookie");
    const providers = await page.evaluate(async () => (await fetch("/api/ai/providers", { cache: "no-store" })).json()) as { providers: Array<{ key: string; configured: boolean }> };
    check(["gemini", "groq", "tavily"].every((key) => providers.providers.some((provider) => provider.key === key && provider.configured)), "Phase 3 provider configuration is accessible after real browser login");

    parent = createHttpServer((_request, response) => {
      response.writeHead(200, { "Content-Type": "text/html" });
      response.end(`<!doctype html><html><body style="margin:0"><iframe id="preview" src="${origin}/login" style="width:100%;height:100vh;border:0" title="Embedded Serein test"></iframe></body></html>`);
    });
    const parentPort = await listen(parent);
    const embedded = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1366, height: 960 } }); contexts.push(embedded);
    const embeddedPage = await embedded.newPage();
    await embeddedPage.goto(`http://localhost:${parentPort}`);
    const frame = embeddedPage.frameLocator("#preview");
    await expect(frame.getByText("You can sign in here", { exact: true })).toBeVisible();
    check(true, "embedded preview explains that opening a new tab is optional");
    await frame.getByText("Need a separate tab? Show the direct Serein address", { exact: true }).click();
    const directField = frame.getByLabel("Direct Serein login URL", { exact: true });
    const directUrl = await directField.inputValue();
    const parsedDirect = new URL(directUrl);
    check(parsedDirect.protocol === "https:" && parsedDirect.pathname === "/login" && !parsedDirect.search && !parsedDirect.hash,
      "direct login URL is absolute and carries no query token or session data");
    const directLink = frame.getByRole("link", { name: "Open Serein login in a new tab", exact: true });
    check(await directLink.getAttribute("href") === directUrl, "new-tab target and copyable app address match exactly");
    let misplacedAuthRequests = 0;
    embedded.on("request", (request) => {
      const url = new URL(request.url());
      if (url.hostname === "editor-wrapper.invalid" && url.pathname.startsWith("/api/auth")) misplacedAuthRequests++;
    });
    await frame.locator("head").evaluate((head) => {
      const base = document.createElement("base");
      base.href = "https://editor-wrapper.invalid/";
      head.prepend(base);
    });
    check(await directLink.getAttribute("href") === directUrl, "an editor base URL cannot rewrite the direct app target");
    await frame.getByRole("button", { name: "Copy direct login URL", exact: true }).click();
    await expect(frame.getByRole("status")).toContainText(/Direct app URL copied|Automatic copy was blocked/);
    check(true, "copy control reports actual clipboard success or an explicit manual-copy fallback");

    // Map only this popup's target to the local managed app for the UI regression.
    // This is not a claim of public gateway permission and does not bypass one.
    if (parsedDirect.origin !== origin) {
      await embedded.route(`${parsedDirect.origin}/**`, async (route) => {
        const target = new URL(route.request().url());
        const upstream = await route.fetch({ url: `${origin}${target.pathname}${target.search}` });
        await route.fulfill({ response: upstream });
      });
    }
    const popupPromise = embedded.waitForEvent("page");
    await directLink.click();
    const directPage = await popupPromise;
    await directPage.waitForLoadState("domcontentloaded");
    await expect(directPage.getByRole("heading", { name: "Sign in to your workspace", exact: true })).toBeVisible({ timeout: 20_000 });
    check(new URL(directPage.url()).origin === parsedDirect.origin, "new-tab click targets the Serein app rather than the simulated editor wrapper");
    await directPage.close();
    await mkdir("test-results", { recursive: true });
    await frame.locator("body").screenshot({ path: "test-results/option-b-preview-help.png" });

    await frame.getByLabel("Email address").fill(email);
    await frame.getByLabel("Password", { exact: true }).fill(password);
    await frame.getByRole("button", { name: "Sign in", exact: true }).click();
    await expect(frame.getByRole("button", { name: "Account and workspaces" })).toBeVisible({ timeout: 20_000 });
    check(misplacedAuthRequests === 0, "inline sign-in and dashboard navigation ignore an editor-injected base URL");
    const partitioned = (await embedded.cookies(origin)).find((cookie) => cookie.name === "serein_session");
    check(partitioned?.sameSite === "None" && partitioned.httpOnly && partitioned.secure && Boolean(partitioned.partitionKey), "cross-site iframe login works with a Secure HttpOnly partitioned session cookie");

    const misrouted = await browser.newContext({ ignoreHTTPSErrors: true }); contexts.push(misrouted);
    let credentialsPostedToMisroutedPreview = 0;
    misrouted.on("request", (request) => {
      if (new URL(request.url()).pathname === "/api/auth/login" && request.method() === "POST") credentialsPostedToMisroutedPreview++;
    });
    // Negative UI test only: simulate the hosting wrapper returning HTML instead of the app probe.
    await misrouted.route("**/api/auth/context", (route) => route.fulfill({ status: 200, contentType: "text/html", body: "<!doctype html><title>Editor wrapper test fixture</title>" }));
    const misroutedPage = await misrouted.newPage();
    await misroutedPage.goto(`${origin}/login`);
    await misroutedPage.getByLabel("Email address").fill(email);
    await misroutedPage.getByLabel("Password", { exact: true }).fill(password);
    await misroutedPage.getByRole("button", { name: "Sign in", exact: true }).click();
    await expect(misroutedPage.locator("#auth-error")).toContainText("hosting preview");
    check(credentialsPostedToMisroutedPreview === 0, "editor HTML is detected before credentials are posted");
    check(misroutedPage.url().endsWith("/login"), "an editor response is never presented as successful sign-in");
    await expect(misroutedPage.getByText("Need a separate tab? Show the direct Serein address", { exact: true })).toBeVisible();

    const mobile = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 390, height: 844 } }); contexts.push(mobile);
    const mobilePage = await mobile.newPage();
    await signIn(mobilePage, origin, email, password);
    await mobilePage.getByRole("button", { name: "Account and workspaces" }).click();
    await expect(mobilePage.getByRole("button", { name: "Sign out", exact: true })).toBeVisible();
    await mobilePage.getByRole("button", { name: "Sign out", exact: true }).click();
    await expect(mobilePage.getByRole("heading", { name: "Sign in to your workspace" })).toBeVisible();
    check(true, "mobile account menu and sign-out are usable");

    const duplicate = await browser.newContext({ ignoreHTTPSErrors: true }); contexts.push(duplicate);
    const duplicatePage = await duplicate.newPage();
    await duplicatePage.goto(`${origin}/register`);
    await duplicatePage.getByLabel("Your name").fill("Another temporary diagnostic");
    await duplicatePage.getByLabel("Email address").fill(secondEmail);
    await duplicatePage.getByLabel("Password", { exact: true }).fill(password);
    await duplicatePage.getByLabel("First workspace name").fill(firstWorkspace);
    await duplicatePage.getByRole("button", { name: "Create account & workspace", exact: true }).click();
    await expect(duplicatePage.getByRole("button", { name: "Account and workspaces" })).toBeVisible({ timeout: 20_000 });
    check(true, "different accounts can use the same workspace display name without slug conflicts");

    const createdBusiness = await desktop.request.post(`${origin}/api/businesses`, { data: { name: `Temporary auth-boundary fixture ${runId}` }, headers: { Origin: origin } });
    check(createdBusiness.status() === 201, "authenticated business creation still works after the session repair");
    const created = await createdBusiness.json() as { business: { id: number } };
    const forbiddenBusiness = await duplicate.request.get(`${origin}/api/businesses/${created.business.id}`);
    check(forbiddenBusiness.status() === 404, "another tenant cannot read the authenticated account's business");
    const forbiddenWrite = await duplicate.request.put(`${origin}/api/businesses/${created.business.id}`, { data: { name: "must not replace the fixture" }, headers: { Origin: origin } });
    check(forbiddenWrite.status() === 404, "another tenant cannot edit the authenticated account's business");
    const anonymous = await browser.newContext({ ignoreHTTPSErrors: true }); contexts.push(anonymous);
    const spoofed = await anonymous.request.get(`${origin}/api/businesses`, { headers: { "x-user-id": "1", "x-workspace-id": String(initialState.activeWorkspaceId) } });
    check(spoofed.status() === 401, "forged identity headers never replace a valid session cookie");

    await checkBlockedCookieFlows({ browser, contexts, origin, parentUrl: `http://localhost:${parentPort}`, existingEmail: email, newEmail: thirdEmail, password, foreignBusinessId: created.business.id });

    const agentPanelColor = await page.locator("div.bg-forest").filter({ has: page.getByRole("heading", { name: "Standing by.", exact: true }) }).first().evaluate((element) => getComputedStyle(element).backgroundColor);
    check(agentPanelColor === "rgb(22, 78, 74)", "forest panels retain their intended background so white text is readable");

    await mkdir("test-results", { recursive: true });
    await page.screenshot({ path: "test-results/authenticated-desktop.png", fullPage: false });
    await mobilePage.screenshot({ path: "test-results/login-mobile.png", fullPage: false });
    check(browserErrors.length === 0, "desktop flow has no uncaught browser page errors");
    console.log("Auth browser checks passed. Test accounts, sessions, and workspaces will now be cleaned up. No AI generation or research credits were consumed by these checks.");
  } finally {
    await Promise.all(contexts.map((context) => context.close().catch(() => {})));
    await browser.close();
    await close(parent); await close(proxy);
    await rm(directory, { recursive: true, force: true });
    await cleanupAuthFixtures(emails);
    console.log("Temporary auth fixtures and local TLS proxy removed; existing customer accounts were preserved.");
  }
}

main().catch((error: unknown) => {
  let message = error instanceof Error ? error.message : "Browser auth check failed";
  for (const key of ["DATABASE_URL", "GEMINI_API_KEY", "GROQ_API_KEY", "TAVILY_API_KEY", "AUTH_SECRET"]) {
    const value = process.env[key]; if (value) message = message.split(value).join("[REDACTED]");
  }
  console.error(message.slice(0, 1800)); process.exitCode = 1;
});
