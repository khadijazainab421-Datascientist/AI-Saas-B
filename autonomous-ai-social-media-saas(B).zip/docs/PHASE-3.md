# Serein — Phase 3: AI and Research Engine

> Historical phase implementation report: provider credentials were absent when this report was written. Subsequent credential configuration, real connection tests, and fixes are documented in `docs/PHASE-3-LIVE-TESTS.md`; the original no-live-test statements below describe the initial delivery, not current runtime status.

> Current authentication update: login now uses random database-backed opaque sessions and no longer requires AUTH_SECRET. The later repair also migrates middleware to Next.js 16 proxy. See `docs/AUTHENTICATION-REPAIR.md` for current configuration and real browser test results; older JWT/signing-secret descriptions below are historical.

## Status at a glance

Phase 3 implements the complete provider-independent architecture, tenant-scoped persistence, brand profiles, website analysis, research, strategy generation, usage tracking, health checks, fallback, quota handling, task pause/resume, and notifications.

**No external provider credential has been supplied. No live AI or research call was tested. No AI output, research source, strategy, or success message was fabricated.** All unconfigured capabilities are displayed as pending.

Phase 2 authentication remains functional via a sandbox-local `AUTH_SECRET` generated for this environment. That value is a local signing key, not a third-party credential, and must be replaced with a securely managed value for any real deployment.

---

## 1. MANDATORY API DISCLOSURE — credentials required for live Phase 3 testing

Under the master prompt's Section 7 rule, I am identifying every external service **before** testing any live integration, and I am waiting for you to provide or configure the credentials. No account, key, developer application, or permission can be created on your behalf.

### 1.1 Google Gemini API — primary free-tier AI candidate

1. **Service needed:** Google Gemini API (generative text for website interpretation and strategy generation).
2. **Why:** It is the default primary provider in the fallback registry and powers `website_analysis` and `strategy_generation` tasks.
3. **Official website:** https://ai.google.dev/ · **Docs:** https://ai.google.dev/gemini-api/docs · https://ai.google.dev/gemini-api/docs/rate-limits · https://aistudio.google.com/
4. **Create an account:** Sign in with a Google account at https://aistudio.google.com/ and accept the Gemini API terms.
5. **Generate a key:** Use **Get API key** in Google AI Studio (creates/selects a Google Cloud project and issues an API key). Keys are managed at https://aistudio.google.com/app/apikey.
6. **Permissions:** The API key itself scopes access to the project's Gemini API. No end-user OAuth scopes are used. Restrict the key to the Generative Language API and to server-side use only.
7. **Where to configure:** `GEMINI_API_KEY` in the server-side `.env` (see `.env.example`). Optional `GEMINI_MODEL` override, default `gemini-2.5-flash`. Never prefix with `NEXT_PUBLIC_`.
8. **Free tier & limitations:** Google documents a free tier with no credit card. Exact RPM/RPD/TPM ceilings are per-project and are shown in the AI Studio rate-limit console rather than a fixed public table; they vary by model and usage tier. Preview/experimental models are more restricted. Free-tier requests are not automatically billed.
9. **Quota exhaustion:** HTTP 429 is returned. In Serein this is classified as `quota`, the provider is placed in a local cooldown, an eligible backup is tried, and if none remain the task is **paused with work preserved and a notification created**. There is no silent loss and no automatic switch to a paid provider.
10. **Alternatives:** Groq (free backup), OpenAI (paid, opt-in only). Official docs consulted during this phase; exact numeric rate limits were not hardcoded because Google publishes them per project.

### 1.2 Groq API — free-tier backup AI candidate

1. **Service needed:** GroqCloud inference API (OpenAI-compatible chat completions).
2. **Why:** Automatic fallback when Gemini is unconfigured, unhealthy, or quota-limited.
3. **Official website:** https://groq.com/ · **Docs:** https://console.groq.com/docs/overview · https://console.groq.com/docs/rate-limits · https://console.groq.com/docs/openai
4. **Create an account:** Sign up at https://console.groq.com/ (free Developer plan).
5. **Generate a key:** Console → **API Keys** → **Create API Key** (`gsk_…`). Copy it immediately.
6. **Permissions:** Bearer-token access to your organization's models. Rate limits are organization-level, not per key or per user. No special OAuth scopes.
7. **Where to configure:** `GROQ_API_KEY` in `.env`; optional `GROQ_MODEL` (default `openai/gpt-oss-20b`, matching the current official rate-limit table; older `llama-3.x` IDs have been retired).
8. **Free tier & limitations:** Free Developer plan, no credit card. Official rate-limit documentation lists per-model RPM/RPD/TPM/TPD ceilings (for example 30 RPM, 1K RPD, 8K TPM, 200K TPD on `openai/gpt-oss-20b`). Model rosters and limits change; the console Limits page is authoritative. Response headers expose `x-ratelimit-remaining-requests`, `x-ratelimit-remaining-tokens`, and `retry-after`.
9. **Quota exhaustion:** HTTP 429 with `retry-after`. Serein honors the header where present, applies a local cooldown, tries the next eligible provider, then pauses and notifies.
10. **Alternatives:** Gemini (free), OpenAI (paid opt-in). A local self-hosted OpenAI-compatible model could also be added through the modular registry.

### 1.3 Tavily Search API — primary free-tier research candidate

1. **Service needed:** Tavily Search (sourced web research for industry topics, trends, and public competitor content).
2. **Why:** The research engine needs legitimate, attributable public sources; it must not invent topics or citations.
3. **Official website:** https://tavily.com/ · **Docs:** https://docs.tavily.com/ · https://docs.tavily.com/documentation/api-reference/endpoint/search · https://docs.tavily.com/documentation/api-credits
4. **Create an account:** Sign up at https://app.tavily.com/ and select the **Researcher** plan.
5. **Generate a key:** Tavily dashboard → API Keys (`tvly-…`). The `GET /usage` endpoint is free and is used for health/quota inspection.
6. **Permissions:** Bearer token (`Authorization: Bearer …`) on `POST https://api.tavily.com/search`. No user OAuth. Restrict the key to server-side calls.
7. **Where to configure:** `TAVILY_API_KEY` in `.env`.
8. **Free tier & limitations:** Official credits documentation: Researcher = **1,000 credits/month, $0, no credit card**. Basic Search costs **1 credit**; Advanced Search costs **2 credits**; Extract costs 1 credit per 5 successful URLs; Research tasks are dynamically priced (mini 4–110, pro 15–250 credits). Serein uses **basic Search only** and never invokes Research/advanced endpoints by default, so a single pro-level charge cannot be created by this integration.
9. **Quota exhaustion:** 429 / credit exhaustion. Serein records the failure, tries an eligible fallback, and otherwise pauses the run with an explicit reason — it never fabricates sources. Pay-as-you-go overage is **not** enabled automatically and requires explicit paid authorization.
10. **Alternatives:** Brave Search (metered, paid-eligible only), a self-hosted search index, or direct public-page extraction.

### 1.4 Brave Search API — metered, paid-eligible only (NOT recommended for free-first)

1. **Service needed:** Brave Web Search API as a potential research fallback.
2. **Why:** Independent web index; useful if Tavily is exhausted and you explicitly authorize paid/metered usage.
3. **Official website:** https://brave.com/search/api/ · **Docs:** https://api-dashboard.search.brave.com/documentation/ · pricing page on the same dashboard.
4. **Create an account:** Sign up at https://api-dashboard.search.brave.com/ and create a subscription key.
5. **Generate a key:** Dashboard → API keys (`X-Subscription-Token`).
6. **Permissions:** Subscription token on `GET https://api.search.brave.com/res/v1/web/search`. Requires acceptance of the API terms; attribution rules may apply to retain credits.
7. **Where to configure:** `BRAVE_API_KEY` in `.env`.
8. **Free tier & limitations:** **Conflicting public information.** Several current sources report the no-card free tier (2,000 queries/month) was retired in February 2026 and replaced with metered billing plus roughly $5 in recurring monthly credits, requiring a payment method and potentially billing overages with no default spend cap. Official pricing must be re-verified in the dashboard before use.
9. **Quota exhaustion / financial risk:** Because a card may be charged automatically, Serein classifies Brave as **paid**. It is excluded from all automatic fallback and from task resumption unless `allowPaidProviders` is explicitly enabled by a workspace owner/admin. No free health probe is performed.
10. **Alternatives:** Tavily (free Researcher), SearXNG self-hosted, or direct public-page extraction.

### 1.5 OpenAI API — optional paid AI provider, opt-in only

1. **Service needed:** OpenAI Chat Completions.
2. **Why:** Demonstrates that paid providers can be added without rewriting the application and without accidental charges.
3. **Official website:** https://platform.openai.com/ · **Docs:** https://platform.openai.com/docs/api-reference/chat
4. **Create an account:** https://platform.openai.com/signup, then set up billing.
5. **Generate a key:** Dashboard → API keys (`sk-…`), with a project-scoped key and a spend limit.
6. **Permissions:** Bearer token on `POST /v1/chat/completions`; project-level billing permissions.
7. **Where to configure:** `OPENAI_API_KEY`, optional `OPENAI_MODEL` (default `gpt-4o-mini`).
8. **Free tier & limitations:** No generally available free API tier; usage is billed per token. Set an explicit monthly spend cap in the provider dashboard.
9. **Quota exhaustion:** 429 / insufficient credit is classified as quota; no automatic charge escalation is performed by Serein.
10. **Alternatives:** Gemini and Groq free tiers.

### 1.6 Non-external configuration

- `DATABASE_URL` — already configured by the sandbox for local PostgreSQL.
- `AUTH_SECRET` — local JWT signing key. Generate with `openssl rand -base64 32`. No external account. A sandbox-local value was generated so Phase 2 login/registration remains functional; replace it for any real deployment.

**I am waiting for you to provide/configure the provider credentials before any live integration test.** The Integration Center and AI Engine currently report them as not configured.

---

## 2. Features implemented

### Provider-independent AI layer
- `src/lib/ai/types.ts` — provider contracts, error taxonomy, attempt records.
- `src/lib/ai/providers.ts` — real REST adapters: Gemini native `generateContent`, Groq and OpenAI chat completions, Tavily Search, Brave Web Search, plus model-list/usage health probes.
- `src/lib/ai/orchestrator.ts` — seeded provider registry, primary/backup ordering, eligibility rules, health checks, quota cooldowns, daily workspace limits, usage events, automatic fallback, explicit paid gating, task pause with preserved partial work, notifications, and resumable tasks.
- Required behaviour mapping:
  1. Primary attempted first ✔
  2. Quota/availability failure → eligible backup ✔
  3. Continue with another provider ✔
  4. All eligible free providers unavailable → pause ✔
  5. Resume when available (manual or eligibility re-check) ✔
  6. User notification ✔
  7. Raw output and attempt log preserved before validation ✔
  8. Paid provider never used without `allowPaidProviders` ✔
- Modular: adding a provider requires one registry entry, not application rewrites.

### Research engine
- `src/lib/research/website.ts` — deterministic HTML extraction (title, meta, headings, text) with public-URL validation, private-host blocking, disabled redirects, timeouts, and size limits.
- `src/lib/research/engine.ts` — Tavily-first research with source provenance, credit accounting, explicit paid gating, and honest paused states; website extraction always works without credentials, with AI interpretation reported separately.

### Brand profiles, strategy, safety
- Tenant-scoped brand profile persistence (tone, voice, vocabulary, audience, objectives, claims policy, restricted topics, style examples).
- `src/lib/strategy/generate.ts` — builds evidence-bounded prompts from user-provided and actual extracted/sourced data only; forbids invented claims, statistics, competitors, and trends.
- `src/lib/strategy/parse.ts` — strict structured-JSON validation, versioned draft strategies, deterministic review flags for superlatives, guarantees, health/regulated claims, performance figures, and restricted topics. Invalid output is preserved and paused, never presented as valid.

### Data model (all workspace-scoped)
`workspace_settings`, `ai_provider_states`, `ai_usage_events`, `ai_tasks`, `notifications`, `brand_profiles`, `website_analyses`, `research_runs`, `research_sources`, `content_strategies`. Provider credentials are **never** stored in the DB; only environment-variable names are shown in the UI.

### API routes
`/api/settings`, `/api/ai/providers` (GET/POST health), `/api/ai/usage`, `/api/agent/tasks` (GET/POST resume), `/api/notifications`, `/api/brand-profiles`, `/api/analysis/website`, `/api/research`, `/api/strategy`, plus hardened Phase 2 routes: `/api/businesses`, `/api/businesses/[id]`, `/api/workspaces`, `/api/auth/me`.

### Interface
- `/dashboard/ai` — provider registry, health checks, paid authorization, primary provider selection, usage, tasks with resume, notifications, and a clear "credentials pending" state.
- `/dashboard/strategy` — business selector, brand profile editor, website analysis, research with linked sources, and strategy drafts with review flags.
- `/dashboard/businesses` — working create/list business manager.
- Overview, sidebar, landing page, and FAQ copy updated to the Phase 3 state.

---

## 3. Security decisions

- Every Phase 3 API route calls `requireTenant()`, which validates the JWT signature, DB session record, expiry/revocation, active workspace, and membership **directly from the request cookie**. It does not trust middleware headers.
- **Phase 2 defect fixed:** `middleware.ts` previously set *response* headers (`x-user-id`, etc.) rather than *request* headers, so downstream handlers could not read them. It now uses `NextResponse.next({ request: { headers } })` and overwrites any client-supplied values. The affected Phase 2 routes were also rewritten to use `requireTenant()` as defense in depth.
- Paid-provider authorization is restricted to workspace owners/admins.
- SSRF protection blocks loopback/private/link-local/metadata hosts and disables redirects; DNS rebinding still requires an egress proxy in production (disclosed in the UI).
- No secret is exposed to the browser; provider keys are read only in server modules.

---

## 4. Validation performed

| Check | Command | Result |
|-------|---------|--------|
| Schema push | `npx drizzle-kit push` | See completion report |
| TypeScript | `npm exec tsc -- --noEmit` | See completion report |
| Route typegen | `npx next typegen` | See completion report |
| Production build | `npm run build` | See completion report |
| Startup + `/api/health` | `build_and_start` | See completion report |

Live provider calls were **not** tested because no credentials were supplied.

## 5. Known limitations

- No live provider integration has been tested; adapters are structurally complete but unverified against live accounts.
- Quota tracking is partly local: Groq/Tavily expose quota information, Gemini's exact ceilings are project-specific, so Serein uses 429 detection plus a conservative local cooldown.
- Website extraction uses regex-based HTML parsing, not a full DOM parser; complex SPA-only sites may return little text.
- Claim detection is a deterministic first-pass regex, not a compliance guarantee.
- Task resumption is explicit (`/api/agent/tasks`), not a background cron worker; scheduled workers arrive in Phase 6.
- No content generation studio, calendar events, social OAuth, publishing, analytics ingestion, or billing in this phase.
- `middleware.ts` still emits a Next.js 16 deprecation warning recommending the `proxy` convention.
- npm audit findings from the inherited dependency graph remain unresolved.
- Automated tenant-isolation and auth test suites are scheduled for Phase 8.

## 6. Review instructions

1. Register/sign in, then create a business under **Businesses**.
2. Open **Strategy**, fill and save a brand profile, and try a public website URL — extraction should work without any API key, with AI interpretation reported as pending.
3. Try a research query — it should pause with an explicit credential reason and create no sources.
4. Try generating a strategy — the task should pause, preserve work, and produce a notification.
5. Open **AI Engine** — verify all providers show "not configured", run health checks, inspect the paid authorization control, and try resuming a paused task.
6. Confirm no dashboard screen shows invented metrics, sources, or strategies.
7. To enable live testing, add the keys described in Section 1 to `.env`, then tell me which providers you have configured. I will not test a live integration until you do.

## 7. Next phase gate

**Phase 4 has NOT started.** It requires your explicit approval. Phase 4 will require its own media/API credential disclosure before any live integration test.
