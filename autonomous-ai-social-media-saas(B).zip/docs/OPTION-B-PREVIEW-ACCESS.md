# Option B only — Editor/new-tab preview routing repair

> Follow-up: when the browser/proxy cannot retain any cookie, Option B now has a verified memory-only preview-session recovery path. See `docs/OPTION-B-COOKIE-PERSISTENCE.md` for its 30-minute lifetime, no-storage behavior, server authorization boundaries, and blocked-cookie tests. The new-tab link is not required for that path.

## Scope

The user reported that the login page's new-tab link opened the Arena editor instead of the Serein login. Work in this follow-up is limited to Option B preview/auth navigation and its tests. Option A, AI/research functionality, provider credentials, database schema, and existing customer records were not changed.

A private source backup of the affected preview/auth files was saved before editing. Environment files and customer records are not included in it.

## Findings

1. The original external-tab link was the relative `/login` or `/register`. A wrapped preview or injected document base can resolve a relative link against the editor instead of the app.
2. Opening a separate tab is not required to submit the existing login form, but the old informational banner made it appear to be a prerequisite.
3. Relative auth fetch/navigation also needed to ignore an editor-injected document base.
4. The current sandbox's port-specific public app origin was verified against the managed preview URL and the official E2B public-URL documentation.
5. A direct unauthenticated sandbox request to the public preview gateway received HTTP 403 without the application marker. The managed app's local routing endpoint returned HTTP 200 with the Serein marker. This is a hosting-gateway boundary, not proof of an incorrect Serein password. No gateway token was read, disclosed, added to a URL, or bypassed.

## Changes

### Clear in-preview login instructions

- The banner now says **You can sign in here** and explicitly makes the new tab optional.
- The user can enter the existing Serein email/password in the same form and choose **Sign in**.
- Separate-tab assistance is collapsed under an optional disclosure rather than presented as a required action.

### Correct, public-only standalone targets

- `src/lib/preview-origin.ts` resolves a safe absolute public app origin from an explicit server configuration, current sandbox metadata, or validated incoming host information.
- Login/register pages are dynamically rendered so a newly started sandbox does not reuse an old sandbox's address from a static build.
- Links use full absolute Serein URLs, not the editor-relative `/login` path.
- A read-only direct address and copy control are available. Clipboard success is shown only after the actual write succeeds; if blocked, the address is selected for manual copy with an accurate message.
- No session identifiers, API keys, traffic access tokens, parent-editor query strings, or credentials are included in copied addresses.
- `APP_PUBLIC_ORIGIN` is an optional **non-secret** deployment origin override. It was not required or configured for this sandbox, whose address is derived from current runtime metadata. No new API key is needed.

### Routing-aware auth, without weakening authentication

- Auth requests and post-auth navigation are resolved against the frame's own `window.location.origin`, never `document.baseURI`.
- `GET /api/auth/context` is a public, no-store routing probe returning only an application marker and public origin. It grants no authenticated access and returns no user, session, workspace, or provider data.
- Before a login/registration credential POST, the client verifies that the route reaches Serein. Editor HTML, redirects, malformed/non-JSON responses, and unexpected app markers produce a clear preview-routing error rather than a simulated sign-in.
- Session verification still follows the password POST. Existing database session, expiry/revocation, membership, CSRF/origin, and tenant-isolation checks remain in place.
- Account/workspace post-actions use the same frame-origin-safe navigation helper.
- No token was moved into local storage or query strings. No auth bypass, fake account, fixed password, automatic sign-in, or permissive CORS rule was added.

## Files

- `src/lib/preview-origin.ts`
- `src/app/api/auth/context/route.ts`
- `src/components/auth/preview-access-help.tsx`
- `src/components/auth/auth-form.tsx`
- `src/app/login/page.tsx`, `src/app/register/page.tsx`
- `src/lib/auth-client.ts`
- `src/components/dashboard/dashboard-shell.tsx` (only the account/workspace navigation calls)
- `scripts/check-preview-origin.ts`
- `scripts/check-auth-browser.ts`

## Actual test results

### Origin tests: 11 passed

Validated explicit-origin priority, current sandbox host convention, exact match with the platform-managed Option B preview origin, local-development origins, and rejection of script URLs, embedded credentials, session/query strings, malformed sandbox IDs, malformed forwarded hosts, and insecure remote fallbacks.

These are local pure-function checks and make no external request or database mutation.

### Browser regression suite: 33 passed

The prior 24 authentication/workspace/tenant checks passed again, together with the new preview-specific coverage:

- In-preview guidance makes a new tab optional.
- Direct login address is absolute, query-free, and identical to the external-tab target.
- Injecting a different editor `<base>` does not rewrite the link.
- Clipboard control reports real success or an explicit manual-copy fallback.
- A new-tab click targets the app origin instead of the simulated editor.
- Inline sign-in and dashboard navigation work with an editor-injected document base.
- A test-only editor-HTML response is detected before credentials are posted.
- That editor response is not reported as successful authentication.
- Partitioned embedded-preview cookies, desktop/mobile login, logout/revocation, refresh persistence, rapid logins, workspace switching, independent device sessions, tenant read/edit protection, and rejection of forged identity headers remain verified.

Browser tests use a temporary local HTTPS proxy and a separate parent origin. The popup target is mapped locally to the real managed app for a UI routing regression; **this does not establish that the public hosting gateway permits standalone access**. The negative HTML fixture exists only inside the test harness, never production behavior.

No AI generation, research, paid provider, or publishing request was made. Existing configured provider presence was read only through the authenticated metadata API.

Temporary diagnostic accounts/workspaces/business fixtures and test TLS proxies were removed. Final aggregate verification found **1 existing account, 1 existing workspace, and 0 temporary auth fixtures**. No customer password or API-key value was displayed.

## User review steps

1. Refresh the current **Option B** preview so it loads the updated form.
2. Stay in that preview; do not click the separate-tab link as a required login step.
3. Enter the existing **Serein signup email** and password in **Email address** / **Password**.
4. Choose the large **Sign in** button.
5. After the dashboard opens, test AI Engine/Strategy as normal. Do not create the account/workspace again.
6. The optional direct address is available under **Need a separate tab?**. If the editor or a platform access page still appears, that standalone gateway path requires hosting permission; a copied URL is not an authorization bypass.

## Limits and status

- The platform's public gateway settings are outside this application's code. No claim is made that a protected standalone URL is publicly unlocked.
- Actual Arena parent-page internals are not accessible from this sandbox; the wrapper/base-URL failure is covered by a local cross-origin browser regression.
- Chromium desktop/mobile-viewport and embedded tests were run; no universal Safari/Firefox/device compatibility claim is made.
- No database schema or provider configuration change was made, and no new product phase was started.
- Required Next.js type generation, TypeScript no-emit, production build, and final managed startup/healthcheck are run after these changes; the completion response records their final status.

## Official references

- https://docs.e2b.dev/network/public-url
- https://developer.mozilla.org/en-US/docs/Web/HTML/Element/base
- https://nextjs.org/docs/app/api-reference/functions/headers
