# Phase 3 — Credential configuration and real integration tests

> Subsequent authentication repair: current login uses database-backed opaque sessions without AUTH_SECRET, and the deprecated middleware convention has been replaced with proxy. See `docs/AUTHENTICATION-REPAIR.md` for current browser tests and secret-file instructions. The provider outcomes below remain historical observations, not new availability claims.

## Scope and date

Tested on 2026-11-11 after the user configured Gemini, Groq, and Tavily keys. This continues Phase 3 verification only; Phase 4 has not started. No secret value, session cookie, or generated strategy body is included in this report.

## Actual outcomes

| Provider / operation | Observed result | What this establishes |
| --- | --- | --- |
| Gemini model-list probe | Accepted | The server can authenticate to the model-list endpoint. This is not proof of generation availability. |
| Original Gemini `gemini-2.5-flash` completion | HTTP 404: unavailable to new users | A real compatibility defect was identified, not a key failure. |
| Updated Gemini `gemini-3.8-flash` completion | HTTP 503: high demand | The current model was temporarily unavailable. No successful Gemini generation is claimed. |
| Gemini during authenticated strategy task | Request timed out after approximately 45 seconds | Actual primary-provider interruption was handled by fallback. Token consumption on a timed-out request is not known from the application response. |
| Groq `openai/gpt-oss-20b` completion | Returned valid structured JSON | Actual generation, not just a health probe, was verified. |
| Groq as strategy fallback | Produced a validated persisted strategy draft | Actual Gemini-to-Groq fallback, draft persistence, preserved attempt history, and usage events were verified. |
| Tavily usage probe | Accepted | Credential/usage endpoint access was verified. |
| Tavily basic Search | Returned real sources from `nextjs.org` | A real search request was made; source titles and URLs were validated structurally. This is not independent fact-checking of source content. |
| Tavily in authenticated research workflow | Completed with sources saved to the selected business | Real research persistence/provenance was verified. |

Two Tavily basic searches were made across the standalone diagnostic and the authenticated smoke test. The documented cost is one credit per basic search. No Advanced Search, Research, Extract, Map, Crawl, OpenAI, or Brave operation was invoked by these tests. Provider dashboards remain authoritative for actual billing and quota usage.

## Compatibility and configuration fixes

- Default Gemini model updated to `gemini-3.8-flash`; `GEMINI_MODEL` remains an optional server-side override. The official model documentation and the specific free-tier pricing section were checked before changing the default.
- Existing `generateContent` compatibility was verified from Google's official API reference; the adapter does not silently switch to a paid model.
- Missing sandbox `AUTH_SECRET` restored with a random local signing key in the private `.env.local`, without replacing provider keys or database settings. A pre-existing browser session may require signing in again.
- `.env.example` updated to the current model and the correct Groq Free Plan terminology; it contains no real secrets.
- Integration Center now reports runtime key presence instead of hardcoded credential-pending text. Key presence is explicitly distinguished from successful health probes and generation.
- AI Engine health summaries count configured providers separately from unconfigured optional providers; successful messages no longer render as errors.
- Research reads and strategy context now scope source records to the selected business as well as its workspace. Research POST rejects a foreign business ID before any external request.
- Brand fields reset when switching to a business without a saved brand profile. Style examples retain their line boundaries. Website analysis submits the saved website when the URL field displays that default.

## Authenticated HTTP smoke checks

The managed production server was exercised through its local loopback address. The public preview gateway returned HTTP 403 to an automated sandbox request, while local `/api/health` returned 200. No gateway access control was bypassed or disabled.

Verified:

1. Production health response.
2. Registration creates a real user, workspace, membership, and session cookie.
3. Protected `/api/auth/me` lookup recognizes the new session.
4. Workspace owner membership is persisted.
5. Business creation persists inside the active workspace.
6. Brand profile creation persists for the selected business.
7. All three keys are visible to the production runtime; their actual values are absent from provider API responses.
8. Paid-provider authorization defaults to false.
9. Real Tavily research completes and stores attributed sources.
10. Strategy task records Gemini failure followed by Groq success.
11. Structured output is validated and persisted as `draft` or `needs_review`, never published.
12. Task history retains the partial/output record and attempt log.
13. Actual usage events are recorded without a paid-only provider.
14. Another business in the same workspace does not inherit the first business's research sources.
15. A second tenant cannot read the first tenant's business (404).
16. A second tenant cannot start research for a foreign business (404 before provider use).
17. Spoofed identity headers without a valid session receive 401.
18. Logout removes authenticated access (subsequent `/api/auth/me` returns 401).

All above smoke assertions passed. Two clearly marked temporary test accounts, their workspaces, business fixtures, and associated tenant-scoped test records were deleted in `finally`. No customer records were deleted. Provider-level counters reflect real calls; standalone diagnostic calls are not inserted into a user's workspace usage history. Provider dashboards still include all real calls.

## Reusable diagnostics

- `scripts/check-providers.ts` uses the application's existing adapters. By default it makes no external calls; explicit `--live` is required. An optional `--provider=gemini`, `--provider=groq`, or `--provider=tavily` limits a retest. It does not access customer business data or create DB fixtures.
- `scripts/check-phase3-flow.ts` requires both `--live` and an explicit managed `--base-url`. It creates temporary diagnostic records, runs the authenticated workflow, and removes its records in `finally`.
- `tsx` is a local open-source runner added to execute the TypeScript diagnostic scripts. It requires no hosted service, key, credit card, or usage subscription. A compiled Node test harness is an alternative.
- Diagnostic scripts are not API routes and are not executed by the application build or when a dashboard is opened.

## How to review through the UI

1. Open the latest preview and sign in or register. If an old session is rejected, sign in again.
2. Go to **AI Engine** and select **Run health checks**. Gemini, Groq, and Tavily should be counted as configured; OpenAI and Brave may remain unconfigured. A green credential probe alone does not prove that a model can generate.
3. Keep **Allow paid providers** switched off.
4. Under **Businesses**, create a real business profile.
5. Under **Strategy → Brand profile**, save the brand's voice and boundaries.
6. Under **Strategy → Research**, run one specific query; inspect the returned source links.
7. Under **Strategy → Strategy**, request one draft. While Gemini is unavailable, an eligible Groq backup can complete it. Allow time for the primary request timeout before expecting fallback.
8. Inspect **AI Engine → Agent tasks** and **Usage tracking** for the actual operation record. If all eligible providers are unavailable, expect a paused task and a notification, not a fabricated result.

For testing with the Gemini free tier, use public/non-confidential information. Google's free-tier data-use terms differ from its paid-tier terms.

## Limitations and boundaries

- Successful Gemini generation remains unverified because the tested requests received 503/timeout. The key was accepted, and real Groq fallback succeeded; these are separate observations.
- These were live adapter and HTTP smoke checks, not automated visual/browser interaction tests or a full concurrency, authorization, compliance, or security audit.
- Background automatic task resumption, social OAuth/publishing, content studio, verified social analytics, and billing remain in their designated later phases.
- The inherited npm audit findings and Next.js middleware convention deprecation remain unresolved; this report is not a production-readiness declaration.
- No live quota-exhaustion stress test was performed deliberately, and no user quota was intentionally exhausted.

## Final build checks

After the documented changes, the required Next.js type generation, TypeScript no-emit check, production build, and managed startup/healthcheck are run again. Their final result is stated in the turn's completion response; live provider availability is not substituted for a build result.

## Official references checked

- https://ai.google.dev/api/generate-content
- https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash.md.txt
- https://ai.google.dev/gemini-api/docs/pricing.md.txt (Gemini 3.8 Flash section)
- https://console.groq.com/docs/text-chat
- https://docs.tavily.com/documentation/api-reference/endpoint/search
