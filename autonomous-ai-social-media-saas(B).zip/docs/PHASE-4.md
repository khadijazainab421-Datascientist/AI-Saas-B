# Phase 4 — Content Creation Studio

## Status and phase gate

**Core implementation available.** Phase 4 now has real saved drafts, editing/history, AI content suggestions, private uploaded images, branded PNG/slide-bundle exports, editorial approval, and calendar planning.

The following are explicitly **not** represented as complete:

- User-reported actual hosted-preview login acceptance remains unresolved/deferred at the user's request. See AUTH-001 in `docs/KNOWN-ISSUES.md`.
- Live stock-photo search/selection awaits `UNSPLASH_ACCESS_KEY` and real provider testing.
- Video scripts/storyboards are supported; movie generation/encoding/transcoding is not implemented/configured.
- Social OAuth/publishing, publishing workers, verified social analytics and billing are later phases.

**Phase 5 has not started.** Explicit approval is required before that phase and its individual social developer-app/permissions disclosures.

## Features implemented

### Saved content operations

- Business/workspace-scoped drafts with title, format, target channels, creative brief, base caption, per-channel caption adaptations, hashtags, carousel slides/alt text/image selections, video script, and primary image.
- Explicit save with optimistic version checks. A stale editor receives HTTP 409 rather than overwriting newer data.
- Versioned revision history and restore. Restoring creates a fresh draft; it does not resurrect an old approval or schedule.
- Archive rather than destructive draft deletion.
- Unsaved-change indicators and an editor leave warning.
- No sample customer businesses, posts, media library items, calendar entries, or performance numbers are seeded.

### AI creation through the existing provider layer

- Task kinds: `studio_ideas`, `studio_caption`, `studio_carousel`, `studio_video_script`.
- Prompts use the selected business/brand, its own saved strategy, extracted website text, stored research sources and the user's saved brief.
- Structured outputs are validated before a Studio generation is claimed. Unknown/invented media IDs/URLs are not accepted as carousel asset references.
- AI output is stored as a separate suggestion. The editor is not overwritten automatically.
- Explicit Apply creates a new, unapproved saved draft version and cannot apply the same suggestion twice.
- Existing primary/backup eligibility, paid-use authorization, usage accounting, task pause/resume and notifications are reused.
- Validation failures hold the task and preserve raw output instead of claiming a valid caption/carousel.
- A preservation gap discovered during integration was repaired: paused/resumed/error snapshots retain earlier raw outputs and append output history instead of replacing it with an attempt-only record. Existing partial metadata is also retained. Task workspace is checked before resuming.
- Claim/restricted-topic checks are first-pass heuristics, not factual/legal-compliance certification. Human acknowledgement is not automatic verification.

### Media and brand assets

- JPG/PNG/WebP image uploads, capped at 5 MiB original input.
- Bounded upload reads, magic-byte checks, actual image decode, 24-million-pixel decode limit, resize to fit 1800 pixels, EXIF/metadata removal and WebP normalization.
- Private bytes stored in PostgreSQL `bytea`, isolated behind authenticated asset endpoints. Metadata lists do not serialize binary bodies.
- Browser previews obtain protected images through the shared authenticated API transport and revocable Blob URLs, not session tokens in image URLs.
- Brand kit: background/foreground/accent colors, editorial/modern template style and an uploaded logo. Persisted brand-kit changes require owner/admin role.
- Colors are validated; SVG template text is XML-escaped; uploaded SVG/scripts are not accepted as image uploads.
- User uploads remain user-supplied content: the system does not claim independently verified image rights.

### Real local visual exports

- Deterministic branded SVG/Sharp rendering to real 1080×1080 PNG files.
- Carousel builder with editable slide heading/body/alt text, image selection, reorder and removal.
- ZIP slide bundle with actual PNG files, base caption text and complete draft JSON.
- A local template render is not marketed as AI image generation. No image-generation API provider or paid raster-generation fallback was selected.
- Long content can wrap/truncate visually with an ellipsis; the saved draft and bundled JSON preserve complete text. Template/server font metrics may differ from a native social application.
- Linked stock assets remain hotlinked. Local PNG export currently asks the user to remove a linked stock background or use an uploaded, licensed image rather than silently caching/rehosting the stock photo.

### Review and calendar

- Request-review and human approve actions.
- Only owners/admins can approve or schedule; member-role denial is enforced server-side, not only by disabled UI controls.
- Claim/sensitive-topic flags require explicit acknowledgement before approval and are recorded in revision history.
- Editing/restoring/applying content clears its prior approval and schedule.
- Scheduling validates a future wall time plus IANA time zone, stores the UTC instant and original zone, and rejects nonexistent/ambiguous DST times.
- Calendar reads actual scheduled rows with month navigation, business filter, display time zone and event-to-draft links.
- Scheduling responses explicitly say `publishingEnabled: false`. No platform account is connected and no worker dispatches a post in this phase.
- Approval is editorial. Before future publication, platform eligibility, exact final media, changed brand policy and rendered-version snapshots must be revalidated by the publishing pipeline.

## External API discovery — complete Phase 4 disclosure

### Selected optional provider: Unsplash public photo API

1. **What:** stock-photo search and linked-photo selection, not AI image generation.
2. **Why:** supplies legitimate stock-photo results with author/source provenance when the user chooses to configure it.
3. **Official website/docs:** https://unsplash.com/developers · https://unsplash.com/documentation · https://unsplash.com/oauth/applications · https://help.unsplash.com/en/articles/3887917-when-should-i-apply-for-a-higher-rate-limit
4. **Account/application setup:** create/sign in to an Unsplash account, open Your Apps, choose New Application, accept the API guidelines, provide an accurate app name/description.
5. **Credential:** copy the app's **Access Key**. The OAuth **Secret Key** is not required by this public-search integration.
6. **Permissions/authentication:** public API requests use `Authorization: Client-ID …` server-side and `Accept-Version: v1`. No user OAuth, private collections or write-user scopes are requested.
7. **Where:** server-side `UNSPLASH_ACCESS_KEY` in private `.env.local` or the hosting environment. An empty field was prepared without replacing existing secrets; `.env.example` has names only. Never use `NEXT_PUBLIC_` or frontend source for the key.
8. **Free access and limits:** official docs describe Demo mode at **50 JSON requests/hour** and **1,000/hour after production approval**. Image CDN loads do not count as JSON requests. Demo is for development/testing; public/large-company use should request production approval. No unlimited claim is made. The retrieved official documentation did not explicitly settle credit-card requirements; do not enter a paid/billing flow without review.
9. **Quota failure/terms:** API rate/access failures produce an explicit error, not synthetic photos or a paid fallback. Hotlink the API-provided image URL, preserve its `ixid`, credit the photographer and Unsplash with referral links, and call required download tracking when selecting a photo for the creation workflow. The implementation preserves those structures.
10. **Alternative/verification gate:** upload your own licensed media and use local branded templates with no stock API key. **No live Unsplash call was tested because no key was supplied. Wait for user configuration before claiming a working live stock integration.**

### Pexels comparison — not selected as a new-key dependency

- Official API homepage: https://www.pexels.com/api/ currently says **new API key issuance is paused** (verified through the official indexed page).
- Official help results describe existing default limits of 200/hour and 20,000/month; requests for higher limits are separately restricted/paused.
- Some older docs still say keys are issued instantly; do not rely on that stale instruction.
- It was not selected for the initial Studio adapter, and no live Pexels connection/test is claimed.
- Direct API/license-page fetches were unavailable in this environment; no stronger licensing claim was inferred from that.

### Existing AI/research providers

Gemini/Groq/Tavily remain the already configured Phase 3 services. No additional AI credential was acquired or hardcoded. Only one live Phase 4 caption task was exercised; its temporary workspace had Groq primary and paid providers disabled. It did not make a new Tavily research request or a stock-photo API request. Free-tier privacy/data-use terms still apply; the UI warns against putting secrets/confidential client data into AI briefs.

### Video, storage, billing

- No FFmpeg executable/worker pipeline was available/configured, so no video-rendering credential was needed and no rendered video is claimed. The Playwright tool's internal test FFmpeg download is not the product's encoder pipeline.
- Small private image persistence uses the already configured PostgreSQL database; no R2/S3 account/key was required in this phase. Large-scale object storage is future hardening, not secretly substituted by a fake integration.
- No payment key, Meta app, LinkedIn app, social password, or publishing permission was required or requested in Phase 4.

## Service/package choices and costs

| Dependency | Purpose | Cost/card/quota | Alternative/limitations |
| --- | --- | --- | --- |
| Zod | API and AI-output validation | Open-source local library; no account/card/hosted quota | Manual validators, with more error-prone duplication |
| date-fns + date-fns-tz | UTC/IANA conversion and display | Open-source local libraries; no card/service quota; uses Intl data | Temporal/polyfill or manual Intl offset logic |
| Sharp/libvips | Image validation/normalization and actual PNG rendering | Local open-source processing, no API key/card; server CPU/memory/host quotas still apply | Canvas/image-service worker; native binary support must be available |
| fflate | ZIP slide bundles | Local open-source library, no card/account/quota | Native archive tooling or individual file downloads |
| PostgreSQL bytea | Small private file store | Existing DB infrastructure, not an unlimited storage service | Object-storage adapter is recommended before larger media/video scale |
| Unsplash | Optional stock API | Demo/production limits above, guidelines and approval apply | Manual uploads/local templates; live key pending |

Libraries are not billed providers. This does not mean hosting CPU, bandwidth or database storage is free/unlimited on every deployment.

## Database and modules

Added tables/indexes:

- `media_assets`
- `studio_brand_styles`
- `content_posts`
- `content_revisions`
- `studio_generations`

Workspace/business deletion cascades are scoped to those parents; an image used by a draft is validated against the same workspace/business. Generation task IDs and draft revision versions have uniqueness constraints for safe application/history.

Main modules:

- `src/lib/studio/types.ts`, `errors.ts`, `time.ts` — contracts, bounded inputs and scheduling validation.
- `repository.ts` — tenant-scoped drafts, versions, review and calendar records.
- `generate.ts`, `finalize.ts` — evidence-bounded prompts and normalized stored suggestions.
- `media.ts`, `unsplash.ts` — private uploads and optional provider adapter.
- `graphic-template.ts`, `graphics.ts` — browser-safe template builder and authenticated server PNG/ZIP output.
- `src/lib/ai/orchestrator.ts`, `work-log.ts` — validated content completion/resume integration and preserved output history.
- `src/app/api/studio/**` — authenticated bootstrap/create, draft detail/mutations, generation, media, stock, export and calendar routes.
- `src/components/studio/**` — actual Studio/editor, secure images, media picker and channel preview.
- `src/components/dashboard/calendar-board.tsx` and Studio/calendar route pages — real planning UI.
- Dashboard overview/phase labels, Integration Center and environment example — accurate Phase 4 readiness, not static zero-state claims.

Portability:

- Replaced the hardcoded local Drizzle JSON connection config with `drizzle.config.ts`, which loads `DATABASE_URL` from the server environment. Existing local data/connection continued to work.
- Added `.nvmrc` for Node 22, a local/GitHub setup README and a current known-issues register.
- Secrets remain ignored; no commit or push was performed and no GitHub connection is claimed.

## Tests actually performed

| Check | Observed result |
| --- | --- |
| Additive schema push with environment config | Passed |
| Initial Next.js route type generation/TypeScript | Passed |
| Pure schema/time/safety/PNG/ZIP/work-history suite | **18 assertions passed** |
| Final protected API + Chromium Studio/calendar workflow | **33 assertions passed** |
| Separate earlier live-AI workflow | One real Groq caption task completed; validated separate suggestion, explicit apply and duplicate-apply guard passed |
| Live stock API | **Not tested** — key missing |
| Video rendering | **Not supported/configured**, no fake success |
| Social publishing | **Not implemented/tested**, no publisher called |

The original live-AI test run and final regression overlap; assertion totals are not summed as if all were unique tests. The final regression was run without `--live-ai` to avoid consuming another provider request for cosmetic/copy changes.

Coverage includes:

- Empty real draft creation, authenticated access, cross-tenant draft/media/export denial, stale version 409.
- Claim flags and explicit owner review, member approval/brand-kit denial.
- Real schedule UTC/zone conversion, actual calendar API record, clearing approval/schedule on edit, revision restore.
- Actual PNG upload decode/normalization and private serving; spoofed MIME/uploaded SVG rejection; no binary-list leakage.
- Real branded PNG and multi-file carousel ZIP exports.
- Structured AI validation, no automatic editor overwrite, explicit genuine-suggestion apply and duplicate-apply rejection.
- Browser save, carousel/media/brand/history interfaces, actual calendar event visibility and correct event-to-draft navigation.
- DST gaps/ambiguity, XML escaping, image dimensions, missing-key response, raw output history retention across pause/retry snapshots.

Temporary users/workspaces/content/media/generations/revisions were cleaned through Drizzle. Final aggregate integrity check found **1 existing customer account, 1 existing workspace, 0 diagnostic accounts, 0 saved posts and 0 media assets**. No test content was left as customer sample content. Provider-level counters can reflect the genuine AI test; customer workspace analytics were not fabricated.

Required final Next.js typegen, TypeScript no-emit, production build and managed startup/healthcheck are run again after final edits. Their final status appears in the completion response.

## Known issues and technical limits

See `docs/KNOWN-ISSUES.md` for the current register. In particular:

- The user's real hosted-preview login problem is still **open/deferred**; local fixture login is not proof it is resolved.
- GitHub connection alone will not fix login, provide a database, migrate accounts or configure provider keys. GitHub Pages alone cannot run this dynamic backend.
- A fresh database contains no existing sandbox users/data unless deliberately migrated.
- No live Unsplash flow has been verified. Local template export of a linked stock background is deliberately blocked rather than silently rehosting it.
- No video rendering/transcoding pipeline, publishing API or background worker exists.
- AI/rendering remain bounded, request-triggered work. Durable leases, crash recovery and publishing idempotency belong to the worker phase.
- Brand/claim flags are not independent compliance verification; final render/policy/platform checks remain required before actual publishing.
- Images use bounded PostgreSQL storage, not a production media CDN. Workspace total-storage quotas/object storage remain scaling work.
- The latest npm install audit still reported **23 findings (1 low, 14 moderate, 7 high, 1 critical)**. No force-upgrade or security clearance is claimed.
- Browser tests used Chromium/local hosting, not the real Arena parent/gateway, every physical device or a comprehensive security/load audit.

## Review instructions

1. Use a reachable Node/Next.js app plus PostgreSQL. Follow README for local/exported setup; do not commit `.env`/`.env.local`.
2. Resolve/verify the real login flow on that deployment before calling the product ready.
3. Add/select a business; open **Content studio → New draft**.
4. Write/save manually; request a caption/carousel suggestion only when intentionally spending configured provider quota; inspect and Apply.
5. Upload a licensed image, select it, save a brand kit, and download a PNG or carousel bundle.
6. Review/acknowledge any flags, approve as owner/admin, choose wall time/zone and save the plan.
7. Open Calendar; inspect the actual event and navigate back to the draft. Confirm it states publishing is not connected.
8. Edit again and verify approval/schedule reset; inspect and restore an earlier revision.
9. Configure the optional Unsplash Access Key only when ready for a real test; follow its credit/hotlink/tracking terms. No key needs to be pasted in chat.

**Stop here for review. Phase 5 social integrations require explicit approval.**
