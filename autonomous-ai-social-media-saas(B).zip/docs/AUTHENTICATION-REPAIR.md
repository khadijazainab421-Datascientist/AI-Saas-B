# Phase 3 follow-up — Authentication and sandbox-secret repair

> Current Option B follow-up: normal deployments still use HttpOnly cookies, while the recognized sandbox can recover from completely blocked cookies with a short-lived, memory-only authenticated session. See `docs/OPTION-B-COOKIE-PERSISTENCE.md`; this does not require another signing key or provider credential.

## Scope

This is a repair to the existing Phase 2/3 functionality, not a restart of Phase 3 or an implementation of Phase 4. Existing customer users, password hashes, businesses, memberships, and workspaces are preserved. A private source backup was saved before the change; it contains no environment files or customer data.

## Observed login blockers

- The running sandbox had all three provider keys but **no AUTH_SECRET**, either in the process environment or private environment files. The old JWT login attempted to sign a session after verifying a password; without that secret, login could fail after account/workspace creation.
- The old JWT creation had no random identifier. Two sessions for the same user/workspace in the same second could have identical JWTs and collide with the unique stored token hash, or collide with an earlier revoked session.
- Registration was not atomic: user, workspace, membership, and session were separate operations. A later failure could leave an account already created even when the form appeared unsuccessful.
- Email matching was exact/case-sensitive; client session errors could be hidden as a redirect back to login.
- Dashboard active-workspace display always chose the first membership, rather than the server-selected workspace. Workspace switching revoked every device session.
- The previous validation was an HTTP smoke test, not a real browser/third-party-cookie test.

An aggregate database inspection found one existing customer account and one workspace, with no missing membership. No customer email, password, password hash, API key, or session cookie was printed.

## Implemented repair

### Database-backed opaque sessions

- Browser receives a cryptographically random 256-bit opaque session token.
- PostgreSQL stores only its SHA-256 hash, user ID, active workspace, expiry, and revocation state.
- Login no longer requires a JWT signing key or AUTH_SECRET. No signing secret is generated on each rebuild.
- Every protected data request independently verifies the DB session and workspace membership. Identity headers and decoded client claims are not trusted.
- Added only a nullable `user_sessions.workspace_id` foreign key (`ON DELETE SET NULL`). Existing rows and accounts were not removed. Older persisted tokens can be resolved by their stored hashes; absent workspace context is resolved from authorized membership, not unverified JWT claims.
- Workspace switching rotates only the current session token. Other devices remain signed in.
- Logout revokes the stored session and clears the matching cookie; failures are not presented as confirmed server-side sign-out.

### Registration/login correctness

- Normalize new emails and perform case-insensitive lookup for existing accounts.
- Keep password values unchanged; do not trim a user's password.
- Validate inputs and bcrypt's byte-length boundary at registration.
- Registration inserts the account, first workspace, membership, and session within one transaction.
- Unique workspace slugs permit multiple users to choose the same display name.
- Existing owners can recover only their own missing owner-membership relation if necessary; there is no mechanism to attach a foreign workspace.
- API errors use explicit, non-secret messages and `Cache-Control: private, no-store`.

### Browser/preview behavior

- Top-level HTTPS uses HttpOnly, Secure, SameSite=Lax cookies by default.
- An explicitly identified embedded request on recognized sandbox/loopback HTTPS hosts uses SameSite=None, Secure, HttpOnly, Partitioned cookies (CHIPS). A custom deployment can explicitly allow its own embedded preview with `ALLOW_EMBEDDED_PREVIEW`; it is not an API key.
- Mutation origin checks remain required; enabling preview cookies does not enable arbitrary cross-site writes.
- Browser auth client verifies `/api/auth/me` after login/registration before navigating to the dashboard. A dropped cookie produces a clear warning, not simulated login success or an endless redirect.
- Login/register include an Open in new tab fallback. If registration created an account but the cookie is blocked, the message explicitly says to sign in with the existing account, not register again.
- Full post-auth navigation avoids reusing a prefetched unauthenticated dashboard response.
- Session loading errors are retryable and distinguish a temporary service error from an unauthenticated state.
- Account menu, workspace creation/switching, and sign-out are usable on a mobile viewport.
- Migrated the deprecated `src/middleware.ts` convention to `src/proxy.ts`. Proxy performs only an optimistic page check and removes client identity headers; authoritative checks remain in the data layer.

### Shared visual correction

Screenshot review revealed default `bg-white` overriding explicit dark backgrounds on reusable panels, making white text invisible. The shared `cn()` helper now uses `tailwind-merge` so caller variants correctly override defaults. A browser assertion verifies the forest background against the specified palette.

## Secret file — what the user needs now

**Private file:** `.env.local` in the project root, alongside `package.json`.

Only these Phase 3 provider entries are needed for the implemented live AI/research integrations:

| Name | Purpose |
| --- | --- |
| GEMINI_API_KEY | Primary AI provider |
| GROQ_API_KEY | Independent AI/backup provider |
| TAVILY_API_KEY | Basic sourced web search |

All three entries were already present in this sandbox and were preserved without displaying or overwriting values. Do not copy a placeholder DATABASE_URL over the existing working database connection. Do not place real keys in `.env.example` or frontend files. The database URL remains an infrastructure configuration requirement. **AUTH_SECRET is not required by the repaired login.**

No new external API credential, paid service, developer-app approval, or user password was requested for this repair. Later content/media/social phases will disclose their own requirements at their phase gates.

## Files/modules

- `src/db/schema.ts`: additive active-workspace session column.
- `src/lib/auth.ts`: token creation/hashing, origin validation, cookie policy.
- `src/lib/auth-server.ts`: DB session verification, transactions, memberships, workspace rotation.
- `src/lib/auth-http.ts`: safe auth responses/input handling.
- `src/lib/tenant.ts`: authentication versus active-tenant authorization guards.
- `src/proxy.ts`: Next.js 16 page proxy; deprecated middleware removed.
- `src/app/api/auth/{login,register,logout,me,switch-workspace}/route.ts` and workspace routes.
- `src/lib/auth-client.ts`, `src/components/auth/auth-form.tsx`, login/register routes.
- `src/components/dashboard/dashboard-shell.tsx`: session/error UX and account/workspace menu.
- `src/lib/utils.ts`: conflict-aware Tailwind class merging.
- `scripts/check-auth-browser.ts`, `scripts/auth-test-cleanup.ts`: isolated browser regression suite.
- `.env.example` and `.gitignore`: secret guidance and private backup/test artifact exclusions.

## Testing performed — actual results

The production app was started with the platform-managed runtime. Chromium tests used a temporary **local HTTPS reverse proxy** to the managed server, plus a separate HTTP parent origin to exercise real cross-site iframe cookie behavior. This does not bypass or test the platform's public gateway authorization. Test-only certificates/proxies were removed afterward.

All **24 checks passed**:

1. Browser registration reaches authenticated dashboard.
2. Email normalization preserves correct credential behavior.
3. Top-level HTTPS cookie is HttpOnly, Secure, SameSite=Lax.
4. New session is opaque and does not require AUTH_SECRET.
5. Revoked/logout token receives 401.
6. Wrong password shows a clear error without dashboard access.
7. Existing-account login works with different email capitalization.
8. Rapid concurrent logins both succeed.
9. Concurrent logins receive distinct random tokens.
10. Browser refresh preserves authenticated access.
11. Workspace create/switch persists selected workspace server-side.
12. Active-workspace label matches persisted selection.
13. Workspace switching does not sign out another browser/device.
14. Cross-origin mutation receives 403 despite a valid cookie.
15. Gemini/Groq/Tavily configuration is accessible after actual browser login.
16. Cross-site iframe login works with a partitioned secure HttpOnly cookie.
17. Mobile account menu and sign-out are usable at a 390-pixel viewport.
18. Separate accounts can use identical workspace display names.
19. Authenticated business creation still works.
20. Another tenant cannot read the business (404).
21. Another tenant cannot edit the business (404).
22. Forged identity headers without a valid session receive 401.
23. Forest panels retain their intended dark background.
24. No uncaught browser page error in the desktop flow.

The suite ran with **AUTH_SECRET absent**. No AI generation, web search, model health probe, or paid-provider request was invoked by these authentication checks. The suite only reads authenticated provider configuration metadata.

Temporary diagnostic accounts/workspaces/business records were cleaned up through Drizzle in `finally`; exact generated diagnostic emails are used, never a customer-data wildcard. Integrity verification found the original one account and one workspace preserved and zero temporary auth fixtures.

Initial test-environment failures were not counted as successful tests: missing Chromium system libraries were installed; a password-label accessibility issue was corrected; a strict test locator was scoped away from Next.js's hidden route-announcer region. The complete suite then passed.

Required Next.js route type generation, TypeScript no-emit validation, production build, and final managed startup/healthcheck are rerun before the turn ends. Their final status is recorded in the completion response.

## Dependencies and limitations

- Playwright/Chromium: open-source local browser test tooling; no hosted account, quota, card, or key. The browser runner needed native Linux libraries in this sandbox. Manual browser tests are an alternative, but are not substituted for these automated results.
- tailwind-merge: open-source local utility, compatible with Tailwind 4; no hosted service, key, card, or quota. Explicit conditional class handling is an alternative.
- Only Chromium desktop/mobile emulation and local cross-site iframe behavior were exercised. Safari, Firefox, physical mobile devices, and every platform gateway policy are not claimed as tested. The separate-tab fallback remains available.
- This is not a comprehensive penetration, concurrency, or production-readiness audit. Email verification/password recovery, MFA, distributed rate limiting, and the inherited npm audit findings remain launch-hardening work. No reset email is simulated.
- Existing Gemini service-availability limitations from the previous live provider test are not claimed resolved by an authentication repair.
- Phase 4 and later functionality has not been started.

## User review

1. Refresh the latest preview and open `/login`, preferably in a separate tab if the embedded browser restricts cookies.
2. Use the **same Serein signup email and password**. The workspace display name or a Gemini/Groq/Tavily login is not the Serein login.
3. Do not recreate the existing account/workspace or send the password/API keys in chat.
4. After the dashboard opens, visit AI Engine for provider status, then Strategy for brand/research/draft workflows.
5. New provider requirements will be disclosed phase-by-phase; the existing three keys need not be pasted again.

## References

- https://nextjs.org/docs/app/guides/authentication
- https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html
- https://developer.mozilla.org/en-US/docs/Web/Privacy/Guides/Privacy_sandbox/Partitioned_cookies
- https://github.com/dcastil/tailwind-merge
