# Current known issues and readiness boundaries

## AUTH-001 — User-reported hosted preview login remains unresolved

**Status: OPEN / user testing deferred.** The user reports the actual Arena-hosted browser still does not complete login, despite prior local HTTP/Chromium regressions passing. The user explicitly asked to proceed to Phase 4 and test later through a GitHub/local or hosted deployment.

- Do not mark this issue resolved merely because local tests pass or GitHub is connected.
- Phase 4 did not rewrite authentication again. It uses the existing authenticated API transport.
- No guest/automatic login, fixed password, or tenant bypass was added.
- Verify the real browser/gateway session flow on the eventual first-party deployment. Check request/response status and safe cookie/header metadata without sharing passwords, API keys, session cookies, or access tokens.
- Connecting a repository alone does not host PostgreSQL or the Next.js backend, migrate users, or verify authentication.

## MEDIA-001 — Stock-photo live integration pending

`UNSPLASH_ACCESS_KEY` has an empty slot in the private environment template/file. No key was supplied for it; no live Unsplash API search/selection was tested. Adapter, hotlinking/credits, download-tracking structure, missing-key API response, and pending UI are implemented. Manual uploads and local PNG/ZIP exports are available without that key.

Pexels was not selected: its current API homepage says new key issuance is paused. Do not instruct a user that a new Pexels key is guaranteed to be issued instantly.

## VIDEO-001 — No video encoder/rendering pipeline

Video scripts/storyboards can be generated and edited. No FFmpeg-backed video creation, transcoding, duration/codec verification, or rendered movie is implemented/configured. Do not show a rendered-video success state. A suitable worker/encoder or an explicitly selected provider must be configured before this can be claimed.

## PUBLISH-001 — Schedules are editorial plans, not publishing jobs

Phase 4 stores approved draft schedule records and displays them in a time-zone-aware calendar. Instagram/Facebook/LinkedIn OAuth and publishing are Phase 5; background publishing workers/retry/idempotency are Phase 6. There is no connected publisher or background dispatch in Phase 4.

## STORAGE-001 — Small-file PostgreSQL storage only

Private image uploads are magic-byte checked, decoded, pixel-limited, resized, metadata-stripped and re-encoded, then stored in PostgreSQL `bytea`. Maximum original upload is 5 MiB. Hosting gateways can impose a lower request limit. This is portable small-file storage, not an unlimited media CDN or large-video store. Object storage and configurable total-storage/plan quotas remain necessary before scaling.

## SAFETY-001 — Review is not independent verification

Claim flags are deterministic first-pass patterns plus configured restricted topics. Human acknowledgement is logged, not presented as proof that a claim is factually/legal-compliance verified. Approval is editorial; the future publishing pipeline must revalidate platform constraints, eligible accounts, brand-policy changes, and the exact final media/rendered version.

## OPS-001 — Request-bound AI/rendering and source-control readiness

- User-triggered AI calls and small graphic exports are request-bound, not a durable worker system. Raw outputs/attempts are persisted, including output history across pauses/resumes, but process/DB outages and concurrent retry leasing need Phase 6 operational hardening.
- The original dependency audit findings are not fully resolved. The most recent package-install audit reported 23 findings: 1 low, 14 moderate, 7 high, 1 critical. No force upgrade was used or security clearance claimed.
- No full production-readiness, penetration, load, exhaustive authorization, or physical-device test is claimed.
- Expired-session cleanup, email verification/recovery, MFA and distributed rate limiting remain launch-hardening work.
- No GitHub repository was detected/committed/pushed in this sandbox. Review code before connecting/pushing. `.gitignore` protects Git operations, not arbitrary ZIP/manual uploads; exclude `.env`, `.env.local`, backups, test artifacts, `node_modules` and `.next` from shared exports.

## Phase gate

Phase 4 core implementation is available with the above external/conditional items pending. Phase 5 has not started and needs explicit approval plus its own developer-app/permission/credential disclosure.
