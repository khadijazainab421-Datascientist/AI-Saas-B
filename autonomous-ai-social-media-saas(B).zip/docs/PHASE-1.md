# Serein — Phase 1: Foundation and UI

## Scope

Phase 1 establishes the product identity, design system, public landing experience, responsive dashboard shell, navigation, reusable UI primitives, and honest loading/empty/error states. It deliberately does not implement authentication, persistence, AI, research, content generation, social connections, publishing, autonomous workers, analytics ingestion, or billing.

The existing Drizzle database connection and empty schema entrypoint were preserved. The starter home page no longer runs a database query, so the public site does not depend on a live database.

## Identity and design system

- Product name: **Serein**.
- Editorial display typography: DM Serif Display.
- Interface typography: Manrope.
- Palette: soft white, deep teal, forest teal, sage, mint, pale green, readable ink, secondary text, and subtle borders from the specification.
- Restrained glass is reserved for layered hero media and navigation rather than applied to every component.
- Original local artwork: editorial portrait and sculptural glass/sage still life.
- Custom Serein mark and custom Instagram, Facebook, and LinkedIn line icons.
- Motion respects `prefers-reduced-motion`; the large agent scene has a readable mobile presentation.

## Landing experience

- Full-viewport layered hero with staggered masked headline entrances and scroll-linked image scale, position, clipping, and copy transformation.
- Product philosophy and original editorial imagery.
- Six differentiated product capability compositions.
- Desktop scroll-driven agent scene in which five disciplines converge and reorder around the central agent.
- Interactive autonomy-model explorer with four modes and a local weekly-cap preview. This control is explicitly labeled as a model and does not save settings or publish content.
- Instagram, Facebook, and LinkedIn capability/eligibility summaries with official documentation links and pending integration status.
- Four-tier plan architecture without invented paid pricing or unlimited claims.
- Security architecture disclosures that distinguish specification from implemented controls.
- Accessible animated FAQ and complete footer.

## Dashboard shell

Routes:

- `/dashboard` — setup path, safe agent state, empty schedule, and empty activity log.
- `/dashboard/businesses` — honest empty state and business-profile architecture.
- `/dashboard/strategy` — honest empty state and strategy blueprint.
- `/dashboard/studio` — honest empty state and planned content-format capability map.
- `/dashboard/calendar` — functional previous/next/today month navigation with no fabricated posts.
- `/dashboard/integrations` — readiness directory, official documentation, phase dependencies, and current credential status.
- `/dashboard/analytics` — data-free visualization state and measurement definitions.

Shared behavior:

- Persistent desktop sidebar and animated mobile drawer.
- Route-aware active navigation and subtle route transitions.
- Responsive top bar and readable content widths.
- Loading skeleton, recoverable dashboard error screen, and custom 404.
- No inactive connect, generate, save, upgrade, or publish buttons.

## Main modules

- `src/app/layout.tsx`, `src/app/globals.css` — metadata, fonts, tokens, global styles.
- `src/app/page.tsx` — public landing content.
- `src/components/brand/` — Serein and social-brand marks.
- `src/components/ui/` — buttons, badges, panels, headings, empty states, skeletons.
- `src/components/landing/` — header, hero, reveal, agent flow, autonomy explorer, FAQ.
- `src/components/dashboard/` — responsive shell and calendar board.
- `src/app/dashboard/` — shell routes and loading/error boundaries.
- `public/images/` — original local artwork.
- `.env.example` — secret-free template; no credentials needed in Phase 1.

## Technology choices

### Motion

- Purpose: scroll-linked transforms, entrances, drawer/dialog-like transitions, FAQ expansion, and route transitions.
- Cost model: open-source local package; no hosted quota, account, credit card, or runtime API credential.
- Exhaustion behavior: not applicable; animation runs locally in the browser.
- Alternative: native CSS and Web Animations API, with more custom orchestration code.

### Lucide

- Purpose: consistent general interface iconography.
- Cost model: open-source local package; no hosted quota, account, credit card, or credential.
- Exhaustion behavior: not applicable.
- Alternative: custom SVG for every icon. Social-brand marks are custom because the installed Lucide release does not export them.

### Google Fonts through `next/font`

- Purpose: DM Serif Display and Manrope, downloaded at build time and self-hosted by Next.js rather than loaded from a browser runtime font request.
- Cost model: open fonts; no API key, account, credit card, or per-view font quota.
- Exhaustion behavior: no runtime font API quota. A build environment still needs access to obtain font files unless they are later vendored.
- Alternative: vendor the font files locally or use system fonts.

No AI, research, media, social, storage, queue, payment, monitoring, or authentication service has been selected or configured in this phase.

## Credentials and external dependencies

**No credentials are required for Phase 1.** No account approval is needed. The Integration Center identifies anticipated candidates and links to official documentation, but does not request secrets or claim live connections.

The existing `.env` and database scaffolding were not modified. `.env.example` contains no real values.

## Functional boundaries and known limitations

- Workspace and business creation are not available until Phase 2; there is no local-only fake persistence.
- The autonomy explorer is a marketing explanation of local UI state, not saved agent configuration.
- Calendar navigation works, but event creation and scheduling do not.
- Integration cards are documentation/readiness entries, not active OAuth connections or provider health checks.
- Analytics intentionally contains no sample performance data.
- Paid-plan prices and payment actions are intentionally absent.
- No production-ready, tenant-isolated, connected, autonomous, or billing-enabled claim is made.
- Dependency installation reported npm audit findings in the inherited/installed dependency graph. No force upgrade was applied because it could break the pinned Next.js toolchain; this requires a separate dependency/security review rather than being hidden or described as resolved.

## Review guide

1. Review `/` at desktop and mobile widths; scroll through the hero and agent scene.
2. Open the autonomy section, switch all four modes, and adjust the weekly cap.
3. Expand and collapse FAQ entries.
4. Open the mobile navigation and verify all section links.
5. Visit every dashboard destination using the sidebar and mobile drawer.
6. Navigate calendar months and return with Today.
7. Open official integration documentation links.
8. Confirm business, strategy, studio, activity, and analytics views remain honestly empty.
9. Confirm reduced-motion preferences disable nonessential movement.

## Next phase gate

Phase 2 has **not** started. It requires explicit approval. Before live authentication and tenant-scoped persistence work, the database connection approach, authentication library, session model, and credential configuration will be identified for review.
