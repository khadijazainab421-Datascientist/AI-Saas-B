# Option B — Blocked-cookie session persistence repair

## Scope and observed symptom

The user could submit correct credentials but received: the password was accepted and the preview did not retain its session cookie. This means password verification succeeded but the following authenticated-session check did not. It does not prove which browser/proxy layer removed the cookie; the actual Arena parent internals are not visible to this sandbox.

This repair addresses Option B only. It does not advance the product phase, change the user's password/account, reset workspaces, edit provider-key values, or alter the database schema.

## Repair

### Cookie transport remains the default

- Normal login still issues an opaque HttpOnly cookie, stored as a SHA-256 verifier in PostgreSQL.
- Top-level HTTPS keeps Secure + SameSite=Lax.
- Embedded cookie policy now recognizes the sandbox runtime as well as forwarded hostnames. A reverse proxy using its own hostname no longer automatically loses the preview policy.
- Known same-origin HTTPS browser requests can correctly supply the secure-cookie signal behind an internal HTTP proxy.

### Authenticated, memory-only preview recovery

If the cookie cannot be verified in a recognized sandbox:

1. The client performs at most one explicit preview retry.
2. The login endpoint verifies the real email/password again.
3. A new, independent `p1_` opaque credential is created with 256 bits of randomness and a maximum 30-minute DB expiry.
4. Only the SHA-256 verifier is stored in the existing session table.
5. The client holds the credential in its current JavaScript memory, not localStorage, sessionStorage, IndexedDB, cookies, URLs, or copied links.
6. Shared same-origin API calls send it in the application-specific preview-session header. Automatic cross-origin redirect following is disabled.
7. The server validates the actual DB session, expiry, revocation, user, active workspace, and membership on protected requests. It never accepts user IDs or role claims as authentication.
8. `/api/auth/me` must confirm the expected user and the preview transport before the UI navigates to the dashboard.

The user does not need to create the account again, change privacy settings, paste a token, or open another tab.

### Deployment boundary and security trade-off

- Cookie-free preview transport is enabled for the recognized E2B sandbox runtime. Normal deployments are cookie-only by default.
- A custom preview host can explicitly opt in with `ALLOW_PREVIEW_TOKEN_AUTH=true`; `false` explicitly disables it even in a sandbox. This is a non-secret deployment setting, not an API key. No such setting or key value was changed in this repair.
- This is a preview compatibility mode, not a claim that JavaScript-managed credentials are equivalent to HttpOnly cookies. XSS remains a threat to any JavaScript-managed credential; memory-only handling, a bounded server expiry, same-origin API restrictions, no URL/storage persistence, and server-side revocation reduce persistence/exfiltration exposure. Production should use a dedicated first-party HTTPS domain and HttpOnly cookies.
- Ordinary cookie login responses do not return their session secret in JSON. Only an explicitly requested, credential-verified preview retry returns the distinct short-lived preview credential, with private/no-store response headers.
- Wrong passwords, invented tokens, expired/revoked tokens, and foreign-tenant resources are rejected.
- Mutation origin checks and existing paid-provider role/authorization controls remain in force. No permissive CORS or guest bypass was introduced.

### Navigation and lifecycle

- Preview-mode login and workspace navigation use the existing client router so a page reload does not immediately erase the memory-only session.
- A recognized preview may load the public dashboard UI shell without a cookie; that shell contains no customer data. Every private API still validates an authenticated DB session. Production retains the optimistic cookie page gate. Future private server-rendered data must use an appropriate authorized data boundary; the preview UI shell must never become a substitute for authorization.
- All current business, strategy, AI, and auth client API wrappers use the shared transport helper.
- Workspace switching rotates the current credential without extending the preview's original expiry or signing out other browsers. Selected-workspace content remounts and fetches its own authorized data.
- A stale in-flight request cannot clear a newly rotated session.
- Logout revokes the preview credential server-side and clears memory only after successful confirmation.
- The dashboard explicitly displays **Temporary preview session**. Keep that tab open. A full browser refresh or tab close discards memory and requires signing in again; saved database records remain available after signing in.

## Actual tests

### Cookie/storage faults were reproduced, not inferred as passed

The local HTTPS test proxy removes both outgoing `Set-Cookie` responses and incoming `Cookie` headers for selected browser contexts. Production code does not recognize or use the test-only fault-injection header.

A second context also denies both localStorage and sessionStorage inside an iframe. The original cookie verification failure is observed before automatic preview recovery.

The full browser suite passed after correcting a workspace-dropdown state issue discovered during the first extended run. Passed cases include:

- Normal cookie signup/login, wrong-password errors, rapid independent sessions, refresh, mobile sign-out, partitioned iframe cookies, and editor-resistant links.
- Successful signup with no session cookie at all, without registering twice.
- Actual DB-backed preview session belongs to the newly registered test account.
- Maximum server lifetime is 30 minutes, irrespective of a client-requested longer lifetime.
- Cookie-failure reproduction followed by verified authenticated dashboard access.
- Real business creation and subsequent private-list reload without cookies.
- AI Engine authenticated metadata retrieval without provider execution.
- Foreign-tenant business read/edit rejection and mutation-origin rejection.
- Workspace rotation, invalidation of the previous token, and no extension of the original expiry.
- Server-confirmed logout/revocation.
- Existing-account iframe login with cookies and both web-storage APIs unavailable.
- Private app navigation retaining the memory-only session.
- Full refresh truthfully returning to sign-in rather than claiming persistent authentication.
- Wrong-password preview retry releases no credential.
- An invented, structurally valid preview token fails DB verification.
- Expiry fault injection affects only an exact generated test account/session, then the server rejects that expired credential.

Policy unit tests verify normal production opt-out/default behavior, distinct random namespaces, preview expiry bound, header-channel restrictions, proxy cookie policy, and mutation-origin protection.

Final totals for this repair: **58 browser assertions passed**, including the original flows and the blocked-cookie/storage-denied cases, plus **16 session-policy assertions passed**. The corresponding local logs are `/tmp/cookie-persistence-browser.log` and `/tmp/session-policy.log`. Tests do not log customer passwords, real session-token values, or provider API keys. Temporary diagnostic users/workspaces/businesses/sessions and local TLS proxies are removed in `finally` through Drizzle using exact newly generated fixture identities.

No AI generation, research, publishing, or paid-provider API request is part of this authentication suite. Provider configuration is read only through the authenticated app metadata API.

## Modules changed

- `src/lib/auth.ts`, `auth-server.ts`, `auth-http.ts`, and `tenant.ts`: transport policy and authoritative DB verification.
- `src/lib/session-constants.ts`: shared non-secret transport constants.
- `src/lib/preview-session-client.ts`: memory-only credential lifecycle.
- `src/lib/api-fetch.ts`: same-origin authenticated API transport, with no redirect-based credential forwarding.
- `src/lib/auth-client.ts`: verified automatic recovery and identity confirmation.
- Auth login/register/me/logout/workspace-switch routes and public capability metadata.
- `src/proxy.ts`: sandbox UI-shell compatibility without changing API authorization.
- Auth form and dashboard shell: client navigation, workspace state, and honest preview-session notice.
- Business/strategy/AI component wrappers: shared API transport only; business/generation logic unchanged.
- `scripts/check-session-policy.ts`, `check-cookie-blocked-flow.ts`, and the existing browser suite.

A source-only backup was saved in the git-ignored private backups directory before editing. No real environment file was overwritten, no new npm service dependency was selected, and no credential is required beyond the already configured infrastructure.

## Review

1. Refresh the current Option B preview once to load the update.
2. Enter the existing Serein email/password and choose **Sign in**.
3. If cookies are blocked, temporary preview recovery should be automatic; no separate-tab step is required.
4. Confirm the dashboard and its temporary-session notice, then test Businesses, Strategy, and AI Engine.
5. Keep that preview tab open while testing. If you fully reload it, sign in again; do not recreate the account/workspace.

The actual Arena browser/gateway policy cannot be universally certified from a local regression. If a host also strips the authenticated app header, the server will fail closed rather than simulate success. The hosting public-access boundary is not bypassed.

## Remaining boundaries

- Phase 4 and later features have not started.
- No production-readiness or full penetration-test claim is made. Existing launch-hardening and inherited dependency-audit work remain.
- Old unconfirmed cookie-attempt records can remain until normal expiry; background expired-session cleanup belongs to operational/worker hardening.
- Required route type generation, TypeScript no-emit, production build, and managed startup/healthcheck are rerun after the final edits; the completion response states the final validation result.

## References consulted

- https://developer.mozilla.org/en-US/docs/Web/API/Window/sessionStorage
- https://cheatsheetseries.owasp.org/cheatsheets/HTML5_Security_Cheat_Sheet.html
