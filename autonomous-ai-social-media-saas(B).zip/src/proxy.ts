import { NextResponse, type NextRequest } from "next/server";
import { publicOrigin, sessionCookieName, previewSessionsEnabled } from "@/lib/auth";

/**
 * Production keeps the optimistic cookie gate. In a recognized sandbox a public
 * UI shell can load without cookies so a memory-only preview credential can be
 * used by client API requests. The shell contains no customer data; every data
 * API still validates its opaque DB session and tenant membership independently.
 */
export function proxy(request: NextRequest) {
  if (request.nextUrl.pathname.startsWith("/dashboard") && !request.cookies.get(sessionCookieName())?.value && !previewSessionsEnabled()) {
    return NextResponse.redirect(new URL("/login", publicOrigin(request)));
  }
  const headers = new Headers(request.headers);
  headers.delete("x-user-id"); headers.delete("x-user-email"); headers.delete("x-workspace-id");
  const response = NextResponse.next({ request: { headers } });
  response.headers.set("Cache-Control", "private, no-store");
  return response;
}
export const config = { matcher: ["/dashboard/:path*", "/api/:path*"] };
