import {
  pgTable,
  serial,
  text,
  timestamp,
  boolean,
  integer,
  pgEnum,
  jsonb,
  uniqueIndex,
  index,
  customType,
} from "drizzle-orm/pg-core";
import type { DraftInput, Platform, BrandStyle } from "@/lib/studio/types";

export const userRoleEnum = pgEnum("user_role", ["owner", "admin", "member"]);
export const aiTaskStatusEnum = pgEnum("ai_task_status", [
  "pending",
  "running",
  "paused",
  "completed",
  "failed",
]);

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull().unique(),
    passwordHash: text("password_hash").notNull(),
    name: text("name"),
    emailVerified: boolean("email_verified").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({ emailIdx: uniqueIndex("users_email_idx").on(table.email) }),
);

export const workspaces = pgTable(
  "workspaces",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    slug: text("slug").notNull().unique(),
    ownerId: integer("owner_id")
      .notNull()
      .references(() => users.id),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({ slugIdx: uniqueIndex("workspaces_slug_idx").on(table.slug) }),
);

export const workspaceMembers = pgTable(
  "workspace_members",
  {
    id: serial("id").primaryKey(),
    workspaceId: integer("workspace_id")
      .notNull()
      .references(() => workspaces.id),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id),
    role: userRoleEnum("role").notNull().default("member"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    workspaceUserIdx: uniqueIndex("workspace_members_user_idx").on(
      table.workspaceId,
      table.userId,
    ),
    userIdx: index("workspace_members_user_lookup_idx").on(table.userId),
  }),
);

export const businesses = pgTable(
  "businesses",
  {
    id: serial("id").primaryKey(),
    workspaceId: integer("workspace_id")
      .notNull()
      .references(() => workspaces.id),
    name: text("name").notNull(),
    website: text("website"),
    industry: text("industry"),
    description: text("description"),
    targetAudience: text("target_audience"),
    brandVoice: text("brand_voice"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    workspaceIdx: index("businesses_workspace_idx").on(table.workspaceId),
  }),
);

export const userSessions = pgTable(
  "user_sessions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id),
    tokenHash: text("token_hash").notNull().unique(),
    workspaceId: integer("workspace_id").references(() => workspaces.id, { onDelete: "set null" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    revoked: boolean("revoked").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    userIdx: index("user_sessions_user_idx").on(table.userId),
    tokenIdx: uniqueIndex("user_sessions_token_idx").on(table.tokenHash),
  }),
);

/* ---------------------------- Phase 3 additions --------------------------- */

export const workspaceSettings = pgTable(
  "workspace_settings",
  {
    id: serial("id").primaryKey(),
    workspaceId: integer("workspace_id")
      .notNull()
      .unique()
      .references(() => workspaces.id),
    allowPaidProviders: boolean("allow_paid_providers")
      .notNull()
      .default(false),
    primaryProvider: text("primary_provider").notNull().default("gemini"),
    dailyAiRequestLimit: integer("daily_ai_request_limit")
      .notNull()
      .default(50),
    dailyResearchLimit: integer("daily_research_limit")
      .notNull()
      .default(20),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    workspaceIdx: uniqueIndex("workspace_settings_workspace_idx").on(
      table.workspaceId,
    ),
  }),
);

/** Runtime provider state. Contains NO credentials; keys live only in env. */
export const aiProviderStates = pgTable(
  "ai_provider_states",
  {
    id: serial("id").primaryKey(),
    providerKey: text("provider_key").notNull().unique(),
    kind: text("kind").notNull(), // "ai" | "research"
    label: text("label").notNull(),
    isPaid: boolean("is_paid").notNull().default(false),
    enabled: boolean("enabled").notNull().default(true),
    priority: integer("priority").notNull().default(100),
    health: text("health").notNull().default("unconfigured"),
    lastCheckedAt: timestamp("last_checked_at", { withTimezone: true }),
    lastError: text("last_error"),
    quotaExhaustedUntil: timestamp("quota_exhausted_until", {
      withTimezone: true,
    }),
    dailyRequestCount: integer("daily_request_count").notNull().default(0),
    quotaWindowStart: timestamp("quota_window_start", { withTimezone: true })
      .defaultNow()
      .notNull(),
    totalRequests: integer("total_requests").notNull().default(0),
    totalInputTokens: integer("total_input_tokens").notNull().default(0),
    totalOutputTokens: integer("total_output_tokens").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    providerIdx: uniqueIndex("ai_provider_states_key_idx").on(
      table.providerKey,
    ),
  }),
);

export const aiUsageEvents = pgTable(
  "ai_usage_events",
  {
    id: serial("id").primaryKey(),
    workspaceId: integer("workspace_id")
      .notNull()
      .references(() => workspaces.id),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id),
    providerKey: text("provider_key").notNull(),
    taskType: text("task_type").notNull(),
    status: text("status").notNull(), // success | error | quota | paused
    inputTokens: integer("input_tokens").notNull().default(0),
    outputTokens: integer("output_tokens").notNull().default(0),
    latencyMs: integer("latency_ms").notNull().default(0),
    errorCode: text("error_code"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    workspaceIdx: index("ai_usage_events_workspace_idx").on(table.workspaceId),
  }),
);

export const aiTasks = pgTable(
  "ai_tasks",
  {
    id: serial("id").primaryKey(),
    workspaceId: integer("workspace_id")
      .notNull()
      .references(() => workspaces.id),
    businessId: integer("business_id").references(() => businesses.id),
    kind: text("kind").notNull(),
    status: aiTaskStatusEnum("status").notNull().default("pending"),
    payload: jsonb("payload"),
    result: jsonb("result"),
    /** Never discard work: every attempt's output/errors are preserved here. */
    partialResult: jsonb("partial_result"),
    error: text("error"),
    attempts: integer("attempts").notNull().default(0),
    providerKey: text("provider_key"),
    allowPaid: boolean("allow_paid").notNull().default(false),
    pausedReason: text("paused_reason"),
    resumeAfter: timestamp("resume_after", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    completedAt: timestamp("completed_at", { withTimezone: true }),
  },
  (table) => ({
    workspaceIdx: index("ai_tasks_workspace_idx").on(table.workspaceId),
    statusIdx: index("ai_tasks_status_idx").on(table.status),
  }),
);

export const notifications = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    workspaceId: integer("workspace_id")
      .notNull()
      .references(() => workspaces.id),
    userId: integer("user_id").references(() => users.id),
    type: text("type").notNull(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    read: boolean("read").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    workspaceIdx: index("notifications_workspace_idx").on(table.workspaceId),
  }),
);

export const brandProfiles = pgTable(
  "brand_profiles",
  {
    id: serial("id").primaryKey(),
    workspaceId: integer("workspace_id")
      .notNull()
      .references(() => workspaces.id),
    businessId: integer("business_id")
      .notNull()
      .unique()
      .references(() => businesses.id),
    tone: text("tone"),
    voiceDescription: text("voice_description"),
    vocabulary: jsonb("vocabulary").$type<string[]>(),
    audience: text("audience"),
    objectives: text("objectives"),
    claimsPolicy: text("claims_policy"),
    restrictedTopics: jsonb("restricted_topics").$type<string[]>(),
    styleExamples: jsonb("style_examples").$type<string[]>(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    businessIdx: uniqueIndex("brand_profiles_business_idx").on(
      table.businessId,
    ),
    workspaceIdx: index("brand_profiles_workspace_idx").on(table.workspaceId),
  }),
);

export const websiteAnalyses = pgTable(
  "website_analyses",
  {
    id: serial("id").primaryKey(),
    workspaceId: integer("workspace_id")
      .notNull()
      .references(() => workspaces.id),
    businessId: integer("business_id")
      .notNull()
      .references(() => businesses.id),
    url: text("url").notNull(),
    status: text("status").notNull().default("pending"),
    title: text("title"),
    metaDescription: text("meta_description"),
    headings: jsonb("headings").$type<string[]>(),
    extractedText: text("extracted_text"),
    wordCount: integer("word_count").notNull().default(0),
    aiSummary: jsonb("ai_summary"),
    providerKey: text("provider_key"),
    error: text("error"),
    fetchedAt: timestamp("fetched_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    businessIdx: index("website_analyses_business_idx").on(table.businessId),
  }),
);

export const researchRuns = pgTable(
  "research_runs",
  {
    id: serial("id").primaryKey(),
    workspaceId: integer("workspace_id")
      .notNull()
      .references(() => workspaces.id),
    businessId: integer("business_id").references(() => businesses.id),
    query: text("query").notNull(),
    status: text("status").notNull().default("pending"),
    providerKey: text("provider_key"),
    creditsUsed: integer("credits_used").notNull().default(0),
    answer: text("answer"),
    error: text("error"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    workspaceIdx: index("research_runs_workspace_idx").on(table.workspaceId),
  }),
);

export const researchSources = pgTable(
  "research_sources",
  {
    id: serial("id").primaryKey(),
    workspaceId: integer("workspace_id")
      .notNull()
      .references(() => workspaces.id),
    businessId: integer("business_id").references(() => businesses.id),
    runId: integer("run_id").references(() => researchRuns.id),
    url: text("url").notNull(),
    title: text("title"),
    snippet: text("snippet"),
    providerKey: text("provider_key").notNull(),
    retrievedAt: timestamp("retrieved_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    workspaceIdx: index("research_sources_workspace_idx").on(table.workspaceId),
  }),
);

export const contentStrategies = pgTable(
  "content_strategies",
  {
    id: serial("id").primaryKey(),
    workspaceId: integer("workspace_id")
      .notNull()
      .references(() => workspaces.id),
    businessId: integer("business_id")
      .notNull()
      .references(() => businesses.id),
    taskId: integer("task_id").references(() => aiTasks.id),
    version: integer("version").notNull().default(1),
    status: text("status").notNull().default("draft"),
    pillars: jsonb("pillars"),
    formats: jsonb("formats"),
    cadence: jsonb("cadence"),
    calendarLogic: jsonb("calendar_logic"),
    rationale: text("rationale"),
    reviewFlags: jsonb("review_flags").$type<string[]>(),
    sources: jsonb("sources").$type<string[]>(),
    providerKey: text("provider_key"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    businessIdx: index("content_strategies_business_idx").on(table.businessId),
  }),
);

/* -------------------- Phase 4: content creation studio -------------------- */
const binary = customType<{ data: Buffer; driverData: Buffer }>({ dataType: () => "bytea" });

export const mediaAssets = pgTable("media_assets", {
  id: serial("id").primaryKey(),
  workspaceId: integer("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  businessId: integer("business_id").references(() => businesses.id, { onDelete: "cascade" }),
  createdBy: integer("created_by").notNull().references(() => users.id),
  name: text("name").notNull(), mimeType: text("mime_type").notNull(), kind: text("kind").notNull(),
  body: binary("body"), byteSize: integer("byte_size").notNull().default(0), width: integer("width"), height: integer("height"),
  source: text("source").notNull().default("upload"), providerId: text("provider_id"),
  remoteUrl: text("remote_url"), sourceUrl: text("source_url"), photographer: text("photographer"), photographerUrl: text("photographer_url"),
  altText: text("alt_text").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (t) => ({ scopeIdx: index("media_assets_scope_idx").on(t.workspaceId, t.businessId) }));

export const studioBrandStyles = pgTable("studio_brand_styles", {
  id: serial("id").primaryKey(),
  workspaceId: integer("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  businessId: integer("business_id").notNull().unique().references(() => businesses.id, { onDelete: "cascade" }),
  style: jsonb("style").$type<BrandStyle>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const contentPosts = pgTable("content_posts", {
  id: serial("id").primaryKey(),
  workspaceId: integer("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  businessId: integer("business_id").notNull().references(() => businesses.id, { onDelete: "cascade" }),
  createdBy: integer("created_by").notNull().references(() => users.id),
  updatedBy: integer("updated_by").notNull().references(() => users.id),
  title: text("title").notNull(), format: text("format").notNull(), platforms: jsonb("platforms").$type<Platform[]>().notNull(),
  document: jsonb("document").$type<DraftInput>().notNull(), status: text("status").notNull().default("draft"),
  version: integer("version").notNull().default(1), reviewFlags: jsonb("review_flags").$type<string[]>().notNull().default([]),
  approvedAt: timestamp("approved_at", { withTimezone: true }), approvedBy: integer("approved_by").references(() => users.id),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }), timeZone: text("time_zone").notNull().default("UTC"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (t) => ({ scopeIdx: index("content_posts_scope_idx").on(t.workspaceId, t.businessId), calendarIdx: index("content_posts_calendar_idx").on(t.workspaceId, t.scheduledAt) }));

export const contentRevisions = pgTable("content_revisions", {
  id: serial("id").primaryKey(),
  workspaceId: integer("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  postId: integer("post_id").notNull().references(() => contentPosts.id, { onDelete: "cascade" }),
  actorId: integer("actor_id").notNull().references(() => users.id), version: integer("version").notNull(), action: text("action").notNull(),
  snapshot: jsonb("snapshot").$type<{ document: DraftInput; status: string; scheduledAt: string | null; timeZone: string }>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (t) => ({ versionIdx: uniqueIndex("content_revisions_version_idx").on(t.postId, t.version) }));

export const studioGenerations = pgTable("studio_generations", {
  id: serial("id").primaryKey(),
  workspaceId: integer("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  businessId: integer("business_id").notNull().references(() => businesses.id, { onDelete: "cascade" }),
  postId: integer("post_id").references(() => contentPosts.id, { onDelete: "set null" }),
  taskId: integer("task_id").notNull().unique().references(() => aiTasks.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(), output: jsonb("output").$type<Record<string, unknown>>().notNull(),
  providerKey: text("provider_key").notNull(), reviewFlags: jsonb("review_flags").$type<string[]>().notNull().default([]), sources: jsonb("sources").$type<string[]>().notNull().default([]),
  appliedAt: timestamp("applied_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (t) => ({ scopeIdx: index("studio_generations_scope_idx").on(t.workspaceId, t.businessId) }));
