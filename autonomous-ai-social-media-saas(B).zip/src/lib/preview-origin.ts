type IncomingHeaders = Pick<Headers, "get">;

type PreviewOriginOptions = {
  configuredOrigin?: string;
  sandboxId?: string;
  sandboxDomain?: string;
  port?: number;
  requestHost?: string;
  requestProtocol?: string;
};

function safeOrigin(value: string | undefined): string | null {
  if (!value?.trim()) return null;
  try {
    const url = new URL(value.trim());
    const local = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
    if (url.username || url.password || url.search || url.hash || !["", "/"].includes(url.pathname)) return null;
    if (url.protocol !== "https:" && !(local && url.protocol === "http:")) return null;
    return url.origin;
  } catch { return null; }
}

/** Public address only: never includes traffic tokens, API credentials, or parent-editor query strings. */
export function resolveStandalonePreviewOrigin(options: PreviewOriginOptions): string | null {
  const configured = safeOrigin(options.configuredOrigin);
  if (configured) return configured;
  const domain = options.sandboxDomain || "e2b.app";
  const port = options.port ?? 3000;
  if (options.sandboxId && /^[a-z0-9][a-z0-9-]{2,95}$/i.test(options.sandboxId) &&
      /^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/i.test(domain) &&
      Number.isInteger(port) && port > 0 && port <= 65535) {
    return `https://${port}-${options.sandboxId}.${domain}`;
  }
  const host = options.requestHost?.split(",")[0].trim();
  if (!host || !/^[a-z0-9.:[\]-]+$/i.test(host)) return null;
  const protocol = options.requestProtocol?.split(",")[0].trim() === "http" ? "http" : "https";
  return safeOrigin(`${protocol}://${host}`);
}

/** Server-side runtime resolution; client code receives only the resulting non-secret origin. */
export function standalonePreviewOrigin(incoming: IncomingHeaders) {
  const port = Number(process.env.PORT || 3000);
  return resolveStandalonePreviewOrigin({
    configuredOrigin: process.env.APP_PUBLIC_ORIGIN,
    sandboxId: process.env.E2B_SANDBOX_ID,
    sandboxDomain: process.env.E2B_DOMAIN,
    port,
    requestHost: incoming.get("x-forwarded-host") || incoming.get("host") || undefined,
    requestProtocol: incoming.get("x-forwarded-proto") || undefined,
  });
}
