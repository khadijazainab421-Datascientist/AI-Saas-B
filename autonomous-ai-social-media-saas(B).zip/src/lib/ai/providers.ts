import { ProviderError, type ProviderDefinition, type CompletionRequest, type CompletionResponse, type HealthResult, type ProviderErrorCode } from "./types";

const TIMEOUT_MS = 45_000;

function classifyStatus(status: number, key: string, message: string, retryAfterMs?: number): ProviderError {
  let code: ProviderErrorCode = "unknown";
  if (status === 401 || status === 403) code = "auth";
  else if (status === 429) code = "quota";
  else if (status >= 500) code = "server";
  else if (status === 408 || status === 504) code = "timeout";
  else if (status >= 400) code = "invalid_request";
  return new ProviderError(key, code, message, retryAfterMs, status);
}

function retryAfter(response: Response): number | undefined {
  const value = response.headers.get("retry-after");
  if (!value) return undefined;
  const seconds = Number(value);
  return Number.isFinite(seconds) ? seconds * 1000 : undefined;
}

async function readError(response: Response): Promise<string> {
  const text = await response.text().catch(() => "");
  try {
    const parsed = JSON.parse(text) as { error?: { message?: string } | string; message?: string };
    const nested = parsed.error;
    if (typeof nested === "string") return nested.slice(0, 400);
    return (nested?.message ?? parsed.message ?? `HTTP ${response.status}`).slice(0, 400);
  } catch {
    return `HTTP ${response.status}${text ? `: ${text.slice(0, 200)}` : ""}`;
  }
}

async function postJson(url: string, headers: Record<string, string>, body: unknown, key: string) {
  let response: Response;
  try {
    response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...headers },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(TIMEOUT_MS),
      cache: "no-store",
    });
  } catch (error) {
    const timedOut = error instanceof Error && /timeout|abort/i.test(error.message);
    throw new ProviderError(key, timedOut ? "timeout" : "network", `Network failure contacting ${key}`);
  }
  if (!response.ok) {
    throw classifyStatus(response.status, key, await readError(response), retryAfter(response));
  }
  return response.json() as Promise<Record<string, unknown>>;
}

/* ------------------------------- Gemini ---------------------------------- */

const GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta";

async function geminiComplete(request: CompletionRequest): Promise<CompletionResponse> {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new ProviderError("gemini", "unconfigured", "GEMINI_API_KEY is not configured");
  const model = process.env.GEMINI_MODEL || "gemini-3.8-flash";
  const generationConfig: Record<string, unknown> = {
    temperature: request.temperature ?? 0.4,
    maxOutputTokens: request.maxTokens ?? 2048,
  };
  if (request.jsonMode) generationConfig.responseMimeType = "application/json";

  const data = await postJson(
    `${GEMINI_BASE}/models/${encodeURIComponent(model)}:generateContent`,
    { "x-goog-api-key": key },
    {
      systemInstruction: { parts: [{ text: request.system }] },
      contents: [{ role: "user", parts: [{ text: request.prompt }] }],
      generationConfig,
    },
    "gemini",
  );

  const candidates = data.candidates as Array<{ content?: { parts?: Array<{ text?: string }> } }> | undefined;
  const text = (candidates?.[0]?.content?.parts ?? [])
    .map((part) => part.text ?? "")
    .join("")
    .trim();
  if (!text) throw new ProviderError("gemini", "unknown", "Gemini returned no usable text");
  const usage = (data.usageMetadata ?? {}) as { promptTokenCount?: number; candidatesTokenCount?: number };
  return {
    text,
    model,
    inputTokens: usage.promptTokenCount ?? 0,
    outputTokens: usage.candidatesTokenCount ?? 0,
  };
}

async function modelListHealth(
  key: string,
  url: string,
  headers: Record<string, string>,
  label: string,
): Promise<HealthResult> {
  const value = process.env[key === "gemini" ? "GEMINI_API_KEY" : key === "groq" ? "GROQ_API_KEY" : "OPENAI_API_KEY"];
  if (!value) return { healthy: false, message: `${label} credential is not configured` };
  try {
    const response = await fetch(url, { headers, signal: AbortSignal.timeout(12_000), cache: "no-store" });
    if (!response.ok) {
      return {
        healthy: false,
        message: `${label} health probe returned HTTP ${response.status}: ${await readError(response)}`,
      };
    }
    return { healthy: true, message: `${label} credential accepted; model listing reachable` };
  } catch (error) {
    return {
      healthy: false,
      message: `${label} health probe failed: ${error instanceof Error ? error.message : "network error"}`,
    };
  }
}

/* ------------------------ OpenAI-compatible hosts ------------------------- */

async function chatComplete(
  providerKey: string,
  baseUrl: string,
  apiKey: string,
  model: string,
  request: CompletionRequest,
): Promise<CompletionResponse> {
  const system = request.jsonMode
    ? `${request.system}\n\nRespond with ONE valid JSON object only. Do not use markdown code fences.`
    : request.system;

  const body: Record<string, unknown> = {
    model,
    messages: [
      { role: "system", content: system },
      { role: "user", content: request.prompt },
    ],
    temperature: request.temperature ?? 0.4,
    max_tokens: request.maxTokens ?? 2048,
  };
  if (providerKey === "openai" && request.jsonMode) {
    body.response_format = { type: "json_object" };
  }

  const data = await postJson(
    `${baseUrl}/chat/completions`,
    { Authorization: `Bearer ${apiKey}` },
    body,
    providerKey,
  );
  const choices = data.choices as Array<{ message?: { content?: string } }> | undefined;
  const text = (choices?.[0]?.message?.content ?? "").trim();
  if (!text) throw new ProviderError(providerKey, "unknown", `${providerKey} returned no usable text`);
  const usage = (data.usage ?? {}) as { prompt_tokens?: number; completion_tokens?: number };
  return {
    text,
    model,
    inputTokens: usage.prompt_tokens ?? 0,
    outputTokens: usage.completion_tokens ?? 0,
  };
}

async function groqComplete(request: CompletionRequest): Promise<CompletionResponse> {
  const key = process.env.GROQ_API_KEY;
  if (!key) throw new ProviderError("groq", "unconfigured", "GROQ_API_KEY is not configured");
  const model = process.env.GROQ_MODEL || "openai/gpt-oss-20b";
  const result = await chatComplete("groq", "https://api.groq.com/openai/v1", key, model, request);
  return result;
}

async function openaiComplete(request: CompletionRequest): Promise<CompletionResponse> {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new ProviderError("openai", "unconfigured", "OPENAI_API_KEY is not configured");
  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";
  return chatComplete("openai", "https://api.openai.com/v1", key, model, request);
}

/* ------------------------------- Research -------------------------------- */

async function tavilySearch(query: string, maxResults: number) {
  const key = process.env.TAVILY_API_KEY;
  if (!key) throw new ProviderError("tavily", "unconfigured", "TAVILY_API_KEY is not configured");
  const data = await postJson(
    "https://api.tavily.com/search",
    { Authorization: `Bearer ${key}` },
    {
      query,
      search_depth: "basic",
      max_results: Math.min(Math.max(maxResults, 1), 10),
      include_answer: false,
    },
    "tavily",
  );
  const results = (data.results ?? []) as Array<{ url?: string; title?: string; content?: string }>;
  return {
    sources: results
      .filter((item) => typeof item.url === "string" && /^https?:\/\//.test(item.url))
      .map((item) => ({
        url: item.url as string,
        title: (item.title ?? "Untitled source").slice(0, 300),
        snippet: (item.content ?? "").slice(0, 1200),
      })),
    answer: typeof data.answer === "string" ? data.answer : undefined,
    // Official Tavily credits docs: basic Search = 1 credit.
    credits: 1,
  };
}

async function tavilyHealth(): Promise<HealthResult> {
  const key = process.env.TAVILY_API_KEY;
  if (!key) return { healthy: false, message: "Tavily credential is not configured" };
  try {
    const response = await fetch("https://api.tavily.com/usage", {
      headers: { Authorization: `Bearer ${key}` },
      signal: AbortSignal.timeout(12_000),
      cache: "no-store",
    });
    if (!response.ok) {
      return { healthy: false, message: `Tavily usage probe returned HTTP ${response.status}` };
    }
    const data = (await response.json()) as Record<string, unknown>;
    return {
      healthy: true,
      message: "Tavily credential accepted; usage endpoint reachable",
      quota: {
        used: typeof data.used === "number" ? data.used : undefined,
        limit: typeof data.limit === "number" ? data.limit : undefined,
      },
    };
  } catch (error) {
    return { healthy: false, message: `Tavily health probe failed: ${error instanceof Error ? error.message : "network error"}` };
  }
}

async function braveSearch(query: string, maxResults: number) {
  const key = process.env.BRAVE_API_KEY;
  if (!key) throw new ProviderError("brave", "unconfigured", "BRAVE_API_KEY is not configured");
  const url = new URL("https://api.search.brave.com/res/v1/web/search");
  url.searchParams.set("q", query);
  url.searchParams.set("count", String(Math.min(Math.max(maxResults, 1), 10)));
  let response: Response;
  try {
    response = await fetch(url, {
      headers: { Accept: "application/json", "X-Subscription-Token": key },
      signal: AbortSignal.timeout(TIMEOUT_MS),
      cache: "no-store",
    });
  } catch {
    throw new ProviderError("brave", "network", "Network failure contacting Brave Search API");
  }
  if (!response.ok) {
    throw classifyStatus(response.status, "brave", await readError(response), retryAfter(response));
  }
  const data = (await response.json()) as { web?: { results?: Array<{ url?: string; title?: string; description?: string }> } };
  return {
    sources: (data.web?.results ?? [])
      .filter((item) => typeof item.url === "string" && /^https?:\/\//.test(item.url))
      .map((item) => ({
        url: item.url as string,
        title: (item.title ?? "Untitled source").slice(0, 300),
        snippet: (item.description ?? "").slice(0, 1200),
      })),
    credits: 1,
  };
}

/* ------------------------------- Registry -------------------------------- */

export const PROVIDERS: ProviderDefinition[] = [
  {
    key: "gemini",
    label: "Google Gemini",
    kind: "ai",
    isPaid: false,
    priority: 10,
    envVar: "GEMINI_API_KEY",
    docsUrl: "https://ai.google.dev/gemini-api/docs",
    freeTierNote:
      "Free tier with no credit card. Exact per-project rate limits are shown in AI Studio; quota exhaustion returns HTTP 429 and does not automatically bill.",
    configured: () => Boolean(process.env.GEMINI_API_KEY),
    complete: geminiComplete,
    healthCheck: () =>
      modelListHealth(
        "gemini",
        `${GEMINI_BASE}/models`,
        { "x-goog-api-key": process.env.GEMINI_API_KEY ?? "" },
        "Gemini",
      ),
  },
  {
    key: "groq",
    label: "Groq",
    kind: "ai",
    isPaid: false,
    priority: 20,
    envVar: "GROQ_API_KEY",
    docsUrl: "https://console.groq.com/docs/overview",
    freeTierNote:
      "Free Plan with no credit card. Organization-level RPM/RPD/TPM/TPD limits; 429 with retry-after when exhausted. The paid Developer plan is separate.",
    configured: () => Boolean(process.env.GROQ_API_KEY),
    complete: groqComplete,
    healthCheck: () =>
      modelListHealth(
        "groq",
        "https://api.groq.com/openai/v1/models",
        { Authorization: `Bearer ${process.env.GROQ_API_KEY ?? ""}` },
        "Groq",
      ),
  },
  {
    key: "openai",
    label: "OpenAI (paid, opt-in only)",
    kind: "ai",
    isPaid: true,
    priority: 90,
    envVar: "OPENAI_API_KEY",
    docsUrl: "https://platform.openai.com/docs/api-reference/chat",
    freeTierNote:
      "Paid, usage-billed. Never eligible unless the workspace explicitly authorizes paid providers.",
    configured: () => Boolean(process.env.OPENAI_API_KEY),
    complete: openaiComplete,
    healthCheck: () =>
      modelListHealth(
        "openai",
        "https://api.openai.com/v1/models",
        { Authorization: `Bearer ${process.env.OPENAI_API_KEY ?? ""}` },
        "OpenAI",
      ),
  },
  {
    key: "tavily",
    label: "Tavily Search",
    kind: "research",
    isPaid: false,
    priority: 10,
    envVar: "TAVILY_API_KEY",
    docsUrl: "https://docs.tavily.com/documentation/api-reference/endpoint/search",
    freeTierNote:
      "Researcher plan: 1,000 credits/month, no credit card. Basic Search costs 1 credit; advanced Search costs 2. Pay-as-you-go is opt-in and never enabled automatically.",
    configured: () => Boolean(process.env.TAVILY_API_KEY),
    healthCheck: tavilyHealth,
    search: tavilySearch,
  },
  {
    key: "brave",
    label: "Brave Search (metered, opt-in only)",
    kind: "research",
    isPaid: true,
    priority: 90,
    envVar: "BRAVE_API_KEY",
    docsUrl: "https://api-dashboard.search.brave.com/documentation/pricing",
    freeTierNote:
      "Reported as metered billing with monthly credits and a payment method required. Treated as paid: excluded from automatic fallback unless explicit authorization is given.",
    configured: () => Boolean(process.env.BRAVE_API_KEY),
    healthCheck: async () => ({
      healthy: false,
      message: "No free health probe is performed for a metered provider. Explicit paid authorization is required before use.",
    }),
    search: braveSearch,
  },
];

export function getProvider(key: string): ProviderDefinition | undefined {
  return PROVIDERS.find((provider) => provider.key === key);
}
