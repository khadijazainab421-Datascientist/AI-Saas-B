import { eq, and, gte, desc } from "drizzle-orm";
import { db } from "@/db";
import {
  aiProviderStates,
  aiUsageEvents,
  aiTasks,
  notifications,
} from "@/db/schema";
import { PROVIDERS } from "./providers";
import { taskWorkLog } from "./work-log";
import {
  ProviderError,
  type AttemptRecord,
  type ProviderErrorCode,
  type ProviderDefinition,
} from "./types";
import { getOrCreateSettings } from "@/lib/tenant";
import { finalizeStrategy } from "@/lib/strategy/parse";
import { finalizeStudioGeneration, STUDIO_GENERATION_KINDS, type StudioGenerationKind } from "@/lib/studio/finalize";

type StateRow = typeof aiProviderStates.$inferSelect;
type EligibleProvider = { definition: ProviderDefinition; state: StateRow };
type TaskPayload = {
  system: string;
  prompt: string;
  jsonMode?: boolean;
  maxTokens?: number;
  temperature?: number;
  restrictedTopics?: string[];
  studioPostId?: number;
};

export type RunTaskOptions = TaskPayload & {
  workspaceId: number;
  userId: number;
  businessId?: number | null;
  kind: string;
  taskId?: number;
  allowPaid?: boolean;
};

export type RunTaskResult = {
  status: "completed" | "paused" | "failed";
  taskId: number;
  providerKey?: string;
  text?: string;
  reason?: string;
  strategyId?: number;
  generationId?: number;
  attempts: AttemptRecord[];
};

const DEFAULT_COOLDOWN_MS = 15 * 60 * 1000;

export async function ensureProviderStates() {
  await db
    .insert(aiProviderStates)
    .values(
      PROVIDERS.map((provider) => ({
        providerKey: provider.key,
        kind: provider.kind,
        label: provider.label,
        isPaid: provider.isPaid,
        priority: provider.priority,
      })),
    )
    .onConflictDoNothing({ target: aiProviderStates.providerKey });
}

export async function getProviderStatuses() {
  await ensureProviderStates();
  const states = await db.select().from(aiProviderStates);
  return PROVIDERS.map((definition) => {
    const state = states.find((row) => row.providerKey === definition.key);
    const configured = definition.configured();
    return {
      key: definition.key,
      label: definition.label,
      kind: definition.kind,
      isPaid: definition.isPaid,
      priority: state?.priority ?? definition.priority,
      configured,
      envVar: definition.envVar,
      docsUrl: definition.docsUrl,
      freeTierNote: definition.freeTierNote,
      health: configured
        ? state?.health === "unconfigured" ? "not_checked" : state?.health ?? "not_checked"
        : "unconfigured",
      enabled: state?.enabled ?? true,
      lastCheckedAt: state?.lastCheckedAt ?? null,
      lastError: state?.lastError ?? null,
      quotaExhaustedUntil: state?.quotaExhaustedUntil ?? null,
      totalRequests: state?.totalRequests ?? 0,
      totalInputTokens: state?.totalInputTokens ?? 0,
      totalOutputTokens: state?.totalOutputTokens ?? 0,
      dailyRequestCount: state?.dailyRequestCount ?? 0,
    };
  });
}

export async function runHealthChecks() {
  await ensureProviderStates();
  const results = [];
  for (const definition of PROVIDERS) {
    if (!definition.configured()) {
      await db
        .update(aiProviderStates)
        .set({ health: "unconfigured", lastCheckedAt: new Date(), lastError: null, updatedAt: new Date() })
        .where(eq(aiProviderStates.providerKey, definition.key));
      results.push({ key: definition.key, healthy: false, message: "Credential not configured" });
      continue;
    }
    let result;
    try {
      result = await definition.healthCheck();
    } catch (error) {
      result = { healthy: false, message: error instanceof Error ? error.message : "Health probe failed" };
    }
    await db
      .update(aiProviderStates)
      .set({
        health: result.healthy ? "healthy" : "unavailable",
        lastCheckedAt: new Date(),
        lastError: result.healthy ? null : result.message.slice(0, 500),
        updatedAt: new Date(),
      })
      .where(eq(aiProviderStates.providerKey, definition.key));
    results.push({ key: definition.key, ...result });
  }
  return results;
}

async function updateProviderCounters(
  key: string,
  state: StateRow | undefined,
  usage: { inputTokens: number; outputTokens: number },
  outcome: { health: string; error?: string; cooldownUntil?: Date | null },
) {
  await db
    .update(aiProviderStates)
    .set({
      health: outcome.health,
      lastError: outcome.error ?? null,
      quotaExhaustedUntil: outcome.cooldownUntil ?? null,
      dailyRequestCount: (state?.dailyRequestCount ?? 0) + 1,
      totalRequests: (state?.totalRequests ?? 0) + 1,
      totalInputTokens: (state?.totalInputTokens ?? 0) + usage.inputTokens,
      totalOutputTokens: (state?.totalOutputTokens ?? 0) + usage.outputTokens,
      updatedAt: new Date(),
    })
    .where(eq(aiProviderStates.providerKey, key));
}

async function getEligibleProviders(
  kind: "ai" | "research",
  allowPaid: boolean,
  primaryProvider?: string | null,
): Promise<{ eligible: EligibleProvider[]; reasons: string[] }> {
  await ensureProviderStates();
  const states = await db.select().from(aiProviderStates);
  const now = new Date();
  const eligible: EligibleProvider[] = [];
  const reasons: string[] = [];

  for (const definition of PROVIDERS) {
    if (definition.kind !== kind) continue;
    const state = states.find((row) => row.providerKey === definition.key);
    if (!definition.configured()) {
      reasons.push(`${definition.label}: ${definition.envVar} is not configured`);
      continue;
    }
    if (state && !state.enabled) {
      reasons.push(`${definition.label}: disabled in provider settings`);
      continue;
    }
    if (definition.isPaid && !allowPaid) {
      reasons.push(`${definition.label}: paid provider not authorized by this workspace`);
      continue;
    }
    if (
      state?.health === "quota_exhausted" &&
      state.quotaExhaustedUntil &&
      new Date(state.quotaExhaustedUntil) > now
    ) {
      reasons.push(`${definition.label}: local quota cooldown until ${state.quotaExhaustedUntil.toISOString()}`);
      continue;
    }
    eligible.push({ definition, state: state as StateRow });
  }

  eligible.sort((a, b) => {
    if (primaryProvider) {
      if (a.definition.key === primaryProvider) return -1;
      if (b.definition.key === primaryProvider) return 1;
    }
    return (a.state?.priority ?? a.definition.priority) - (b.state?.priority ?? b.definition.priority);
  });

  return { eligible, reasons };
}

async function countTodayAiRequests(workspaceId: number) {
  const start = new Date();
  start.setUTCHours(0, 0, 0, 0);
  const rows = await db
    .select({ id: aiUsageEvents.id })
    .from(aiUsageEvents)
    .where(and(eq(aiUsageEvents.workspaceId, workspaceId), gte(aiUsageEvents.createdAt, start)));
  return rows.length;
}

async function notify(options: {
  workspaceId: number;
  userId: number;
  type: string;
  title: string;
  body: string;
}) {
  await db.insert(notifications).values(options);
}

function toProviderError(error: unknown, key: string): ProviderError {
  if (error instanceof ProviderError) return error;
  return new ProviderError(
    key,
    "unknown",
    error instanceof Error ? error.message.slice(0, 400) : "Unexpected provider error",
  );
}

export async function runTask(options: RunTaskOptions): Promise<RunTaskResult> {
  const settings = await getOrCreateSettings(options.workspaceId);
  const allowPaid = options.allowPaid ?? settings.allowPaidProviders;

  const payload: TaskPayload = {
    system: options.system,
    prompt: options.prompt,
    jsonMode: options.jsonMode,
    maxTokens: options.maxTokens,
    temperature: options.temperature,
    restrictedTopics: options.restrictedTopics,
    studioPostId: options.studioPostId,
  };

  let taskId = options.taskId;
  let wasPaused = false;
  let existingAttempts: AttemptRecord[] = [];
  let workLog = taskWorkLog(null);

  if (taskId) {
    const [existing] = await db.select().from(aiTasks).where(eq(aiTasks.id, taskId)).limit(1);
    if (!existing || existing.workspaceId !== options.workspaceId) throw new Error("Task not found in this workspace");
    workLog = taskWorkLog(existing.partialResult);
    wasPaused = existing.status === "paused";
    const partial = existing?.partialResult as { attempts?: AttemptRecord[] } | null;
    existingAttempts = Array.isArray(partial?.attempts) ? partial.attempts : [];
    await db
      .update(aiTasks)
      .set({ status: "running", allowPaid, payload, updatedAt: new Date() })
      .where(eq(aiTasks.id, taskId));
  } else {
    const [created] = await db
      .insert(aiTasks)
      .values({
        workspaceId: options.workspaceId,
        businessId: options.businessId ?? null,
        kind: options.kind,
        status: "running",
        payload,
        allowPaid,
        partialResult: { attempts: [] },
      })
      .returning();
    taskId = created.id;
  }

  const attempts: AttemptRecord[] = [...existingAttempts];

  const pause = async (reason: string, detail: string): Promise<RunTaskResult> => {
    await db
      .update(aiTasks)
      .set({
        status: "paused",
        pausedReason: reason,
        error: detail.slice(0, 1000),
        partialResult: workLog.snapshot(attempts),
        resumeAfter: new Date(Date.now() + DEFAULT_COOLDOWN_MS),
        updatedAt: new Date(),
      })
      .where(eq(aiTasks.id, taskId));
    await notify({
      workspaceId: options.workspaceId,
      userId: options.userId,
      type: "task_paused",
      title: "Agent task paused — work preserved",
      body: `${options.kind} was paused because ${detail} No generated work was discarded. The task can be resumed when a provider is available.`,
    });
    return { status: "paused", taskId, reason, attempts };
  };

  const usedToday = await countTodayAiRequests(options.workspaceId);
  if (usedToday >= settings.dailyAiRequestLimit) {
    return pause("workspace_daily_ai_limit", `the workspace daily AI request limit (${settings.dailyAiRequestLimit}) has been reached`);
  }

  const { eligible, reasons } = await getEligibleProviders("ai", allowPaid, settings.primaryProvider);
  if (eligible.length === 0) {
    return pause(
      "no_eligible_provider",
      reasons.length > 0 ? reasons.join("; ") : "no eligible AI provider is configured",
    );
  }

  for (const { definition, state } of eligible) {
    const started = Date.now();
    try {
      const result = await definition.complete!({
        system: options.system,
        prompt: options.prompt,
        jsonMode: options.jsonMode,
        maxTokens: options.maxTokens,
        temperature: options.temperature,
      });

      workLog.append(result.text, definition.key);
      const latencyMs = Date.now() - started;
      attempts.push({
        providerKey: definition.key,
        outcome: "success",
        textPreserved: true,
        outputLength: result.text.length,
        latencyMs,
        at: new Date().toISOString(),
      });

      await db.insert(aiUsageEvents).values({
        workspaceId: options.workspaceId,
        userId: options.userId,
        providerKey: definition.key,
        taskType: options.kind,
        status: "success",
        inputTokens: result.inputTokens,
        outputTokens: result.outputTokens,
        latencyMs,
      });
      await updateProviderCounters(
        definition.key,
        state,
        { inputTokens: result.inputTokens, outputTokens: result.outputTokens },
        { health: "healthy", cooldownUntil: null },
      );

      // Preserve output before any downstream validation so nothing is lost.
      await db
        .update(aiTasks)
        .set({
          partialResult: workLog.snapshot(attempts),
          providerKey: definition.key,
          attempts: attempts.length,
          updatedAt: new Date(),
        })
        .where(eq(aiTasks.id, taskId));

      let strategyId: number | undefined;
      let generationId: number | undefined;
      if (options.businessId && (options.kind === "strategy_generation" || STUDIO_GENERATION_KINDS.includes(options.kind as StudioGenerationKind))) {
        try {
          if (options.kind === "strategy_generation") {
            const strategy = await finalizeStrategy({ taskId, workspaceId: options.workspaceId, businessId: options.businessId, text: result.text, providerKey: definition.key, restrictedTopics: options.restrictedTopics ?? [] });
            strategyId = strategy.id;
          } else {
            const generation = await finalizeStudioGeneration({ taskId, workspaceId: options.workspaceId, businessId: options.businessId, postId: options.studioPostId, kind: options.kind as StudioGenerationKind, text: result.text, providerKey: definition.key, restrictedTopics: options.restrictedTopics ?? [] });
            generationId = generation.id;
          }
        } catch (validationError) {
          await db.update(aiTasks).set({ status: "paused", pausedReason: "output_validation_failed", error: validationError instanceof Error ? validationError.message.slice(0, 800) : "Invalid structured output", partialResult: workLog.snapshot(attempts), resumeAfter: new Date(Date.now() + DEFAULT_COOLDOWN_MS), updatedAt: new Date() }).where(eq(aiTasks.id, taskId));
          await notify({ workspaceId: options.workspaceId, userId: options.userId, type: "task_paused", title: "Generated output held for review", body: "The provider returned output that failed structured validation. Raw work was preserved; no valid draft or strategy is claimed." });
          return { status: "paused", taskId, providerKey: definition.key, text: result.text, reason: "output_validation_failed", attempts };
        }
      }

      await db
        .update(aiTasks)
        .set({
          status: "completed",
          result: strategyId ? { strategyId, providerKey: definition.key } : generationId ? { generationId, providerKey: definition.key } : { text: result.text, providerKey: definition.key },
          providerKey: definition.key,
          attempts: attempts.length,
          completedAt: new Date(),
          pausedReason: null,
          resumeAfter: null,
          updatedAt: new Date(),
        })
        .where(eq(aiTasks.id, taskId));

      if (wasPaused) {
        await notify({
          workspaceId: options.workspaceId,
          userId: options.userId,
          type: "task_resumed",
          title: "Agent task resumed successfully",
          body: `${options.kind} completed using ${definition.label} after a provider interruption.`,
        });
      }

      return {
        status: "completed",
        taskId,
        providerKey: definition.key,
        text: result.text,
        strategyId,
        generationId,
        attempts,
      };
    } catch (error) {
      const failure = toProviderError(error, definition.key);
      const latencyMs = Date.now() - started;
      attempts.push({
        providerKey: definition.key,
        outcome: "error",
        errorCode: failure.code,
        message: failure.message.slice(0, 400),
        latencyMs,
        at: new Date().toISOString(),
      });

      const quotaLike: ProviderErrorCode[] = ["quota", "rate_limit"];
      const health = quotaLike.includes(failure.code)
        ? "quota_exhausted"
        : failure.code === "auth"
          ? "unavailable"
          : "degraded";
      const cooldownUntil =
        health === "quota_exhausted"
          ? new Date(Date.now() + Math.min(Math.max(failure.retryAfterMs ?? DEFAULT_COOLDOWN_MS, 60_000), 24 * 60 * 60 * 1000))
          : null;

      await db.insert(aiUsageEvents).values({
        workspaceId: options.workspaceId,
        userId: options.userId,
        providerKey: definition.key,
        taskType: options.kind,
        status: quotaLike.includes(failure.code) ? "quota" : "error",
        latencyMs,
        errorCode: failure.code,
      });
      await updateProviderCounters(
        definition.key,
        state,
        { inputTokens: 0, outputTokens: 0 },
        { health, error: failure.message.slice(0, 400), cooldownUntil },
      );

      await db
        .update(aiTasks)
        .set({
          attempts: attempts.length,
          partialResult: workLog.snapshot(attempts),
          updatedAt: new Date(),
        })
        .where(eq(aiTasks.id, taskId));
    }
  }

  return pause(
    "all_eligible_providers_unavailable",
    attempts.map((attempt) => `${attempt.providerKey}: ${attempt.errorCode ?? "error"} — ${attempt.message ?? ""}`).join("; "),
  );
}

export async function resumePausedTasks(workspaceId: number, userId: number, taskId?: number) {
  const rows = await db
    .select()
    .from(aiTasks)
    .where(
      taskId
        ? and(eq(aiTasks.workspaceId, workspaceId), eq(aiTasks.id, taskId), eq(aiTasks.status, "paused"))
        : and(eq(aiTasks.workspaceId, workspaceId), eq(aiTasks.status, "paused")),
    )
    .orderBy(desc(aiTasks.createdAt))
    .limit(20);

  const results = [];
  for (const task of rows) {
    const payload = task.payload as TaskPayload | null;
    if (!payload?.system || !payload?.prompt) {
      results.push({ taskId: task.id, status: "skipped", reason: "Task payload is incomplete" });
      continue;
    }
    const result = await runTask({
      workspaceId,
      userId,
      businessId: task.businessId,
      kind: task.kind,
      taskId: task.id,
      ...payload,
    });
    results.push({ taskId: task.id, status: result.status, providerKey: result.providerKey, reason: result.reason });
  }
  return results;
}
