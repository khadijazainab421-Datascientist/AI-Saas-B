export type ProviderKind = "ai" | "research";

export type ProviderErrorCode =
  | "unconfigured"
  | "auth"
  | "quota"
  | "rate_limit"
  | "network"
  | "invalid_request"
  | "server"
  | "timeout"
  | "unknown";

export class ProviderError extends Error {
  constructor(
    public providerKey: string,
    public code: ProviderErrorCode,
    message: string,
    public retryAfterMs?: number,
    public httpStatus?: number,
  ) {
    super(message);
    this.name = "ProviderError";
  }
}

export type CompletionRequest = {
  system: string;
  prompt: string;
  maxTokens?: number;
  temperature?: number;
  jsonMode?: boolean;
};

export type CompletionResponse = {
  text: string;
  model: string;
  inputTokens: number;
  outputTokens: number;
  quota?: {
    remainingRequests?: number;
    remainingTokens?: number;
    resetAt?: string;
  };
};

export type HealthResult = {
  healthy: boolean;
  message: string;
  quota?: { used?: number; limit?: number; resetAt?: string };
};

export type ProviderDefinition = {
  key: string;
  label: string;
  kind: ProviderKind;
  isPaid: boolean;
  priority: number;
  envVar: string;
  docsUrl: string;
  freeTierNote: string;
  configured: () => boolean;
  complete?: (request: CompletionRequest) => Promise<CompletionResponse>;
  healthCheck: () => Promise<HealthResult>;
  /** Research providers only. */
  search?: (query: string, maxResults: number) => Promise<{
    sources: Array<{ url: string; title: string; snippet: string }>;
    answer?: string;
    credits: number;
    quota?: { used?: number; limit?: number };
  }>;
};

export type AttemptRecord = {
  providerKey: string;
  outcome: "success" | "error";
  errorCode?: ProviderErrorCode;
  message?: string;
  textPreserved?: boolean;
  /** Length only; full output is stored in the task result/partialResult. */
  outputLength?: number;
  latencyMs?: number;
  at: string;
};
