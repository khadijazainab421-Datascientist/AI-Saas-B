import type { AttemptRecord } from "./types";
type Output = { text: string; providerKey?: string; at?: string };

/** A retry/pause may append work, never erase an earlier provider response. */
export function taskWorkLog(partial: unknown) {
  const base = partial && typeof partial === "object" ? partial as Record<string, unknown> : {};
  const outputs: Output[] = Array.isArray(base.outputs) ? base.outputs.filter((value): value is Output => Boolean(value && typeof value === "object" && typeof (value as Output).text === "string")) : [];
  if (typeof base.rawOutput === "string" && !outputs.some((item) => item.text === base.rawOutput)) outputs.push({ text: base.rawOutput });
  return {
    append(text: string, providerKey: string) { outputs.push({ text, providerKey, at: new Date().toISOString() }); },
    snapshot(attempts: AttemptRecord[]): Record<string, unknown> & { attempts: AttemptRecord[]; outputs: Output[]; rawOutput: unknown } { return { ...base, attempts, outputs: [...outputs], rawOutput: outputs[outputs.length - 1]?.text ?? base.rawOutput }; },
  };
}
