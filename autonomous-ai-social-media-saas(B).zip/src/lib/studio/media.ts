import sharp from "sharp";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { mediaAssets } from "@/db/schema";
import type { TenantContext } from "@/lib/tenant";
import { assetColumns, ownBusiness } from "./repository";
import { StudioError } from "./errors";
import { selectStockPhoto } from "./unsplash";

export const UPLOAD_LIMIT = 5 * 1024 * 1024;
export async function limitedBytes(request: Request, maximum: number) {
  if (Number(request.headers.get("content-length") || 0) > maximum) throw new StudioError("File/request exceeds the allowed size.", 413);
  const reader = request.body?.getReader();
  if (!reader) throw new StudioError("No upload body was received.");
  const chunks: Buffer[] = []; let total = 0;
  while (true) {
    const item = await reader.read(); if (item.done) break;
    total += item.value.byteLength;
    if (total > maximum) { await reader.cancel(); throw new StudioError("File/request exceeds the allowed size.", 413); }
    chunks.push(Buffer.from(item.value));
  }
  return Buffer.concat(chunks);
}
function imageSignature(buffer: Buffer) {
  return (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) ||
    buffer.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10])) ||
    (buffer.toString("ascii", 0, 4) === "RIFF" && buffer.toString("ascii", 8, 12) === "WEBP");
}
export async function uploadAsset(actor: TenantContext, request: Request) {
  const type = request.headers.get("content-type") ?? "";
  if (!type.startsWith("multipart/form-data")) throw new StudioError("Use an image file upload.");
  const bytes = await limitedBytes(request, UPLOAD_LIMIT + 65_536);
  const form = await new Response(new Uint8Array(bytes), { headers: { "Content-Type": type } }).formData();
  const file = form.get("file");
  const businessId = Number(form.get("businessId"));
  if (!(file instanceof File) || !file.size || file.size > UPLOAD_LIMIT) throw new StudioError("Choose a JPG, PNG, or WebP image no larger than 5 MiB.");
  if (!Number.isSafeInteger(businessId) || businessId < 1) throw new StudioError("Choose a business before uploading.");
  await ownBusiness(actor.workspaceId, businessId);
  const input = Buffer.from(await file.arrayBuffer());
  if (!imageSignature(input)) throw new StudioError("Only real JPG, PNG, and WebP images are supported. SVG, scripts, and videos are not accepted as image uploads.");
  let normalized: { data: Buffer; info: { width: number; height: number; size: number } };
  try {
    normalized = await sharp(input, { limitInputPixels: 24_000_000, failOn: "warning" }).rotate().resize({ width: 1800, height: 1800, fit: "inside", withoutEnlargement: true }).webp({ quality: 88 }).toBuffer({ resolveWithObject: true });
  } catch { throw new StudioError("This image could not be decoded safely or has excessive pixel dimensions."); }
  const [asset] = await db.insert(mediaAssets).values({
    workspaceId: actor.workspaceId, businessId, createdBy: actor.userId,
    name: file.name.replace(/[\\/\u0000-\u001f]/g, "_").slice(0, 180) || "Uploaded image",
    mimeType: "image/webp", kind: "image", body: normalized.data, byteSize: normalized.info.size,
    width: normalized.info.width, height: normalized.info.height, source: "upload", altText: String(form.get("altText") || "").slice(0, 1000),
  }).returning(assetColumns);
  return asset;
}
export async function linkStockAsset(actor: TenantContext, businessId: number, photoId: string) {
  await ownBusiness(actor.workspaceId, businessId);
  const selected = await selectStockPhoto(photoId);
  const [asset] = await db.insert(mediaAssets).values({ workspaceId: actor.workspaceId, businessId, createdBy: actor.userId, name: selected.altText || `Photo by ${selected.photographer}`, mimeType: "image/jpeg", kind: "image", source: "unsplash", providerId: selected.id, remoteUrl: selected.url, sourceUrl: selected.sourceUrl, photographer: selected.photographer, photographerUrl: selected.photographerUrl, altText: selected.altText, width: selected.width, height: selected.height }).returning(assetColumns);
  return asset;
}
export async function ownAsset(workspaceId: number, id: number) {
  const [asset] = await db.select().from(mediaAssets).where(and(eq(mediaAssets.id, id), eq(mediaAssets.workspaceId, workspaceId))).limit(1);
  if (!asset) throw new StudioError("Media not found in this workspace.", 404);
  return asset;
}
