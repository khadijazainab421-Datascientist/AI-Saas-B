import { StudioError } from "./errors";

export type StockPhoto = { id: string; url: string; thumbnail: string; sourceUrl: string; photographer: string; photographerUrl: string; altText: string; width: number; height: number };
function trusted(value: unknown, hostname: string) {
  if (typeof value !== "string") throw new StudioError("The photo provider returned an invalid link.", 502);
  const url = new URL(value);
  if (url.protocol !== "https:" || url.hostname !== hostname || url.username || url.password) throw new StudioError("The photo provider returned an unsupported link.", 502);
  return url;
}
function referral(value: unknown) {
  const url = trusted(value, "unsplash.com"); url.searchParams.set("utm_source", "serein"); url.searchParams.set("utm_medium", "referral"); return url.href;
}
async function unsplash(path: string) {
  const key = process.env.UNSPLASH_ACCESS_KEY;
  if (!key) throw new StudioError("Stock photo search is pending: configure UNSPLASH_ACCESS_KEY server-side. Upload your own licensed image instead.", 424);
  let response: Response;
  try { response = await fetch(`https://api.unsplash.com${path}`, { headers: { Authorization: `Client-ID ${key}`, "Accept-Version": "v1" }, signal: AbortSignal.timeout(12_000), cache: "no-store", redirect: "error" }); }
  catch { throw new StudioError("The stock photo provider could not be reached. No result is assumed.", 502); }
  if (!response.ok) throw new StudioError(response.status === 429 || response.status === 403 ? "Stock provider quota/access is unavailable. Check its dashboard before retrying; no paid fallback was used." : `Stock provider returned HTTP ${response.status}.`, response.status === 429 ? 429 : 502);
  return { data: await response.json() as Record<string, unknown>, quota: { limit: response.headers.get("x-ratelimit-limit"), remaining: response.headers.get("x-ratelimit-remaining") } };
}
function photo(data: Record<string, unknown>): StockPhoto {
  const urls = data.urls as Record<string, unknown>;
  const links = data.links as Record<string, unknown>;
  const user = data.user as { name?: string; links?: { html?: string } };
  if (typeof data.id !== "string" || !urls || !links || !user) throw new StudioError("Stock provider response was incomplete.", 502);
  return { id: data.id, url: trusted(urls.regular, "images.unsplash.com").href, thumbnail: trusted(urls.small, "images.unsplash.com").href, sourceUrl: referral(links.html), photographer: (user.name ?? "Unsplash contributor").slice(0, 200), photographerUrl: referral(user.links?.html), altText: typeof data.alt_description === "string" ? data.alt_description.slice(0, 1000) : "", width: Number(data.width) || 0, height: Number(data.height) || 0 };
}
export async function searchStock(query: string) {
  if (query.trim().length < 2 || query.length > 150) throw new StudioError("Use a photo query of 2–150 characters.");
  const { data, quota } = await unsplash(`/search/photos?query=${encodeURIComponent(query.trim())}&per_page=12&content_filter=high`);
  if (!Array.isArray(data.results)) throw new StudioError("Stock search did not return a valid result list.", 502);
  return { photos: data.results.map((item) => photo(item as Record<string, unknown>)), quota };
}
export async function selectStockPhoto(id: string) {
  if (!/^[a-z0-9_-]{3,80}$/i.test(id)) throw new StudioError("Choose a valid provider photo.");
  const { data } = await unsplash(`/photos/${encodeURIComponent(id)}`);
  const selected = photo(data);
  // Per official API guidelines, choosing a photo in a creation workflow triggers download tracking.
  await unsplash(`/photos/${encodeURIComponent(id)}/download`);
  return selected;
}
