import type { BrandStyle } from "./types";

export function escapeXml(text: string) { return text.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" })[char]!); }
function wrapped(text: string, max: number, limit: number) {
  const lines: string[] = []; let line = "";
  for (const word of text.replace(/\s+/g, " ").split(" ")) {
    if ((line + " " + word).trim().length > max && line) { lines.push(line); line = word; }
    else line = `${line} ${word}`.trim();
  }
  if (line) lines.push(line);
  const result = lines.slice(0, limit);
  if (lines.length > limit) result[result.length - 1] = result[result.length - 1].slice(0, -1) + "…";
  return result;
}
export function graphicSvg(options: { brand: string; heading: string; body: string; style: BrandStyle; index?: number; count?: number; imageData?: string; logoData?: string }) {
  const { style } = options;
  const size = options.heading.length > 100 ? 48 : options.heading.length > 55 ? 60 : 76;
  const lines = wrapped(options.heading, size < 60 ? 35 : 25, 5);
  const headingY = 255;
  const bodyY = headingY + lines.length * (size + 8) + 50;
  const bodySize = options.body.length > 650 ? 25 : 31;
  const bodyLines = wrapped(options.body, bodySize === 25 ? 65 : 51, Math.max(1, Math.floor((910 - bodyY) / (bodySize + 13))));
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1080" viewBox="0 0 1080 1080"><rect width="1080" height="1080" fill="${style.background}"/>${options.imageData ? `<image href="${options.imageData}" width="1080" height="1080" preserveAspectRatio="xMidYMid slice" opacity="0.16"/><rect width="1080" height="1080" fill="${style.background}" opacity="0.55"/>` : ""}<circle cx="1020" cy="70" r="270" fill="none" stroke="${style.accent}" stroke-opacity="0.15"/><circle cx="1020" cy="70" r="225" fill="none" stroke="${style.accent}" stroke-opacity="0.1"/><path d="M80 135h50" stroke="${style.accent}" stroke-width="2"/><text x="148" y="142" font-family="sans-serif" font-size="20" letter-spacing="3" fill="${style.accent}">${escapeXml(options.brand.slice(0, 55).toUpperCase())}</text><text fill="${style.foreground}" font-family="${style.font === "editorial" ? "Georgia, serif" : "sans-serif"}" font-size="${size}">${lines.map((line, i) => `<tspan x="80" y="${headingY + i * (size + 8)}">${escapeXml(line)}</tspan>`).join("")}</text><text fill="${style.foreground}" fill-opacity="0.76" font-family="sans-serif" font-size="${bodySize}">${bodyLines.map((line, i) => `<tspan x="82" y="${bodyY + i * (bodySize + 13)}">${escapeXml(line)}</tspan>`).join("")}</text><path d="M80 974h920" stroke="${style.accent}" stroke-opacity="0.3"/><text x="82" y="1021" font-family="sans-serif" font-size="19" letter-spacing="2" fill="${style.accent}">${escapeXml(options.brand.slice(0, 60))}</text><text x="994" y="1021" text-anchor="end" font-family="sans-serif" font-size="18" fill="${style.accent}">${String((options.index ?? 0) + 1).padStart(2, "0")} / ${String(options.count ?? 1).padStart(2, "0")}</text>${options.logoData ? `<image href="${options.logoData}" x="890" y="75" width="110" height="110" preserveAspectRatio="xMidYMid meet"/>` : ""}</svg>`;
}
