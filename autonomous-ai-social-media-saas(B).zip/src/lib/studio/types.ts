import { z } from "zod";

export const platformSchema = z.enum(["instagram", "facebook", "linkedin"]);
export type Platform = z.infer<typeof platformSchema>;
export const formatSchema = z.enum(["post", "carousel", "video"]);
export type ContentFormat = z.infer<typeof formatSchema>;
export const slideSchema = z.object({
  id: z.string().min(1).max(80),
  heading: z.string().max(160),
  body: z.string().max(1400),
  altText: z.string().max(1000).default(""),
  imageAssetId: z.number().int().positive().nullable().default(null),
}).strict();
export type Slide = z.infer<typeof slideSchema>;
export const captionsSchema = z.object({ instagram: z.string().max(10000), facebook: z.string().max(10000), linkedin: z.string().max(10000) }).strict();
export const draftSchema = z.object({
  title: z.string().trim().min(1, "Give this draft a title").max(180),
  format: formatSchema,
  platforms: z.array(platformSchema).min(1).max(3).refine((items) => new Set(items).size === items.length, "Choose each channel only once"),
  brief: z.string().max(6000).default(""),
  caption: z.string().max(10000).default(""),
  platformCaptions: captionsSchema.default({ instagram: "", facebook: "", linkedin: "" }),
  hashtags: z.array(z.string().trim().min(1).max(100)).max(30).default([]),
  slides: z.array(slideSchema).max(10).default([]),
  videoScript: z.string().max(15000).default(""),
  primaryMediaId: z.number().int().positive().nullable().default(null),
}).strict();
export type DraftInput = z.infer<typeof draftSchema>;
export const styleSchema = z.object({
  background: z.string().regex(/^#[0-9a-f]{6}$/i),
  foreground: z.string().regex(/^#[0-9a-f]{6}$/i),
  accent: z.string().regex(/^#[0-9a-f]{6}$/i),
  font: z.enum(["editorial", "modern"]),
  logoAssetId: z.number().int().positive().nullable(),
}).strict();
export type BrandStyle = z.infer<typeof styleSchema>;
export const DEFAULT_STYLE: BrandStyle = { background: "#F0F6F2", foreground: "#172B29", accent: "#155E59", font: "editorial", logoAssetId: null };
export type PostStatus = "draft" | "in_review" | "approved" | "scheduled" | "archived";
export type PostDTO = {
  id: number; businessId: number; title: string; format: string; platforms: Platform[];
  document: DraftInput; status: PostStatus; version: number; reviewFlags: string[];
  approvedAt: string | null; approvedBy: number | null; scheduledAt: string | null;
  timeZone: string; createdAt: string; updatedAt: string;
};
export type AssetDTO = {
  id: number; businessId: number | null; name: string; mimeType: string; kind: string;
  byteSize: number; width: number | null; height: number | null; source: string;
  remoteUrl: string | null; sourceUrl: string | null; photographer: string | null;
  photographerUrl: string | null; altText: string; createdAt: string;
};
export type GenerationDTO = { id: number; businessId: number; postId: number | null; taskId: number; kind: string; output: Record<string, unknown>; reviewFlags: string[]; sources: string[]; providerKey: string; appliedAt: string | null; createdAt: string };
export type RevisionDTO = { id: number; version: number; action: string; actorId: number; snapshot: { document: DraftInput; status: string; scheduledAt: string | null; timeZone: string }; createdAt: string };
export type StudioBootstrap = {
  businesses: Array<{ id: number; name: string; website: string | null }>;
  posts: PostDTO[]; assets: AssetDTO[]; generations: GenerationDTO[]; style: BrandStyle;
  actorRole: string; capabilities: { aiConfigured: boolean; stockConfigured: boolean; videoProcessing: boolean; publishing: false; uploadLimitBytes: number };
};

export function emptyDraft(format: ContentFormat = "post"): DraftInput {
  return { title: "Untitled draft", format, platforms: ["instagram"], brief: "", caption: "", platformCaptions: { instagram: "", facebook: "", linkedin: "" }, hashtags: [], slides: [], videoScript: "", primaryMediaId: null };
}
