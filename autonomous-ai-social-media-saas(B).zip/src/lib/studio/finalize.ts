import { z } from "zod";
import { randomUUID } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { studioGenerations, researchSources, contentPosts } from "@/db/schema";
import { detectReviewFlags } from "@/lib/strategy/parse";

const tagList = z.array(z.string().trim().min(1).max(100)).max(30).default([]);
const channelCaptions = z.object({ instagram: z.string().max(10000).default(""), facebook: z.string().max(10000).default(""), linkedin: z.string().max(10000).default("") }).default({ instagram: "", facebook: "", linkedin: "" });
const ideaSchema = z.object({ title: z.string().min(1).max(180), brief: z.string().min(1).max(2000), format: z.enum(["post", "carousel", "video"]), pillar: z.string().max(200).default("") });
const schemas = {
  studio_ideas: z.object({ ideas: z.array(ideaSchema).min(1).max(12) }),
  studio_caption: z.object({ caption: z.string().min(1).max(10000), hashtags: tagList, platformCaptions: channelCaptions }),
  studio_carousel: z.object({ caption: z.string().max(10000).default(""), hashtags: tagList, slides: z.array(z.object({ heading: z.string().min(1).max(160), body: z.string().max(1400), altText: z.string().max(1000).default("") })).min(2).max(10) }),
  studio_video_script: z.object({ script: z.string().min(1).max(15000), shotList: z.array(z.object({ scene: z.string().max(300), direction: z.string().max(1000) })).max(20).default([]) }),
};
export type StudioGenerationKind = keyof typeof schemas;
export const STUDIO_GENERATION_KINDS = Object.keys(schemas) as StudioGenerationKind[];
export function parseStudioOutput(kind: StudioGenerationKind, text: string) {
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "");
  let parsed: unknown;
  try { parsed = JSON.parse(cleaned); } catch {
    const start = cleaned.indexOf("{"); const end = cleaned.lastIndexOf("}");
    if (start < 0 || end <= start) throw new Error("The provider did not return a JSON object.");
    parsed = JSON.parse(cleaned.slice(start, end + 1));
  }
  const output = schemas[kind].parse(parsed) as unknown as Record<string, unknown>;
  if (kind === "studio_carousel") output.slides = (output.slides as Array<Record<string, unknown>>).map((slide) => ({ ...slide, id: randomUUID(), imageAssetId: null }));
  if (Array.isArray(output.hashtags)) output.hashtags = [...new Set((output.hashtags as string[]).map((tag) => tag.replace(/^#+/, "").trim()).filter(Boolean))];
  return output;
}
export async function finalizeStudioGeneration(options: { taskId: number; workspaceId: number; businessId: number; postId?: number; kind: StudioGenerationKind; text: string; providerKey: string; restrictedTopics?: string[] }) {
  const output = parseStudioOutput(options.kind, options.text);
  if (options.postId) {
    const [post] = await db.select({ id: contentPosts.id }).from(contentPosts).where(and(eq(contentPosts.id, options.postId), eq(contentPosts.workspaceId, options.workspaceId), eq(contentPosts.businessId, options.businessId))).limit(1);
    if (!post) throw new Error("The generation target no longer belongs to this business/workspace.");
  }
  const sources = await db.select({ url: researchSources.url }).from(researchSources).where(and(eq(researchSources.workspaceId, options.workspaceId), eq(researchSources.businessId, options.businessId))).limit(20);
  const values = { workspaceId: options.workspaceId, businessId: options.businessId, postId: options.postId ?? null, taskId: options.taskId, kind: options.kind, output, providerKey: options.providerKey, sources: sources.map((s) => s.url), reviewFlags: detectReviewFlags(JSON.stringify(output), options.restrictedTopics ?? []) };
  const [inserted] = await db.insert(studioGenerations).values(values).onConflictDoNothing({ target: studioGenerations.taskId }).returning();
  if (inserted) return inserted;
  const [existing] = await db.select().from(studioGenerations).where(and(eq(studioGenerations.taskId, options.taskId), eq(studioGenerations.workspaceId, options.workspaceId))).limit(1);
  if (!existing) throw new Error("Generation could not be stored safely.");
  return existing;
}
