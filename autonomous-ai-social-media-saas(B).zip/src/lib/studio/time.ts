import { fromZonedTime, formatInTimeZone } from "date-fns-tz";
import { StudioError } from "./errors";

export function scheduleInstant(wallTime: string, timeZone: string, now = new Date()) {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(wallTime)) throw new StudioError("Choose a date and time.");
  try { new Intl.DateTimeFormat("en", { timeZone }).format(now); } catch { throw new StudioError("Choose a valid IANA time zone."); }
  const instant = fromZonedTime(wallTime, timeZone);
  if (!Number.isFinite(instant.getTime()) || formatInTimeZone(instant, timeZone, "yyyy-MM-dd'T'HH:mm") !== wallTime) {
    throw new StudioError("That local time does not exist in the selected time zone. Choose another time (daylight-saving change).");
  }
  const ambiguous = [-7_200_000, -3_600_000, -1_800_000, 1_800_000, 3_600_000, 7_200_000].some((offset) => formatInTimeZone(new Date(instant.getTime() + offset), timeZone, "yyyy-MM-dd'T'HH:mm") === wallTime);
  if (ambiguous) throw new StudioError("That local time occurs twice during a daylight-saving change. Choose an unambiguous time.");
  if (instant.getTime() <= now.getTime() + 60_000) throw new StudioError("Choose a time at least one minute in the future.");
  return instant;
}
