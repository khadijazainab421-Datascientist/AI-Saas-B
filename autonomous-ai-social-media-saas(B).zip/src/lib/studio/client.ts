"use client";

import { apiFetch } from "@/lib/api-fetch";
export class StudioClientError extends Error { constructor(message: string, public status: number) { super(message); } }
export async function studioApi<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (init.body && !(init.body instanceof FormData)) headers.set("Content-Type", "application/json");
  const response = await apiFetch(path, { ...init, headers, signal: init.signal ?? AbortSignal.timeout(125_000) });
  const data = await response.json().catch(() => ({})) as T & { error?: string };
  if (!response.ok) throw new StudioClientError(data.error || `Request failed (${response.status}).`, response.status);
  return data;
}
export async function downloadStudioFile(path: string) {
  const response = await apiFetch(path, { signal: AbortSignal.timeout(65_000) });
  if (!response.ok) { const data = await response.json().catch(() => ({})) as { error?: string }; throw new Error(data.error || "Export did not complete."); }
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a"); link.href = url; link.download = response.headers.get("content-disposition")?.match(/filename="([^"]+)"/)?.[1] || "serein-export";
  document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
