import { NextResponse } from "next/server";
import { ZodError } from "zod";

export class StudioError extends Error {
  constructor(message: string, public status = 400) { super(message); this.name = "StudioError"; }
}
export function studioFailure(error: unknown) {
  if (error instanceof ZodError) return NextResponse.json({ error: error.issues.map((issue) => `${issue.path.join(".") || "Input"}: ${issue.message}`).slice(0, 5).join("; ") }, { status: 400 });
  if (error instanceof StudioError) return NextResponse.json({ error: error.message }, { status: error.status });
  return NextResponse.json({ error: "The studio could not complete this operation. No success is assumed; refresh the saved record before retrying." }, { status: 500 });
}
export function positiveId(value: unknown, label = "ID") {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isSafeInteger(parsed) || parsed < 1) throw new StudioError(`Choose a valid ${label}.`);
  return parsed;
}
export async function studioBody(request: Request) {
  if (Number(request.headers.get("content-length") || 0) > 150_000) throw new StudioError("This editor request is too large.", 413);
  try {
    const reader = request.body?.getReader();
    if (!reader) throw new StudioError("An editor request body is required.");
    const chunks: Uint8Array[] = []; let size = 0;
    while (true) {
      const part = await reader.read(); if (part.done) break;
      size += part.value.byteLength;
      if (size > 150_000) { await reader.cancel(); throw new StudioError("This editor request is too large.", 413); }
      chunks.push(part.value);
    }
    const text = Buffer.concat(chunks.map((chunk) => Buffer.from(chunk))).toString("utf8");
    const result: unknown = JSON.parse(text);
    if (!result || typeof result !== "object" || Array.isArray(result)) throw new Error();
    return result as Record<string, unknown>;
  } catch (error) { if (error instanceof StudioError) throw error; throw new StudioError("Send a valid JSON editor request."); }
}
