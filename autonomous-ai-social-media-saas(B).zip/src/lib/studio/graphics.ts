import sharp from "sharp";
import { zipSync, strToU8 } from "fflate";
import type { BrandStyle, DraftInput } from "./types";
import { ownAsset } from "./media";
import { StudioError } from "./errors";

import { graphicSvg } from "./graphic-template";

async function imageData(workspaceId: number, id: number | null) {
  if (!id) return undefined;
  const asset = await ownAsset(workspaceId, id);
  if (!asset.body || asset.source !== "upload") throw new StudioError("Linked stock photos stay hotlinked in the app. For local template export, remove that image or choose an uploaded, licensed image.", 409);
  const png = await sharp(asset.body, { limitInputPixels: 24_000_000 }).resize({ width: 1600, height: 1600, fit: "inside" }).png().toBuffer();
  return `data:image/png;base64,${png.toString("base64")}`;
}
export async function exportGraphics(workspaceId: number, brand: string, document: DraftInput, style: BrandStyle, bundle: boolean) {
  const slides = document.format === "carousel" ? document.slides : [{ heading: document.title, body: document.caption || document.videoScript, imageAssetId: document.primaryMediaId }];
  if (!slides.length) throw new StudioError("Add carousel slides before exporting.");
  const logoData = await imageData(workspaceId, style.logoAssetId);
  const files: Record<string, Uint8Array> = {};
  for (let index = 0; index < (bundle ? slides.length : 1); index++) {
    const slide = slides[index];
    const backgroundData = await imageData(workspaceId, slide.imageAssetId ?? document.primaryMediaId);
    const svg = graphicSvg({ brand, heading: slide.heading, body: slide.body, style, index, count: slides.length, imageData: backgroundData, logoData });
    files[`slide-${String(index + 1).padStart(2, "0")}.png`] = await sharp(Buffer.from(svg)).png().toBuffer();
  }
  if (!bundle) return { bytes: files["slide-01.png"], mimeType: "image/png", filename: "serein-graphic.png" };
  files["caption.txt"] = strToU8([document.caption, document.hashtags.map((t) => `#${t.replace(/^#/, "")}`).join(" ")].filter(Boolean).join("\n\n"));
  files["draft.json"] = strToU8(JSON.stringify({ document, notice: "Exported editable draft assets. Not published. Review platform requirements and source rights before use. Full text is preserved here if a visual template wraps/truncates it." }, null, 2));
  return { bytes: zipSync(files, { level: 0 }), mimeType: "application/zip", filename: "serein-carousel.zip" };
}
