import { and, eq, desc, inArray, isNull, or } from "drizzle-orm";
import { db } from "@/db";
import { businesses, brandProfiles, contentPosts, contentRevisions, studioGenerations, studioBrandStyles, mediaAssets } from "@/db/schema";
import { getWorkspaceMembership, getBusinessesForWorkspace } from "@/lib/auth-server";
import type { TenantContext } from "@/lib/tenant";
import { detectReviewFlags } from "@/lib/strategy/parse";
import { PROVIDERS } from "@/lib/ai/providers";
import { DEFAULT_STYLE, draftSchema, styleSchema, type DraftInput, type PostDTO, type PostStatus, type BrandStyle } from "./types";
import { positiveId, StudioError } from "./errors";
import { scheduleInstant } from "./time";

export type PostRow = typeof contentPosts.$inferSelect;
export const assetColumns = { id: mediaAssets.id, businessId: mediaAssets.businessId, name: mediaAssets.name, mimeType: mediaAssets.mimeType, kind: mediaAssets.kind, byteSize: mediaAssets.byteSize, width: mediaAssets.width, height: mediaAssets.height, source: mediaAssets.source, remoteUrl: mediaAssets.remoteUrl, sourceUrl: mediaAssets.sourceUrl, photographer: mediaAssets.photographer, photographerUrl: mediaAssets.photographerUrl, altText: mediaAssets.altText, createdAt: mediaAssets.createdAt };
export function postDTO(row: PostRow): PostDTO {
  return { id: row.id, businessId: row.businessId, title: row.title, format: row.format, platforms: row.platforms, document: row.document, status: row.status as PostStatus, version: row.version, reviewFlags: row.reviewFlags, approvedAt: row.approvedAt?.toISOString() ?? null, approvedBy: row.approvedBy, scheduledAt: row.scheduledAt?.toISOString() ?? null, timeZone: row.timeZone, createdAt: row.createdAt.toISOString(), updatedAt: row.updatedAt.toISOString() };
}
function snapshot(row: PostRow) { return { document: row.document, status: row.status, scheduledAt: row.scheduledAt?.toISOString() ?? null, timeZone: row.timeZone }; }
export async function ownBusiness(workspaceId: number, businessId: number) {
  const [business] = await db.select().from(businesses).where(and(eq(businesses.id, businessId), eq(businesses.workspaceId, workspaceId))).limit(1);
  if (!business) throw new StudioError("Business not found in this workspace.", 404);
  return business;
}
export async function ownPost(workspaceId: number, postId: number) {
  const [post] = await db.select().from(contentPosts).where(and(eq(contentPosts.id, postId), eq(contentPosts.workspaceId, workspaceId))).limit(1);
  if (!post) throw new StudioError("Draft not found in this workspace.", 404);
  return post;
}
async function restricted(workspaceId: number, businessId: number) {
  const [profile] = await db.select({ topics: brandProfiles.restrictedTopics }).from(brandProfiles).where(and(eq(brandProfiles.workspaceId, workspaceId), eq(brandProfiles.businessId, businessId))).limit(1);
  return profile?.topics ?? [];
}
function flagsFor(document: DraftInput, topics: string[]) {
  return detectReviewFlags([document.title, document.caption, ...Object.values(document.platformCaptions), ...document.slides.flatMap((s) => [s.heading, s.body]), document.videoScript].join("\n"), topics);
}
async function validateMedia(workspaceId: number, businessId: number, document: DraftInput) {
  const ids = [...new Set([document.primaryMediaId, ...document.slides.map((s) => s.imageAssetId)].filter((id): id is number => id !== null))];
  if (!ids.length) return;
  const rows = await db.select({ id: mediaAssets.id }).from(mediaAssets).where(and(eq(mediaAssets.workspaceId, workspaceId), inArray(mediaAssets.id, ids), or(eq(mediaAssets.businessId, businessId), isNull(mediaAssets.businessId))));
  if (rows.length !== ids.length) throw new StudioError("One of the selected media assets is unavailable to this business.", 400);
}
export async function brandStyle(workspaceId: number, businessId: number): Promise<BrandStyle> {
  const [row] = await db.select().from(studioBrandStyles).where(and(eq(studioBrandStyles.workspaceId, workspaceId), eq(studioBrandStyles.businessId, businessId))).limit(1);
  return row?.style ?? { ...DEFAULT_STYLE };
}
export async function saveBrandStyle(actor: TenantContext, businessId: number, input: unknown) {
  await ownBusiness(actor.workspaceId, businessId);
  const membership = await getWorkspaceMembership(actor.workspaceId, actor.userId);
  if (!["owner", "admin"].includes(membership?.role ?? "")) throw new StudioError("Only owners/admins may change the saved brand kit.", 403);
  const style = styleSchema.parse(input);
  if (style.logoAssetId) {
    const [logo] = await db.select({ id: mediaAssets.id, kind: mediaAssets.kind, source: mediaAssets.source }).from(mediaAssets).where(and(eq(mediaAssets.id, style.logoAssetId), eq(mediaAssets.workspaceId, actor.workspaceId), or(eq(mediaAssets.businessId, businessId), isNull(mediaAssets.businessId)))).limit(1);
    if (!logo || logo.kind !== "image" || logo.source !== "upload") throw new StudioError("Choose an uploaded image from this business as the logo; linked stock is not treated as a logo license.");
  }
  await db.insert(studioBrandStyles).values({ workspaceId: actor.workspaceId, businessId, style }).onConflictDoUpdate({ target: studioBrandStyles.businessId, set: { style, updatedAt: new Date() } });
  return style;
}
export async function studioBootstrap(actor: TenantContext, businessId?: number) {
  const allBusinesses = await getBusinessesForWorkspace(actor.workspaceId);
  const selected = businessId ?? allBusinesses[0]?.id;
  if (selected) await ownBusiness(actor.workspaceId, selected);
  const membership = await getWorkspaceMembership(actor.workspaceId, actor.userId);
  const posts = selected ? await db.select().from(contentPosts).where(and(eq(contentPosts.workspaceId, actor.workspaceId), eq(contentPosts.businessId, selected))).orderBy(desc(contentPosts.updatedAt)).limit(100) : [];
  const assets = selected ? await db.select(assetColumns).from(mediaAssets).where(and(eq(mediaAssets.workspaceId, actor.workspaceId), or(eq(mediaAssets.businessId, selected), isNull(mediaAssets.businessId)))).orderBy(desc(mediaAssets.createdAt)).limit(100) : [];
  const generations = selected ? await db.select().from(studioGenerations).where(and(eq(studioGenerations.workspaceId, actor.workspaceId), eq(studioGenerations.businessId, selected))).orderBy(desc(studioGenerations.createdAt)).limit(40) : [];
  return {
    businesses: allBusinesses.map(({ id, name, website }) => ({ id, name, website })), posts: posts.map(postDTO), assets, generations,
    style: selected ? await brandStyle(actor.workspaceId, selected) : DEFAULT_STYLE, actorRole: membership?.role ?? "member",
    capabilities: { aiConfigured: PROVIDERS.some((p) => p.kind === "ai" && !p.isPaid && p.configured()), stockConfigured: Boolean(process.env.UNSPLASH_ACCESS_KEY), videoProcessing: false, publishing: false, uploadLimitBytes: 5 * 1024 * 1024 },
  };
}
export async function createDraft(actor: TenantContext, businessId: number, input: unknown) {
  await ownBusiness(actor.workspaceId, businessId);
  const document = draftSchema.parse(input);
  await validateMedia(actor.workspaceId, businessId, document);
  const reviewFlags = flagsFor(document, await restricted(actor.workspaceId, businessId));
  return db.transaction(async (tx) => {
    const [row] = await tx.insert(contentPosts).values({ workspaceId: actor.workspaceId, businessId, createdBy: actor.userId, updatedBy: actor.userId, title: document.title, format: document.format, platforms: document.platforms, document, reviewFlags }).returning();
    await tx.insert(contentRevisions).values({ workspaceId: actor.workspaceId, postId: row.id, actorId: actor.userId, version: row.version, action: "created", snapshot: snapshot(row) });
    return postDTO(row);
  });
}
export async function draftDetail(actor: TenantContext, id: number) {
  const row = await ownPost(actor.workspaceId, id);
  const revisions = await db.select().from(contentRevisions).where(and(eq(contentRevisions.workspaceId, actor.workspaceId), eq(contentRevisions.postId, id))).orderBy(desc(contentRevisions.version)).limit(40);
  return { post: postDTO(row), revisions };
}

export async function mutateDraft(actor: TenantContext, id: number, body: Record<string, unknown>) {
  const expectedVersion = positiveId(body.version, "draft version");
  const actions = ["save", "review", "approve", "schedule", "unschedule", "archive", "restore", "apply"];
  if (typeof body.action !== "string" || !actions.includes(body.action)) throw new StudioError("Choose a valid draft action.");
  const action = body.action;
  const existing = await ownPost(actor.workspaceId, id);
  const membership = await getWorkspaceMembership(actor.workspaceId, actor.userId);
  if (["approve", "schedule"].includes(action) && !["owner", "admin"].includes(membership?.role ?? "")) throw new StudioError("Only owners/admins may approve or schedule content.", 403);
  const topics = await restricted(actor.workspaceId, existing.businessId);
  return db.transaction(async (tx) => {
    const [current] = await tx.select().from(contentPosts).where(and(eq(contentPosts.id, id), eq(contentPosts.workspaceId, actor.workspaceId))).limit(1).for("update");
    if (!current) throw new StudioError("Draft not found.", 404);
    if (current.version !== expectedVersion) throw new StudioError("This draft changed elsewhere. Reload it before saving; your unsaved editor text has not been overwritten.", 409);
    let document = current.document;
    let status = current.status;
    let scheduledAt = current.scheduledAt;
    let timeZone = current.timeZone;
    let approvedAt = current.approvedAt;
    let approvedBy = current.approvedBy;
    let generationId: number | null = null;
    if (action === "save") document = draftSchema.parse(body.document);
    if (action === "restore") {
      const revisionId = positiveId(body.revisionId, "revision");
      const [revision] = await tx.select().from(contentRevisions).where(and(eq(contentRevisions.id, revisionId), eq(contentRevisions.postId, id), eq(contentRevisions.workspaceId, actor.workspaceId))).limit(1);
      if (!revision) throw new StudioError("Revision not found.", 404);
      document = draftSchema.parse(revision.snapshot.document);
    }
    if (action === "apply") {
      generationId = positiveId(body.generationId, "generation");
      const [generation] = await tx.select().from(studioGenerations).where(and(eq(studioGenerations.id, generationId), eq(studioGenerations.workspaceId, actor.workspaceId), eq(studioGenerations.businessId, current.businessId), eq(studioGenerations.postId, id))).limit(1).for("update");
      if (!generation) throw new StudioError("Generation does not belong to this draft.", 404);
      if (generation.appliedAt) throw new StudioError("That generated suggestion was already applied.", 409);
      const output = generation.output;
      if (generation.kind === "studio_caption") document = draftSchema.parse({ ...document, caption: output.caption, hashtags: output.hashtags, platformCaptions: output.platformCaptions });
      else if (generation.kind === "studio_carousel") document = draftSchema.parse({ ...document, format: "carousel", caption: output.caption, hashtags: output.hashtags, slides: output.slides });
      else if (generation.kind === "studio_video_script") document = draftSchema.parse({ ...document, format: "video", videoScript: output.script });
      else throw new StudioError("Use ideas to start a new draft; they are not caption replacements.");
    }
    const reviewFlags = flagsFor(document, topics);
    if (["save", "restore", "apply"].includes(action)) {
      await validateMedia(actor.workspaceId, current.businessId, document);
      status = "draft"; approvedAt = null; approvedBy = null; scheduledAt = null;
    }
    if (["review", "approve"].includes(action)) {
      const hasCaption = document.caption.trim() || document.platforms.some((p) => document.platformCaptions[p].trim());
      if (!hasCaption && !(document.format === "carousel" && document.slides.length >= 2) && !(document.format === "video" && document.videoScript.trim())) throw new StudioError("Add caption text, at least two carousel slides, or a video script before review.");
      if (document.format === "carousel" && (document.slides.length < 2 || document.slides.some((s) => !s.heading.trim()))) throw new StudioError("A carousel needs 2–10 slides with headings before review.");
      scheduledAt = null;
      if (action === "review") { status = "in_review"; approvedAt = null; approvedBy = null; }
      else {
        if (reviewFlags.length && body.acknowledgeFlags !== true) throw new StudioError("Review the claim/sensitive-topic flags and explicitly acknowledge them before approval.");
        status = "approved"; approvedAt = new Date(); approvedBy = actor.userId;
      }
    }
    if (action === "schedule") {
      if (current.status !== "approved" || !current.approvedAt) throw new StudioError("A human must approve the current draft before it can be scheduled.");
      if (typeof body.wallTime !== "string" || typeof body.timeZone !== "string") throw new StudioError("Choose a date, time, and time zone.");
      timeZone = body.timeZone;
      scheduledAt = scheduleInstant(body.wallTime, timeZone);
      status = "scheduled";
    }
    if (action === "unschedule") { scheduledAt = null; status = approvedAt ? "approved" : "draft"; }
    if (action === "archive") { status = "archived"; scheduledAt = null; approvedAt = null; approvedBy = null; }
    const [row] = await tx.update(contentPosts).set({ document, title: document.title, format: document.format, platforms: document.platforms, reviewFlags, status, approvedAt, approvedBy, scheduledAt, timeZone, version: current.version + 1, updatedBy: actor.userId, updatedAt: new Date() }).where(and(eq(contentPosts.id, id), eq(contentPosts.workspaceId, actor.workspaceId))).returning();
    await tx.insert(contentRevisions).values({ workspaceId: actor.workspaceId, postId: id, actorId: actor.userId, version: row.version, action: action === "approve" && reviewFlags.length ? "approved_flags_acknowledged" : action, snapshot: snapshot(row) });
    if (generationId) await tx.update(studioGenerations).set({ appliedAt: new Date() }).where(and(eq(studioGenerations.id, generationId), eq(studioGenerations.workspaceId, actor.workspaceId)));
    return { post: postDTO(row), publishingEnabled: false, notice: action === "schedule" ? "Calendar plan saved. No social account or publishing worker is connected; this will not publish automatically." : undefined };
  });
}

export async function calendarPosts(actor: TenantContext, start: Date, end: Date, businessId?: number) {
  const { gte, lt } = await import("drizzle-orm");
  if (businessId) await ownBusiness(actor.workspaceId, businessId);
  const rows = await db.select().from(contentPosts).where(and(eq(contentPosts.workspaceId, actor.workspaceId), eq(contentPosts.status, "scheduled"), gte(contentPosts.scheduledAt, start), lt(contentPosts.scheduledAt, end), businessId ? eq(contentPosts.businessId, businessId) : undefined));
  return rows.map(postDTO);
}
