import { eq } from "drizzle-orm";
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { workspaceSettings } from "@/db/schema";
import { isSameOriginRequest, requestSessionToken } from "@/lib/auth";
import { readAuthenticatedSession, getWorkspaceMembership } from "@/lib/auth-server";

export type TenantContext = { userId: number; workspaceId: number; email: string };

export async function requireUser(request: NextRequest) {
  if (!isSameOriginRequest(request)) {
    return { ok: false as const, response: NextResponse.json({ error: "Request origin not allowed" }, { status: 403 }) };
  }
  try {
    const session = await readAuthenticatedSession(requestSessionToken(request));
    if (!session) {
      return { ok: false as const, response: NextResponse.json({ error: "Please sign in to continue", code: "UNAUTHENTICATED" }, { status: 401, headers: { "Cache-Control": "private, no-store" } }) };
    }
    return { ok: true as const, session };
  } catch {
    return { ok: false as const, response: NextResponse.json({ error: "Session service temporarily unavailable. Please retry.", code: "SESSION_UNAVAILABLE" }, { status: 503 }) };
  }
}

/** Session identity comes from the DB token hash, never client headers or JWT claims. */
export async function requireTenant(request: NextRequest) {
  const auth = await requireUser(request);
  if (!auth.ok) return auth;
  const { session } = auth;
  const workspaceId = session.workspaceId;
  if (!workspaceId || !(await getWorkspaceMembership(workspaceId, session.user.id))) {
    return { ok: false as const, response: NextResponse.json({ error: "Create or select a workspace to continue.", code: "WORKSPACE_REQUIRED" }, { status: 403 }) };
  }
  const context: TenantContext = { userId: session.user.id, workspaceId, email: session.user.email };
  return { ok: true as const, context };
}

export async function getOrCreateSettings(workspaceId: number) {
  const [existing] = await db.select().from(workspaceSettings).where(eq(workspaceSettings.workspaceId, workspaceId)).limit(1);
  if (existing) return existing;
  const [created] = await db.insert(workspaceSettings).values({ workspaceId }).onConflictDoNothing().returning();
  if (created) return created;
  const [fallback] = await db.select().from(workspaceSettings).where(eq(workspaceSettings.workspaceId, workspaceId)).limit(1);
  return fallback;
}
