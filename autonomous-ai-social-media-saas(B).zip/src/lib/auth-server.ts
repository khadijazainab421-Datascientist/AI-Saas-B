import { eq, and, asc, desc, sql, gt } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { db } from "@/db";
import { users, userSessions, workspaces, workspaceMembers, businesses } from "@/db/schema";
import { createSessionToken, hashSessionToken, SESSION_TTL_SECONDS, PREVIEW_SESSION_TTL_SECONDS, type SessionTransport } from "@/lib/auth";

type UserRow = typeof users.$inferSelect;
type WorkspaceRow = typeof workspaces.$inferSelect;
type MembershipRow = typeof workspaceMembers.$inferSelect;
type BusinessRow = typeof businesses.$inferSelect;
type SessionRow = typeof userSessions.$inferSelect;
export type SessionWithUser = SessionRow & { user: UserRow; transport?: SessionTransport };

export function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

export async function hashPassword(password: string) {
  const bcrypt = await import("bcryptjs");
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(plain: string, hash: string) {
  const bcrypt = await import("bcryptjs");
  return bcrypt.compare(plain, hash);
}

export async function findUserByEmail(email: string): Promise<UserRow | undefined> {
  const normalized = normalizeEmail(email);
  const [row] = await db.select().from(users)
    .where(sql`lower(btrim(${users.email})) = ${normalized}`).limit(1);
  return row;
}

export async function createUser(email: string, passwordHash: string, name?: string) {
  return db.insert(users).values({ email: normalizeEmail(email), passwordHash, name }).returning();
}

export async function createSessionRecord(userId: number, tokenHash: string, expiresAt: Date, workspaceId: number | null = null) {
  return db.insert(userSessions).values({ userId, tokenHash, expiresAt, workspaceId }).returning();
}

export async function getSessionByToken(tokenHash: string): Promise<SessionWithUser | null> {
  const [row] = await db.select({ session: userSessions, user: users })
    .from(userSessions).innerJoin(users, eq(users.id, userSessions.userId))
    .where(eq(userSessions.tokenHash, tokenHash)).limit(1);
  return row ? { ...row.session, user: row.user } : null;
}

export async function revokeSession(tokenHash: string) {
  return db.update(userSessions).set({ revoked: true }).where(eq(userSessions.tokenHash, tokenHash));
}

export async function revokeAllSessionsForUser(userId: number) {
  return db.update(userSessions).set({ revoked: true }).where(eq(userSessions.userId, userId));
}

export async function getWorkspacesForUser(userId: number): Promise<Array<{ workspace: WorkspaceRow; role: MembershipRow["role"] }>> {
  return db.select({ workspace: workspaces, role: workspaceMembers.role })
    .from(workspaceMembers).innerJoin(workspaces, eq(workspaces.id, workspaceMembers.workspaceId))
    .where(eq(workspaceMembers.userId, userId)).orderBy(asc(workspaceMembers.workspaceId));
}

export async function getWorkspaceMembership(workspaceId: number, userId: number) {
  const [row] = await db.select().from(workspaceMembers)
    .where(and(eq(workspaceMembers.workspaceId, workspaceId), eq(workspaceMembers.userId, userId))).limit(1);
  return row;
}

/** Recover only workspaces already owned by this authenticated user; never attach a foreign workspace. */
export async function firstWorkspaceForUser(userId: number) {
  const memberships = await getWorkspacesForUser(userId);
  if (memberships[0]) return memberships[0].workspace.id;
  const [owned] = await db.select().from(workspaces).where(eq(workspaces.ownerId, userId)).orderBy(asc(workspaces.id)).limit(1);
  if (!owned) return null;
  await db.insert(workspaceMembers).values({ workspaceId: owned.id, userId, role: "owner" }).onConflictDoNothing();
  return owned.id;
}

/** DB session expiry and revocation are authoritative, including for previously issued persisted tokens. */
export async function readAuthenticatedSession(token: string | undefined): Promise<SessionWithUser | null> {
  if (!token || token.length < 32 || token.length > 2048 || !/^[A-Za-z0-9_.-]+$/.test(token)) return null;
  const session = await getSessionByToken(hashSessionToken(token));
  if (!session || session.revoked || session.expiresAt <= new Date()) return null;
  let workspaceId = session.workspaceId;
  if (!workspaceId || !(await getWorkspaceMembership(workspaceId, session.user.id))) {
    workspaceId = await firstWorkspaceForUser(session.user.id);
    if (workspaceId !== session.workspaceId) {
      await db.update(userSessions).set({ workspaceId })
        .where(and(eq(userSessions.id, session.id), eq(userSessions.revoked, false)));
    }
  }
  return { ...session, workspaceId, transport: token.startsWith("p1_") ? "preview" : "cookie" };
}

function uniqueSlug(name: string) {
  const base = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48) || "workspace";
  return `${base}-${randomUUID().slice(0, 12)}`;
}

export async function createWorkspace(userId: number, name: string, slug?: string): Promise<WorkspaceRow> {
  return db.transaction(async (tx) => {
    const [workspace] = await tx.insert(workspaces).values({ name, slug: uniqueSlug(slug || name), ownerId: userId }).returning();
    await tx.insert(workspaceMembers).values({ workspaceId: workspace.id, userId, role: "owner" });
    return workspace;
  });
}

/** Account, first workspace, membership, and session succeed or roll back together. */
export async function registerWithWorkspace(options: { email: string; password: string; name: string; workspaceName: string }) {
  const passwordHash = await hashPassword(options.password);
  const token = createSessionToken();
  const expiresAt = new Date(Date.now() + SESSION_TTL_SECONDS * 1000);
  return db.transaction(async (tx) => {
    const [user] = await tx.insert(users).values({ email: normalizeEmail(options.email), passwordHash, name: options.name }).returning();
    const [workspace] = await tx.insert(workspaces).values({ name: options.workspaceName, slug: uniqueSlug(options.workspaceName), ownerId: user.id }).returning();
    await tx.insert(workspaceMembers).values({ workspaceId: workspace.id, userId: user.id, role: "owner" });
    await tx.insert(userSessions).values({ userId: user.id, workspaceId: workspace.id, tokenHash: hashSessionToken(token), expiresAt });
    return { user, workspace, token, expiresAt };
  });
}

export async function createSessionAndToken(userId: number, workspaceId: number | null, expiresInSeconds = SESSION_TTL_SECONDS, options: { transport?: SessionTransport } = {}) {
  const transport = options.transport ?? "cookie";
  const token = createSessionToken(transport);
  const tokenHash = hashSessionToken(token);
  const ttl = transport === "preview" ? Math.min(expiresInSeconds, PREVIEW_SESSION_TTL_SECONDS) : expiresInSeconds;
  const expiresAt = new Date(Date.now() + ttl * 1000);
  await createSessionRecord(userId, tokenHash, expiresAt, workspaceId);
  return { token, tokenHash, expiresAt };
}

/** Rotate this session only; another browser/device is not logged out when switching a workspace. */
export async function rotateSessionWorkspace(sessionId: number, userId: number, workspaceId: number, transport: SessionTransport = "cookie") {
  const token = createSessionToken(transport);
  const changes = {
    tokenHash: hashSessionToken(token), workspaceId,
    ...(transport === "cookie" ? { expiresAt: new Date(Date.now() + SESSION_TTL_SECONDS * 1000) } : {}),
  };
  const [row] = await db.update(userSessions).set(changes)
    .where(and(eq(userSessions.id, sessionId), eq(userSessions.userId, userId), eq(userSessions.revoked, false), gt(userSessions.expiresAt, new Date()))).returning();
  return row ? { token, expiresAt: row.expiresAt } : null;
}

export async function getBusinessesForWorkspace(workspaceId: number): Promise<BusinessRow[]> {
  return db.select().from(businesses).where(eq(businesses.workspaceId, workspaceId)).orderBy(desc(businesses.createdAt));
}

export async function getBusinessByIdAndWorkspace(businessId: number, workspaceId: number) {
  const [row] = await db.select().from(businesses)
    .where(and(eq(businesses.id, businessId), eq(businesses.workspaceId, workspaceId))).limit(1);
  return row;
}

type BusinessInput = { name: string; website?: string | null; industry?: string | null; description?: string | null; targetAudience?: string | null; brandVoice?: string | null };
export async function createBusiness(workspaceId: number, data: BusinessInput) {
  return db.insert(businesses).values({ workspaceId, ...data }).returning();
}
export async function updateBusiness(businessId: number, workspaceId: number, data: Partial<BusinessInput>) {
  return db.update(businesses).set({ ...data, updatedAt: new Date() })
    .where(and(eq(businesses.id, businessId), eq(businesses.workspaceId, workspaceId))).returning();
}
