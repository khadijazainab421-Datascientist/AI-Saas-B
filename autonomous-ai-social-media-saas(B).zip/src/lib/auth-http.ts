import { NextResponse } from "next/server";
import { isSameOriginRequest, sessionCookieName, sessionCookieOptions, previewSessionsEnabled, PREVIEW_SESSION_TTL_SECONDS } from "@/lib/auth";

export function authError(message: string, status: number, code = "AUTH_ERROR") {
  return NextResponse.json({ error: message, code }, { status, headers: { "Cache-Control": "private, no-store" } });
}
export function originError(request: Request) {
  return isSameOriginRequest(request) ? null : authError("Request origin not allowed", 403, "ORIGIN_REJECTED");
}
export async function authBody(request: Request): Promise<Record<string, unknown> | null> {
  if (Number(request.headers.get("content-length") ?? 0) > 16_384) return null;
  try {
    const value: unknown = await request.json();
    return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : null;
  } catch { return null; }
}

export function authResponse(request: Request, data: unknown, token?: string, status = 200) {
  let payload = data;
  const isPreview = Boolean(token?.startsWith("p1_"));
  if (isPreview) {
    if (!previewSessionsEnabled() || !isSameOriginRequest(request) || !data || typeof data !== "object") throw new Error("Preview session transport is not permitted");
    const values = data as Record<string, unknown>;
    const expiration = values.expiresAt instanceof Date ? values.expiresAt.getTime() : typeof values.expiresAt === "string" ? Date.parse(values.expiresAt) : Date.now();
    const remaining = Math.min(PREVIEW_SESSION_TTL_SECONDS, Math.floor((expiration - Date.now()) / 1000));
    if (remaining <= 0) return authError("Your preview session expired. Please sign in again.", 401, "UNAUTHENTICATED");
    payload = { ...values, sessionTransport: "preview", previewSession: { token, expiresInSeconds: remaining } };
  }
  const response = NextResponse.json(payload, { status, headers: { "Cache-Control": "private, no-store" } });
  if (token && !isPreview) response.cookies.set(sessionCookieName(), token, sessionCookieOptions(request));
  return response;
}

export function clearSessionCookie(request: Request, response: NextResponse) {
  response.cookies.set(sessionCookieName(), "", { ...sessionCookieOptions(request), maxAge: 0, expires: new Date(0) });
  return response;
}
export function databaseErrorCode(error: unknown): string | undefined {
  let current: unknown = error;
  for (let attempt = 0; attempt < 5; attempt++) {
    if (!current || typeof current !== "object") return undefined;
    const record = current as { code?: unknown; cause?: unknown };
    if (typeof record.code === "string") return record.code;
    current = record.cause;
  }
  return undefined;
}
