export const PREVIEW_SESSION_HEADER = "x-serein-preview-session";
export const PREVIEW_SESSION_TTL_SECONDS = 30 * 60;
export const PREVIEW_SESSION_EVENT = "serein:preview-session-changed";
