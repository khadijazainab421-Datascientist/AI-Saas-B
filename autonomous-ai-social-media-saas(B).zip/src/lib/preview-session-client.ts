"use client";

import { PREVIEW_SESSION_EVENT, PREVIEW_SESSION_TTL_SECONDS } from "@/lib/session-constants";

let current: { token: string; expiresAt: number } | null = null;

function notify() {
  if (typeof window !== "undefined") window.dispatchEvent(new Event(PREVIEW_SESSION_EVENT));
}

/** Memory only: never writes a bearer credential to cookies, URLs, web storage, or IndexedDB. */
export function savePreviewSession(session: { token: string; expiresInSeconds: number }) {
  if (!/^p1_[A-Za-z0-9_-]{43}$/.test(session.token) ||
      !Number.isFinite(session.expiresInSeconds) || session.expiresInSeconds <= 0) {
    throw new Error("The preview session response could not be verified.");
  }
  current = {
    token: session.token,
    expiresAt: Date.now() + Math.min(session.expiresInSeconds, PREVIEW_SESSION_TTL_SECONDS) * 1000,
  };
  notify();
}

export function clearPreviewSession() {
  const existed = Boolean(current);
  current = null;
  if (existed) notify();
}

export function previewSessionToken() {
  if (current && current.expiresAt <= Date.now()) clearPreviewSession();
  return current?.token ?? null;
}

export function hasPreviewSession() {
  return Boolean(previewSessionToken());
}
