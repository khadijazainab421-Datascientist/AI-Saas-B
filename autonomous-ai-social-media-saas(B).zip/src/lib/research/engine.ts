import { eq, and, gte, desc } from "drizzle-orm";
import { db } from "@/db";
import {
  researchRuns,
  researchSources,
  aiProviderStates,
  notifications,
  websiteAnalyses,
} from "@/db/schema";
import { getProvider, PROVIDERS } from "@/lib/ai/providers";
import { ensureProviderStates } from "@/lib/ai/orchestrator";
import { ProviderError } from "@/lib/ai/types";
import { getOrCreateSettings } from "@/lib/tenant";
import { extractWebsite } from "./website";
import { runTask } from "@/lib/ai/orchestrator";

export type ResearchResult = {
  runId: number;
  status: "completed" | "paused" | "failed";
  providerKey?: string;
  sources: Array<{ url: string; title: string; snippet: string }>;
  creditsUsed: number;
  reason?: string;
  attempts: Array<{ providerKey: string; errorCode: string; message: string }>;
};

export async function runResearch(options: {
  workspaceId: number;
  userId: number;
  businessId?: number | null;
  query: string;
  maxResults?: number;
}): Promise<ResearchResult> {
  const settings = await getOrCreateSettings(options.workspaceId);
  await ensureProviderStates();
  const query = options.query.trim().slice(0, 400);

  const [run] = await db
    .insert(researchRuns)
    .values({
      workspaceId: options.workspaceId,
      businessId: options.businessId ?? null,
      query,
      status: "running",
    })
    .returning();

  const attempts: ResearchResult["attempts"] = [];

  const pause = async (status: "paused" | "failed", reason: string): Promise<ResearchResult> => {
    await db
      .update(researchRuns)
      .set({ status, error: reason.slice(0, 1000) })
      .where(eq(researchRuns.id, run.id));
    await db.insert(notifications).values({
      workspaceId: options.workspaceId,
      userId: options.userId,
      type: "research_paused",
      title: "Research not executed — no source invented",
      body: `The research run was ${status} because ${reason} No topics or sources were fabricated.`,
    });
    return { runId: run.id, status, sources: [], creditsUsed: 0, reason, attempts };
  };

  const start = new Date();
  start.setUTCHours(0, 0, 0, 0);
  const todayRuns = await db
    .select({ id: researchRuns.id })
    .from(researchRuns)
    .where(and(eq(researchRuns.workspaceId, options.workspaceId), gte(researchRuns.createdAt, start)));
  if (todayRuns.length > settings.dailyResearchLimit) {
    return pause("paused", `the workspace daily research limit (${settings.dailyResearchLimit}) has been reached`);
  }

  const states = await db.select().from(aiProviderStates);
  const candidates = PROVIDERS.filter((provider) => {
    if (provider.kind !== "research") return false;
    if (provider.isPaid && !settings.allowPaidProviders) return false;
    return provider.configured();
  }).sort((a, b) => a.priority - b.priority);

  if (candidates.length === 0) {
    const paidKeys = PROVIDERS.filter((p) => p.kind === "research" && p.isPaid).map((p) => p.envVar);
    return pause(
      "paused",
      `no eligible research provider is configured. Add TAVILY_API_KEY for the free Researcher plan${settings.allowPaidProviders ? "" : `; metered providers (${paidKeys.join(", ")}) require explicit paid authorization`}`,
    );
  }

  for (const definition of candidates) {
    const state = states.find((row) => row.providerKey === definition.key);
    if (
      state?.health === "quota_exhausted" &&
      state.quotaExhaustedUntil &&
      new Date(state.quotaExhaustedUntil) > new Date()
    ) {
      attempts.push({
        providerKey: definition.key,
        errorCode: "quota",
        message: `Local cooldown until ${state.quotaExhaustedUntil.toISOString()}`,
      });
      continue;
    }

    try {
      const result = await definition.search!(query, options.maxResults ?? 5);
      if (result.sources.length === 0) {
        attempts.push({
          providerKey: definition.key,
          errorCode: "empty",
          message: "Provider returned no usable sources",
        });
        continue;
      }

      await db.insert(researchSources).values(
        result.sources.map((source) => ({
          workspaceId: options.workspaceId,
          businessId: options.businessId ?? null,
          runId: run.id,
          url: source.url,
          title: source.title,
          snippet: source.snippet,
          providerKey: definition.key,
        })),
      );

      await db
        .update(researchRuns)
        .set({
          status: "completed",
          providerKey: definition.key,
          creditsUsed: result.credits,
          answer: result.answer ?? null,
        })
        .where(eq(researchRuns.id, run.id));

      await db
        .update(aiProviderStates)
        .set({
          health: "healthy",
          lastError: null,
          totalRequests: (state?.totalRequests ?? 0) + 1,
          dailyRequestCount: (state?.dailyRequestCount ?? 0) + 1,
          updatedAt: new Date(),
        })
        .where(eq(aiProviderStates.providerKey, definition.key));

      return {
        runId: run.id,
        status: "completed",
        providerKey: definition.key,
        sources: result.sources,
        creditsUsed: result.credits,
        attempts,
      };
    } catch (error) {
      const failure = error instanceof ProviderError
        ? error
        : new ProviderError(definition.key, "unknown", error instanceof Error ? error.message : "Research request failed");
      attempts.push({
        providerKey: definition.key,
        errorCode: failure.code,
        message: failure.message.slice(0, 400),
      });
      await db
        .update(aiProviderStates)
        .set({
          health: failure.code === "quota" ? "quota_exhausted" : "degraded",
          lastError: failure.message.slice(0, 400),
          quotaExhaustedUntil:
            failure.code === "quota"
              ? new Date(Date.now() + Math.min(Math.max(failure.retryAfterMs ?? 900_000, 60_000), 86_400_000))
              : null,
          updatedAt: new Date(),
        })
        .where(eq(aiProviderStates.providerKey, definition.key));
    }
  }

  return pause(
    "paused",
    attempts.length > 0
      ? attempts.map((a) => `${a.providerKey}: ${a.errorCode} — ${a.message}`).join("; ")
      : "all eligible research providers are unavailable",
  );
}

export async function getResearch(workspaceId: number, businessId?: number | null) {
  const runs = await db
    .select()
    .from(researchRuns)
    .where(
      businessId
        ? and(eq(researchRuns.workspaceId, workspaceId), eq(researchRuns.businessId, businessId))
        : eq(researchRuns.workspaceId, workspaceId),
    )
    .orderBy(desc(researchRuns.createdAt))
    .limit(30);
  const sources = await db
    .select()
    .from(researchSources)
    .where(
      businessId
        ? and(eq(researchSources.workspaceId, workspaceId), eq(researchSources.businessId, businessId))
        : eq(researchSources.workspaceId, workspaceId),
    )
    .orderBy(desc(researchSources.retrievedAt))
    .limit(100);
  return { runs, sources };
}

export async function analyzeWebsite(options: {
  workspaceId: number;
  userId: number;
  businessId: number;
  url: string;
  allowPaid?: boolean;
}) {
  let extraction;
  try {
    extraction = await extractWebsite(options.url);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Website extraction failed";
    const [record] = await db
      .insert(websiteAnalyses)
      .values({
        workspaceId: options.workspaceId,
        businessId: options.businessId,
        url: options.url,
        status: "failed",
        error: message.slice(0, 800),
      })
      .returning();
    return { analysis: record, aiStatus: "not_attempted" as const, reason: message };
  }

  const [record] = await db
    .insert(websiteAnalyses)
    .values({
      workspaceId: options.workspaceId,
      businessId: options.businessId,
      url: extraction.url,
      status: "extracted",
      title: extraction.title,
      metaDescription: extraction.metaDescription,
      headings: extraction.headings,
      extractedText: extraction.extractedText,
      wordCount: extraction.wordCount,
      fetchedAt: new Date(extraction.fetchedAt),
    })
    .returning();

  // Deterministic extraction always succeeds without credentials.
  // AI interpretation is a separate, explicitly reported step.
  const hasEligibleAi = PROVIDERS.some(
    (provider) =>
      provider.kind === "ai" &&
      provider.configured() &&
      (!provider.isPaid || Boolean(options.allowPaid)),
  );

  if (!hasEligibleAi) {
    await db
      .update(websiteAnalyses)
      .set({ aiSummary: { pending: true, reason: "no_eligible_ai_provider" } })
      .where(eq(websiteAnalyses.id, record.id));
    return {
      analysis: { ...record, aiSummary: { pending: true, reason: "no_eligible_ai_provider" } },
      aiStatus: "pending_credentials" as const,
      reason: "Website content was extracted. AI interpretation is pending because no eligible provider is configured.",
    };
  }

  const task = await runTask({
    workspaceId: options.workspaceId,
    userId: options.userId,
    businessId: options.businessId,
    kind: "website_analysis",
    allowPaid: options.allowPaid,
    jsonMode: true,
    maxTokens: 1200,
    system:
      "You analyze a business website for a social media strategy. Use ONLY the supplied page text. Never invent products, customers, claims, or metrics. Clearly mark uncertainty. Return JSON with keys: summary, offerings (array of strings), audiences (array of strings), toneSignals (array of strings), uncertainties (array of strings).",
    prompt: `URL: ${extraction.url}\nTITLE: ${extraction.title ?? "none"}\nMETA: ${extraction.metaDescription ?? "none"}\nHEADINGS: ${extraction.headings.join(" | ") || "none"}\nPAGE TEXT:\n${extraction.extractedText.slice(0, 8000)}`,
  });

  if (task.status === "completed" && task.text) {
    let summary: unknown = { pending: true, reason: "unstructured_output", rawOutputPreserved: true };
    try {
      summary = JSON.parse(task.text.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, ""));
    } catch {
      // Raw output remains stored on the task; do not claim interpretation.
    }
    await db
      .update(websiteAnalyses)
      .set({ status: "analysed", aiSummary: summary, providerKey: task.providerKey ?? null })
      .where(eq(websiteAnalyses.id, record.id));
    return {
      analysis: { ...record, status: "analysed", aiSummary: summary, providerKey: task.providerKey },
      aiStatus: "completed" as const,
      taskId: task.taskId,
    };
  }

  await db
    .update(websiteAnalyses)
    .set({ aiSummary: { pending: true, reason: task.reason ?? "ai_task_paused", taskId: task.taskId } })
    .where(eq(websiteAnalyses.id, record.id));
  return {
    analysis: { ...record, aiSummary: { pending: true, reason: task.reason ?? "ai_task_paused", taskId: task.taskId } },
    aiStatus: "paused" as const,
    taskId: task.taskId,
    reason: task.reason,
  };
}

export async function getWebsiteAnalyses(workspaceId: number, businessId?: number | null) {
  return db
    .select()
    .from(websiteAnalyses)
    .where(
      businessId
        ? and(eq(websiteAnalyses.workspaceId, workspaceId), eq(websiteAnalyses.businessId, businessId))
        : eq(websiteAnalyses.workspaceId, workspaceId),
    )
    .orderBy(desc(websiteAnalyses.createdAt))
    .limit(20);
}

export function getResearchProvider(key: string) {
  return getProvider(key);
}
