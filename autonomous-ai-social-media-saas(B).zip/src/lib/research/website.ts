export type WebsiteExtraction = {
  url: string;
  title: string | null;
  metaDescription: string | null;
  headings: string[];
  extractedText: string;
  wordCount: number;
  fetchedAt: string;
  status: "extracted";
};

function decode(value: string): string {
  return value
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCharCode(Number(code)))
    .replace(/\s+/g, " ")
    .trim();
}

/** Blocks obvious SSRF targets. DNS-rebinding protection requires an egress proxy. */
export function isPublicWebUrl(raw: string): { ok: boolean; reason?: string; url?: URL } {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return { ok: false, reason: "Enter a valid URL including https:// or http://" };
  }
  if (!["http:", "https:"].includes(url.protocol)) {
    return { ok: false, reason: "Only http and https URLs are supported" };
  }
  const host = url.hostname.toLowerCase();
  const blocked =
    host === "localhost" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local") ||
    host.endsWith(".internal") ||
    /^127\./.test(host) ||
    /^10\./.test(host) ||
    /^192\.168\./.test(host) ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(host) ||
    /^169\.254\./.test(host) ||
    /^0\./.test(host) ||
    host === "::1" ||
    host === "[::1]" ||
    host.startsWith("fc") ||
    host.startsWith("fd") ||
    host.startsWith("fe80") ||
    host === "metadata.google.internal";
  if (blocked) {
    return { ok: false, reason: "Private, loopback, link-local, and metadata hosts are not allowed" };
  }
  return { ok: true, url };
}

export async function extractWebsite(raw: string): Promise<WebsiteExtraction> {
  const check = isPublicWebUrl(raw);
  if (!check.ok || !check.url) throw new Error(check.reason ?? "Invalid URL");
  const url = check.url;

  let response: Response;
  try {
    // Redirects are disabled to prevent a public URL from bouncing to a private host.
    response = await fetch(url, {
      redirect: "manual",
      signal: AbortSignal.timeout(12_000),
      cache: "no-store",
      headers: {
        "User-Agent": "Serein-Research/0.3 (+business website analysis)",
        Accept: "text/html,application/xhtml+xml",
      },
    });
  } catch (error) {
    throw new Error(`Could not fetch the website: ${error instanceof Error ? error.message : "network error"}`);
  }
  if (!response.ok) {
    throw new Error(`Website returned HTTP ${response.status}`);
  }

  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("text/html") && !contentType.includes("application/xhtml+xml") && contentType !== "") {
    throw new Error("The URL did not return an HTML document");
  }

  const limited = (await response.text()).slice(0, 500_000);
  const titleMatch = limited.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const metaMatch =
    limited.match(/<meta[^>]+name=["']description["'][^>]+content=["']([\s\S]*?)["'][^>]*>/i) ??
    limited.match(/<meta[^>]+content=["']([\s\S]*?)["'][^>]+name=["']description["'][^>]*>/i) ??
    limited.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([\s\S]*?)["'][^>]*>/i);

  const headings: string[] = [];
  const headingPattern = /<h([1-3])[^>]*>([\s\S]*?)<\/h\1>/gi;
  for (const match of limited.matchAll(headingPattern)) {
    const text = decode(match[2].replace(/<[^>]+>/g, " "));
    if (text && text.length < 300) headings.push(text);
    if (headings.length >= 30) break;
  }

  const withoutBlocks = limited
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
    .replace(/<svg[\s\S]*?<\/svg>/gi, " ")
    .replace(/<nav[\s\S]*?<\/nav>/gi, " ")
    .replace(/<footer[\s\S]*?<\/footer>/gi, " ")
    .replace(/<!--[\s\S]*?-->/g, " ");
  const extractedText = decode(withoutBlocks.replace(/<[^>]+>/g, " ")).slice(0, 20_000);

  return {
    url: url.toString(),
    title: titleMatch ? decode(titleMatch[1].replace(/<[^>]+>/g, " ")).slice(0, 300) : null,
    metaDescription: metaMatch ? decode(metaMatch[1]).slice(0, 600) : null,
    headings,
    extractedText,
    wordCount: extractedText ? extractedText.split(/\s+/).length : 0,
    fetchedAt: new Date().toISOString(),
    status: "extracted",
  };
}
