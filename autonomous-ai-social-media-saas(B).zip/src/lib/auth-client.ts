import { apiFetch, appUrl } from "@/lib/api-fetch";
import { clearPreviewSession, hasPreviewSession, savePreviewSession } from "@/lib/preview-session-client";

export type WorkspaceSummary = { id: number; name: string; slug: string; role: string };
export type CurrentSession = {
  user: { id: number; email: string; name: string | null };
  activeWorkspaceId: number | null;
  workspaces: WorkspaceSummary[];
  sessionTransport?: "cookie" | "preview";
  expiresAt?: string;
};
type PreviewCredential = { token: string; expiresInSeconds: number };
type AuthReply = {
  user: CurrentSession["user"];
  workspaceId?: number | null;
  workspace?: WorkspaceSummary;
  previewSessionAvailable?: boolean;
  previewSession?: PreviewCredential;
  sessionTransport?: "cookie" | "preview";
};

export class AuthClientError extends Error {
  constructor(message: string, public code = "REQUEST_FAILED") { super(message); this.name = "AuthClientError"; }
}
export function isEmbeddedPreview() {
  if (typeof window === "undefined") return false;
  try { return window.top !== window.self; } catch { return true; }
}
export function inAppUrl(path: string) { return appUrl(path); }

export function navigateInApp(path: string, navigation?: { replace: (href: string) => void }) {
  if (hasPreviewSession()) {
    if (!navigation) throw new AuthClientError("Temporary preview navigation needs the current app tab. Please retry sign-in.", "PREVIEW_NAVIGATION");
    navigation.replace(path);
    return;
  }
  window.location.assign(inAppUrl(path));
}

function routingFailure() {
  return new AuthClientError("The hosting preview returned an editor page or redirect instead of Serein. Use the direct Serein address shown below; do not create the account again.", "PREVIEW_ROUTING");
}
async function request<T>(path: string, init: RequestInit = {}) {
  const headers = new Headers(init.headers);
  if (init.body) headers.set("Content-Type", "application/json");
  let response: Response;
  try {
    response = await apiFetch(path, { ...init, redirect: "manual", headers, signal: init.signal ?? AbortSignal.timeout(20_000) });
  } catch (problem) {
    if (problem instanceof AuthClientError) throw problem;
    throw new AuthClientError("Could not reach the workspace service. Check the connection and retry.", "NETWORK_ERROR");
  }
  if (response.type === "opaqueredirect" || (response.status >= 300 && response.status < 400) || !response.headers.get("content-type")?.toLowerCase().includes("application/json")) throw routingFailure();
  let data: T & { error?: string; code?: string };
  try { data = await response.json(); } catch { throw routingFailure(); }
  if (!data || typeof data !== "object") throw routingFailure();
  return { response, data };
}
async function verifyAppRouting() {
  const { response, data } = await request<{ application: string; previewSessionAvailable?: boolean }>("/api/auth/context");
  if (!response.ok || data.application !== "serein") throw routingFailure();
  return data;
}
function failure(data: { error?: string; code?: string }, fallback: string) { return new AuthClientError(data.error ?? fallback, data.code); }

export async function getSession(): Promise<CurrentSession | null> {
  const { response, data } = await request<CurrentSession>("/api/auth/me");
  if (response.status === 401) return null;
  if (!response.ok) throw failure(data, "Session information could not be loaded. Please retry.");
  if (!data.user || typeof data.user.id !== "number" || typeof data.user.email !== "string" || !Array.isArray(data.workspaces)) throw routingFailure();
  return data;
}

async function establishPreviewSession(email: string, password: string, expectedUserId: number) {
  const { response, data } = await request<AuthReply>("/api/auth/login", {
    method: "POST", headers: { "x-serein-preview-fallback": "1" },
    body: JSON.stringify({ email: email.trim(), password, sessionTransport: "preview" }),
  });
  if (!response.ok) throw failure(data, "Temporary preview sign-in could not be completed.");
  if (data.sessionTransport !== "preview" || !data.previewSession || data.user?.id !== expectedUserId) throw routingFailure();
  savePreviewSession(data.previewSession);
  const confirmed = await getSession();
  if (!confirmed || confirmed.user.id !== expectedUserId || confirmed.sessionTransport !== "preview") {
    clearPreviewSession();
    throw new AuthClientError("The hosting preview rejected both cookie and temporary-session verification. No authenticated session could be confirmed.", "PREVIEW_SESSION_BLOCKED");
  }
  return data;
}

export async function signIn(email: string, password: string) {
  clearPreviewSession();
  const context = await verifyAppRouting();
  const { response, data } = await request<AuthReply>("/api/auth/login", { method: "POST", body: JSON.stringify({ email: email.trim(), password }) });
  if (!response.ok) throw failure(data, "Sign-in failed. Please retry.");
  if (typeof data.user?.id !== "number") throw routingFailure();
  const confirmed = await getSession();
  if (confirmed && confirmed.user.id === data.user.id) return data;
  if (context.previewSessionAvailable && data.previewSessionAvailable && data.user?.id) return establishPreviewSession(email, password, data.user.id);
  throw new AuthClientError("Your password was accepted, but this browser blocked the session cookie. Temporary preview sessions are disabled on this deployment.", "COOKIE_BLOCKED");
}

export async function signUp(options: { email: string; password: string; name?: string; workspaceName?: string }) {
  clearPreviewSession();
  const context = await verifyAppRouting();
  const { response, data } = await request<AuthReply>("/api/auth/register", { method: "POST", body: JSON.stringify(options) });
  if (!response.ok) throw failure(data, "Registration failed. Please retry.");
  if (typeof data.user?.id !== "number") throw routingFailure();
  const confirmed = await getSession();
  if (confirmed && confirmed.user.id === data.user.id) return data;
  if (context.previewSessionAvailable && data.previewSessionAvailable && data.user?.id) return establishPreviewSession(options.email, options.password, data.user.id);
  throw new AuthClientError("Your account and workspace were created, but this deployment could not retain its cookie. Sign in with the same account; do not register again.", "COOKIE_BLOCKED");
}

export async function signOut() {
  const { response, data } = await request("/api/auth/logout", { method: "POST" });
  if (!response.ok) throw failure(data, "Sign-out could not be confirmed. Please retry.");
  clearPreviewSession();
}
export async function getWorkspaces() {
  const { response, data } = await request<{ workspaces: WorkspaceSummary[]; activeWorkspaceId: number | null }>("/api/workspaces");
  if (!response.ok) throw failure(data, "Workspaces could not be loaded. Please retry.");
  return data;
}
export async function createWorkspace(name: string) {
  const { response, data } = await request<{ workspace: WorkspaceSummary }>("/api/workspaces", { method: "POST", body: JSON.stringify({ name }) });
  if (!response.ok) throw failure(data, "Workspace could not be created. Please retry.");
  return data.workspace;
}
export async function switchWorkspace(workspaceId: number) {
  const { response, data } = await request<{ previewSession?: PreviewCredential }>("/api/auth/switch-workspace", { method: "POST", body: JSON.stringify({ workspaceId }) });
  if (!response.ok) throw failure(data, "Workspace could not be selected. Please retry.");
  if (data.previewSession) savePreviewSession(data.previewSession);
  const session = await getSession();
  if (!session || session.activeWorkspaceId !== workspaceId) throw new AuthClientError("The selected workspace session could not be confirmed. Please sign in again.", "SESSION_UNCONFIRMED");
  return data;
}
