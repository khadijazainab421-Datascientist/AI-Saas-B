"use client";

import { PREVIEW_SESSION_HEADER } from "@/lib/session-constants";
import { clearPreviewSession, previewSessionToken } from "@/lib/preview-session-client";

export function appUrl(path: string) {
  if (!path.startsWith("/") || path.startsWith("//")) throw new Error("Invalid internal app address.");
  if (typeof window === "undefined") return path;
  if (!/^https?:$/.test(window.location.protocol)) throw new Error("This preview has no usable app origin.");
  return new URL(path, window.location.origin).href;
}

/** Same-origin API calls only. Provider keys are never part of this client. */
export async function apiFetch(path: string, init: RequestInit = {}) {
  if (!path.startsWith("/api/")) throw new Error("Only same-origin app API paths are supported.");
  const headers = new Headers(init.headers);
  const token = previewSessionToken();
  if (token) headers.set(PREVIEW_SESSION_HEADER, token);
  else headers.delete(PREVIEW_SESSION_HEADER);
  if (typeof window !== "undefined") {
    try { if (window.top !== window.self) headers.set("x-serein-embedded-preview", "1"); }
    catch { headers.set("x-serein-embedded-preview", "1"); }
  }
  const response = await fetch(appUrl(path), { ...init, redirect: "manual", headers, credentials: "include", cache: "no-store" });
  if (token && response.status === 401 && previewSessionToken() === token) clearPreviewSession();
  return response;
}
