import { eq, and, desc } from "drizzle-orm";
import { db } from "@/db";
import {
  businesses,
  brandProfiles,
  websiteAnalyses,
  researchSources,
  contentStrategies,
} from "@/db/schema";
import { runTask } from "@/lib/ai/orchestrator";
import { getOrCreateSettings } from "@/lib/tenant";

export async function getStrategyContext(workspaceId: number, businessId: number) {
  const [business] = await db
    .select()
    .from(businesses)
    .where(and(eq(businesses.id, businessId), eq(businesses.workspaceId, workspaceId)))
    .limit(1);
  if (!business) return null;

  const [profile] = await db
    .select()
    .from(brandProfiles)
    .where(and(eq(brandProfiles.businessId, businessId), eq(brandProfiles.workspaceId, workspaceId)))
    .limit(1);

  const [analysis] = await db
    .select()
    .from(websiteAnalyses)
    .where(and(eq(websiteAnalyses.businessId, businessId), eq(websiteAnalyses.workspaceId, workspaceId)))
    .orderBy(desc(websiteAnalyses.createdAt))
    .limit(1);

  const sources = await db
    .select()
    .from(researchSources)
    .where(and(eq(researchSources.workspaceId, workspaceId), eq(researchSources.businessId, businessId)))
    .orderBy(desc(researchSources.retrievedAt))
    .limit(15);

  const strategies = await db
    .select()
    .from(contentStrategies)
    .where(and(eq(contentStrategies.businessId, businessId), eq(contentStrategies.workspaceId, workspaceId)))
    .orderBy(desc(contentStrategies.version))
    .limit(10);

  return { business, profile, analysis, sources, strategies };
}

export async function generateStrategy(options: {
  workspaceId: number;
  userId: number;
  businessId: number;
}) {
  const context = await getStrategyContext(options.workspaceId, options.businessId);
  if (!context) {
    return { status: "failed" as const, reason: "Business not found in this workspace" };
  }
  const settings = await getOrCreateSettings(options.workspaceId);
  const { business, profile, analysis, sources } = context;
  const restrictedTopics = profile?.restrictedTopics ?? [];

  const system = [
    "You are a social media strategist for Instagram, Facebook, and LinkedIn.",
    "Use ONLY the supplied business profile, website extraction, and cited research sources.",
    "Never invent statistics, customer counts, awards, certifications, competitors, trends, or performance results.",
    "If evidence is missing, say so in the rationale and lower confidence rather than filling gaps.",
    "Do not make medical, financial, legal, or absolute performance claims.",
    "Sensitive or unverified claims must be excluded or explicitly marked for human review.",
    'Return ONE JSON object with keys: pillars (array of {name, purpose, evidence}), formats (array of {name, rationale}), cadence (object with recommendedPostsPerWeek, channelMix, rationale), calendarLogic (object with themes, seasonalNotes, constraints), rationale (string).',
  ].join(" ");

  const prompt = [
    `BUSINESS (user-provided):`,
    `Name: ${business.name}`,
    `Website: ${business.website ?? "not provided"}`,
    `Industry: ${business.industry ?? "not provided"}`,
    `Description: ${business.description ?? "not provided"}`,
    `Target audience: ${business.targetAudience ?? profile?.audience ?? "not provided"}`,
    `Brand voice: ${business.brandVoice ?? profile?.voiceDescription ?? "not provided"}`,
    `Tone: ${profile?.tone ?? "not provided"}`,
    `Objectives: ${profile?.objectives ?? "not provided"}`,
    `Vocabulary: ${(profile?.vocabulary ?? []).join(", ") || "not provided"}`,
    `Claims policy: ${profile?.claimsPolicy ?? "not provided"}`,
    `Restricted topics: ${restrictedTopics.join(", ") || "none provided"}`,
    `Style examples: ${(profile?.styleExamples ?? []).join(" | ") || "none provided"}`,
    ``,
    `WEBSITE EXTRACTION (public page, deterministic):`,
    `Status: ${analysis?.status ?? "not analysed"}`,
    `Title: ${analysis?.title ?? "none"}`,
    `Meta description: ${analysis?.metaDescription ?? "none"}`,
    `Headings: ${(analysis?.headings ?? []).join(" | ") || "none"}`,
    `Page text: ${(analysis?.extractedText ?? "").slice(0, 5000) || "none"}`,
    `AI interpretation: ${analysis?.aiSummary ? JSON.stringify(analysis.aiSummary).slice(0, 2000) : "none"}`,
    ``,
    `RESEARCH SOURCES (only cite these; empty means no research has been run):`,
    ...(sources.length > 0
      ? sources.map((source, index) => `${index + 1}. ${source.title} — ${source.url} — ${(source.snippet ?? "").slice(0, 300)}`)
      : ["No verified research sources available. Do not imply that research was performed."]),
    ``,
    "Produce a conservative, evidence-bounded strategy. It will be stored as a draft for human review, never published automatically.",
  ].join("\n");

  const result = await runTask({
    workspaceId: options.workspaceId,
    userId: options.userId,
    businessId: options.businessId,
    kind: "strategy_generation",
    system,
    prompt,
    jsonMode: true,
    maxTokens: 2400,
    temperature: 0.3,
    allowPaid: settings.allowPaidProviders,
    restrictedTopics,
  });

  return result;
}
