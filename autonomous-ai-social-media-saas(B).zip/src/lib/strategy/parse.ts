import { eq, and, desc } from "drizzle-orm";
import { db } from "@/db";
import { contentStrategies, researchSources, aiTasks } from "@/db/schema";

const CLAIM_PATTERNS: Array<[RegExp, string]> = [
  [/\b(guarantee[sd]?|guaranteed)\b/i, "Absolute guarantee language requires review"],
  [/\b(best|#1|number one|leading|world-class)\b/i, "Superlative claim requires substantiation"],
  [/\b(100%|always|never|zero risk|risk-free)\b/i, "Absolute or risk-free claim requires review"],
  [/\b(cure[sd]?|clinically proven|FDA[- ]approved|medical|health claim)\b/i, "Health or regulated claim requires additional review"],
  [/\b(proven results?|scientifically proven)\b/i, "Evidence claim requires a cited source"],
  [/\b(ROI|revenue|sales)\s+\w*\s*\d+[%x]/i, "Performance figure requires verification"],
];

export function detectReviewFlags(text: string, restrictedTopics: string[] = []): string[] {
  const flags = new Set<string>();
  for (const [pattern, label] of CLAIM_PATTERNS) {
    if (pattern.test(text)) flags.add(label);
  }
  for (const topic of restrictedTopics) {
    const trimmed = topic.trim();
    if (trimmed && new RegExp(`\\b${trimmed.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i").test(text)) {
      flags.add(`Restricted topic mentioned: ${trimmed}`);
    }
  }
  return [...flags];
}

export type ParsedStrategy = {
  pillars: unknown;
  formats: unknown;
  cadence: unknown;
  calendarLogic: unknown;
  rationale: string;
  reviewFlags: string[];
};

function extractJson(text: string): unknown {
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "");
  try {
    return JSON.parse(cleaned) as unknown;
  } catch {
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    if (start >= 0 && end > start) {
      return JSON.parse(cleaned.slice(start, end + 1)) as unknown;
    }
    throw new Error("Provider output was not valid JSON");
  }
}

export function parseStrategyOutput(
  text: string,
  restrictedTopics: string[] = [],
): ParsedStrategy {
  const raw = extractJson(text) as Record<string, unknown>;
  const pillars = raw.pillars ?? raw.contentPillars;
  if (!Array.isArray(pillars) || pillars.length === 0) {
    throw new Error("Strategy is missing content pillars");
  }
  return {
    pillars,
    formats: raw.formats ?? [],
    cadence: raw.cadence ?? raw.postingFrequency ?? {},
    calendarLogic: raw.calendarLogic ?? raw.calendar ?? {},
    rationale: typeof raw.rationale === "string" ? raw.rationale.slice(0, 6000) : "",
    reviewFlags: detectReviewFlags(text, restrictedTopics),
  };
}

/** Persists a validated strategy. Called on first completion and on resumed tasks. */
export async function finalizeStrategy(options: {
  taskId: number;
  workspaceId: number;
  businessId: number;
  text: string;
  providerKey: string;
  restrictedTopics?: string[];
}) {
  const parsed = parseStrategyOutput(options.text, options.restrictedTopics ?? []);

  const sourceRows = await db
    .select({ url: researchSources.url })
    .from(researchSources)
    .where(and(
      eq(researchSources.workspaceId, options.workspaceId),
      eq(researchSources.businessId, options.businessId),
    ))
    .limit(30);

  const [previous] = await db
    .select({ version: contentStrategies.version })
    .from(contentStrategies)
    .where(eq(contentStrategies.businessId, options.businessId))
    .orderBy(desc(contentStrategies.version))
    .limit(1);

  const [strategy] = await db
    .insert(contentStrategies)
    .values({
      workspaceId: options.workspaceId,
      businessId: options.businessId,
      taskId: options.taskId,
      version: (previous?.version ?? 0) + 1,
      status: parsed.reviewFlags.length > 0 ? "needs_review" : "draft",
      pillars: parsed.pillars,
      formats: parsed.formats,
      cadence: parsed.cadence,
      calendarLogic: parsed.calendarLogic,
      rationale: parsed.rationale,
      reviewFlags: parsed.reviewFlags,
      sources: sourceRows.map((row) => row.url),
      providerKey: options.providerKey,
    })
    .returning();

  await db
    .update(aiTasks)
    .set({ result: { strategyId: strategy.id, providerKey: options.providerKey }, updatedAt: new Date() })
    .where(eq(aiTasks.id, options.taskId));

  return strategy;
}
