import { createHash, randomBytes } from "node:crypto";
import { PREVIEW_SESSION_HEADER, PREVIEW_SESSION_TTL_SECONDS } from "@/lib/session-constants";

export const SESSION_TTL_SECONDS = 7 * 24 * 60 * 60;
export { PREVIEW_SESSION_TTL_SECONDS };
export type SessionTransport = "cookie" | "preview";
const COOKIE_NAME = "serein_session";

/** Preview transport is opt-in outside the platform sandbox; normal deployments stay cookie-only. */
export function previewSessionsEnabled(environment: Record<string, string | undefined> = process.env) {
  if (environment.ALLOW_PREVIEW_TOKEN_AUTH === "false") return false;
  return environment.ALLOW_PREVIEW_TOKEN_AUTH === "true" ||
    Boolean(environment.E2B_SANDBOX_ID && /^[a-z0-9][a-z0-9-]{2,95}$/i.test(environment.E2B_SANDBOX_ID));
}

export function createSessionToken(transport: SessionTransport = "cookie") {
  return `${transport === "preview" ? "p1" : "s1"}_${randomBytes(32).toString("base64url")}`;
}

export function hashSessionToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export function sessionCookieName() { return COOKIE_NAME; }

/** A preview header never substitutes a user ID/role; its opaque secret still needs a valid DB record. */
export function requestSessionToken(request: Request) {
  const preview = request.headers.get(PREVIEW_SESSION_HEADER);
  if (preview !== null) {
    if (!previewSessionsEnabled() || !/^p1_[A-Za-z0-9_-]{43}$/.test(preview)) return undefined;
    return preview;
  }
  const entry = request.headers.get("cookie")?.split(";").find((part) => part.trim().startsWith(`${COOKIE_NAME}=`));
  if (!entry) return undefined;
  try {
    const token = decodeURIComponent(entry.trim().slice(COOKIE_NAME.length + 1));
    return token.startsWith("p1_") ? undefined : token;
  } catch { return undefined; }
}

function publicHost(request: Request) {
  const host = (request.headers.get("x-forwarded-host") ?? request.headers.get("host") ?? new URL(request.url).host).split(",")[0].trim();
  return /^[a-z0-9.:[\]-]+$/i.test(host) ? host : new URL(request.url).host;
}
function hostname(request: Request) { return new URL(`https://${publicHost(request)}`).hostname.toLowerCase(); }
function isLoopback(host: string) { return ["localhost", "127.0.0.1", "[::1]"].includes(host); }

export function publicOrigin(request: Request) {
  const forwarded = request.headers.get("x-forwarded-proto")?.split(",")[0].trim();
  const scheme = forwarded === "https" || new URL(request.url).protocol === "https:" ? "https" : "http";
  return `${scheme}://${publicHost(request)}`;
}

export function isSameOriginRequest(request: Request) {
  if (["GET", "HEAD", "OPTIONS"].includes(request.method)) return true;
  const origin = request.headers.get("origin");
  if (!origin) return request.headers.get("sec-fetch-site") !== "cross-site";
  try {
    const parsed = new URL(origin);
    const allowedHosts = new Set([new URL(request.url).host, publicHost(request), request.headers.get("host")]);
    return allowedHosts.has(parsed.host) && (parsed.protocol === "https:" || (parsed.protocol === "http:" && isLoopback(parsed.hostname)));
  } catch { return false; }
}

export function sessionCookieOptions(request: Request) {
  const host = hostname(request);
  const httpsBrowserOrigin = Boolean(request.headers.get("origin")?.startsWith("https://") && isSameOriginRequest(request));
  const secure = publicOrigin(request).startsWith("https:") || httpsBrowserOrigin || (process.env.NODE_ENV === "production" && !isLoopback(host));
  // The preview proxy may use its own hostname instead of forwarding *.e2b.app.
  const previewHost = previewSessionsEnabled() || host.endsWith(".e2b.app") || host.endsWith(".e2b.dev") || isLoopback(host) || process.env.ALLOW_EMBEDDED_PREVIEW === "true";
  const embedded = secure && previewHost && request.headers.get("x-serein-embedded-preview") === "1";
  const sameSite: "lax" | "none" = embedded ? "none" : "lax";
  return { path: "/", httpOnly: true, secure, sameSite, partitioned: embedded, maxAge: SESSION_TTL_SECONDS };
}
