import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  className,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex min-h-72 flex-col items-center justify-center rounded-[1.4rem] border border-dashed border-sage/45 bg-white/45 px-6 py-12 text-center",
        className,
      )}
    >
      <div className="relative mb-5 grid h-14 w-14 place-items-center rounded-full border border-sage/35 bg-mint/55 text-forest">
        <span className="absolute inset-2 rounded-full border border-white/80" aria-hidden="true" />
        <Icon className="relative h-5 w-5" strokeWidth={1.6} aria-hidden="true" />
      </div>
      <h3 className="font-display text-2xl tracking-[-0.02em] text-ink">{title}</h3>
      <p className="mt-3 max-w-md text-sm leading-6 text-secondary">{description}</p>
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}
