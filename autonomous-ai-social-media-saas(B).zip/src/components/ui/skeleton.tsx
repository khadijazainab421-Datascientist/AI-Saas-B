import { cn } from "@/lib/utils";

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("animate-pulse rounded-lg bg-sage/15", className)} aria-hidden="true" />;
}

export function DashboardSkeleton() {
  return (
    <div className="animate-pulse" aria-label="Loading workspace" role="status">
      <span className="sr-only">Loading workspace</span>
      <Skeleton className="h-3 w-28" />
      <Skeleton className="mt-5 h-11 w-80 max-w-full" />
      <Skeleton className="mt-4 h-4 w-[30rem] max-w-full" />
      <div className="mt-10 grid gap-5 lg:grid-cols-3">
        <Skeleton className="h-64 lg:col-span-2" />
        <Skeleton className="h-64" />
      </div>
      <div className="mt-5 grid gap-5 sm:grid-cols-2">
        <Skeleton className="h-40" />
        <Skeleton className="h-40" />
      </div>
    </div>
  );
}
