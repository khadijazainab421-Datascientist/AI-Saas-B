import type { ReactNode } from "react";
import { Badge } from "./badge";

export function PageHeader({
  eyebrow,
  title,
  description,
  status,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  status?: string;
  children?: ReactNode;
}) {
  return (
    <header className="mb-8 flex flex-col gap-5 border-b border-line pb-7 lg:flex-row lg:items-end lg:justify-between">
      <div className="max-w-2xl">
        <div className="mb-3 flex flex-wrap items-center gap-3">
          <p className="eyebrow">{eyebrow}</p>
          {status && <Badge tone="neutral">{status}</Badge>}
        </div>
        <h1 className="font-display text-[2.15rem] leading-tight tracking-[-0.03em] text-ink sm:text-[2.65rem]">
          {title}
        </h1>
        <p className="mt-3 max-w-xl text-sm leading-6 text-secondary">{description}</p>
      </div>
      {children && <div className="flex shrink-0 items-center gap-3">{children}</div>}
    </header>
  );
}
