import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Badge({
  children,
  tone = "sage",
  className,
}: {
  children: ReactNode;
  tone?: "sage" | "teal" | "neutral" | "amber";
  className?: string;
}) {
  const tones = {
    sage: "border-sage/35 bg-mint/55 text-forest",
    teal: "border-teal/15 bg-teal text-white",
    neutral: "border-line bg-white/60 text-secondary",
    amber: "border-[#d9c9a9] bg-[#f7f2e8] text-[#735c32]",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[0.64rem] font-semibold uppercase tracking-[0.11em]",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}
