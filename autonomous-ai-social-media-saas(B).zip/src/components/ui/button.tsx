import type { ButtonHTMLAttributes, ReactNode } from "react";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";

export type ButtonVariant = "primary" | "secondary" | "ghost" | "light";

const variants: Record<ButtonVariant, string> = {
  primary:
    "bg-forest text-white border-forest hover:bg-teal hover:border-teal shadow-[0_8px_24px_rgba(22,78,74,0.12)]",
  secondary: "bg-white/70 text-ink border-line hover:border-sage hover:bg-white",
  ghost: "bg-transparent text-secondary border-transparent hover:text-ink hover:bg-mint/55",
  light: "bg-soft-white text-forest border-white/70 hover:bg-white",
};

const base =
  "inline-flex min-h-11 items-center justify-center gap-2.5 rounded-full border px-5 py-2.5 text-[0.78rem] font-semibold tracking-[0.01em] transition-all duration-300 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-teal disabled:pointer-events-none disabled:opacity-45";

export function Button({
  children,
  className,
  variant = "primary",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: ButtonVariant }) {
  return (
    <button className={cn(base, variants[variant], className)} {...props}>
      {children}
    </button>
  );
}

export function ButtonLink({
  children,
  href,
  className,
  variant = "primary",
  arrow = false,
  external = false,
}: {
  children: ReactNode;
  href: string;
  className?: string;
  variant?: ButtonVariant;
  arrow?: boolean;
  external?: boolean;
}) {
  const content = (
    <>
      {children}
      {arrow && (
        <ArrowUpRight
          aria-hidden="true"
          className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
        />
      )}
    </>
  );

  if (external) {
    return (
      <a
        href={href}
        target="_blank"
        rel="noreferrer"
        className={cn(base, variants[variant], "group", className)}
      >
        {content}
      </a>
    );
  }

  return (
    <Link href={href} className={cn(base, variants[variant], "group", className)}>
      {content}
    </Link>
  );
}
