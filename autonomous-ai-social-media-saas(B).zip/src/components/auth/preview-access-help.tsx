"use client";

import { useRef, useState } from "react";
import { ArrowUpRight, Check, Copy, Info } from "lucide-react";

export function PreviewAccessHelp({ standaloneOrigin, registration = false }: {
  standaloneOrigin: string | null;
  registration?: boolean;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [copyState, setCopyState] = useState<"idle" | "copied" | "manual">("idle");
  const action = registration ? "registration" : "login";
  const directUrl = standaloneOrigin ? new URL(registration ? "/register" : "/login", standaloneOrigin).href : null;

  async function copyAddress() {
    if (!directUrl) return;
    try {
      if (!navigator.clipboard?.writeText) throw new Error("Clipboard unavailable");
      await navigator.clipboard.writeText(directUrl);
      setCopyState("copied");
    } catch {
      input.current?.focus();
      input.current?.select();
      setCopyState("manual");
    }
  }

  return (
    <aside aria-label="Preview sign-in help" className="mt-5 rounded-xl border border-sage/40 bg-mint/35 p-4 text-[0.67rem] leading-5 text-forest">
      <p className="flex items-center gap-2 font-bold"><Info className="h-3.5 w-3.5 shrink-0" aria-hidden="true" /> {registration ? "You can register here" : "You can sign in here"}</p>
      <p className="mt-2">{registration ? "Complete the form below to create your workspace." : "Enter your Serein email and password below, then choose Sign in."} A new tab is optional—not a required step.</p>
      {directUrl ? (
        <details className="mt-3 border-t border-forest/10 pt-3">
          <summary className="cursor-pointer font-semibold underline decoration-forest/30 underline-offset-4">Need a separate tab? Show the direct Serein address</summary>
          <div className="mt-3">
            <a href={directUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 font-bold underline underline-offset-4">
              Open Serein {action} in a new tab <ArrowUpRight className="h-3 w-3" aria-hidden="true" />
            </a>
            <p className="mt-2 text-[0.62rem] leading-5 text-secondary">If the hosting editor opens instead, copy the full app address below. Preview access may still require permission from the hosting platform.</p>
            <label htmlFor="direct-auth-address" className="mt-3 block text-[0.58rem] font-bold uppercase tracking-[0.09em] text-teal">Direct Serein {action} URL</label>
            <div className="mt-1.5 flex items-stretch gap-2">
              <input id="direct-auth-address" ref={input} type="text" readOnly value={directUrl} onFocus={(event) => event.currentTarget.select()} className="min-w-0 flex-1 rounded-lg border border-sage/40 bg-white/80 px-2.5 py-2 font-mono text-[0.6rem] text-ink outline-none focus:border-teal" spellCheck={false} />
              <button type="button" aria-label={`Copy direct ${action} URL`} onClick={() => void copyAddress()} className="grid min-h-10 w-10 shrink-0 place-items-center rounded-lg border border-sage/40 bg-white/80 text-forest hover:bg-white">
                {copyState === "copied" ? <Check className="h-4 w-4" aria-hidden="true" /> : <Copy className="h-4 w-4" aria-hidden="true" />}
              </button>
            </div>
            <p role="status" aria-live="polite" className="mt-2 text-[0.6rem] leading-5 text-secondary">
              {copyState === "copied" ? "Direct app URL copied. No password or session token is included." : copyState === "manual" ? "Automatic copy was blocked. The address is selected; copy it manually." : "This is the app's direct target, not the editor's relative /login link. Hosting access rules still apply."}
            </p>
          </div>
        </details>
      ) : <p className="mt-3 text-[0.62rem] leading-5 text-secondary">A standalone app address could not be resolved. Sign in here rather than following an editor-relative link.</p>}
    </aside>
  );
}
