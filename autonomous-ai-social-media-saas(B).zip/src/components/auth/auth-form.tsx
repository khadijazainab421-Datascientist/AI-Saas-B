"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Building2, Eye, EyeOff, LockKeyhole, Mail, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Panel } from "@/components/ui/panel";
import { Logo } from "@/components/brand/logo";
import { PreviewAccessHelp } from "@/components/auth/preview-access-help";
import { AuthClientError, isEmbeddedPreview, navigateInApp, signIn, signUp } from "@/lib/auth-client";

export function AuthForm({ mode, standaloneOrigin = null }: { mode: "login" | "register"; standaloneOrigin?: string | null }) {
  const registering = mode === "register";
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [workspaceName, setWorkspaceName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [embedded, setEmbedded] = useState(false);
  const [error, setError] = useState("");
  const [errorCode, setErrorCode] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => { setEmbedded(isEmbeddedPreview()); }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(""); setErrorCode(""); setLoading(true);
    try {
      if (registering) await signUp({ email: email.trim(), password, name, workspaceName });
      else await signIn(email, password);
      navigateInApp("/dashboard", router);
    } catch (problem) {
      setError(problem instanceof Error ? problem.message : "Sign-in could not be completed. Please retry.");
      setErrorCode(problem instanceof AuthClientError ? problem.code : "REQUEST_FAILED");
      setLoading(false);
    }
  }

  const inputClass = "block w-full rounded-xl border border-line bg-white py-3 pl-10 pr-4 text-sm text-ink outline-none transition-colors focus:border-teal focus:ring-2 focus:ring-mint disabled:bg-pale/60";

  return (
    <main className="fine-grid flex min-h-screen items-center justify-center bg-pale/55 px-5 py-10 sm:py-16">
      <div className="w-full max-w-md">
        <Link href="/" className="mb-6 inline-flex items-center gap-2 text-[0.65rem] font-semibold text-secondary hover:text-teal">
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" /> Back to Serein
        </Link>
        <Panel className="p-6 sm:p-9">
          <Logo />
          <p className="eyebrow mt-8">{registering ? "A considered beginning" : "Welcome back"}</p>
          <h1 className="mt-3 font-display text-[2rem] leading-tight tracking-[-0.03em] text-ink">{registering ? "Create your workspace" : "Sign in to your workspace"}</h1>
          <p className="mt-3 text-xs leading-6 text-secondary">{registering ? "One personal account. A separate, private space for each brand." : "Use the email and password you entered on Serein's Create your workspace form—not your AI-provider account."}</p>

          {(embedded || ["COOKIE_BLOCKED", "PREVIEW_ROUTING"].includes(errorCode)) && (
            <PreviewAccessHelp standaloneOrigin={standaloneOrigin} registration={registering && !["COOKIE_BLOCKED", "ACCOUNT_EXISTS"].includes(errorCode)} />
          )}

          {error && <div id="auth-error" role="alert" className="mt-5 rounded-xl border border-[#dfcfb6] bg-[#f7f2e8] p-4 text-xs leading-6 text-[#735c32]">{error}</div>}

          <form onSubmit={submit} className="mt-7 space-y-4" aria-describedby={error ? "auth-error" : undefined}>
            {registering && <label className="block">
              <span className="mb-2 block text-[0.65rem] font-semibold text-ink">Your name</span>
              <div className="relative"><UserRound className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sage-dark" aria-hidden="true" /><input name="name" autoComplete="name" required maxLength={100} value={name} onChange={(event) => setName(event.target.value)} disabled={loading} className={inputClass} /></div>
            </label>}
            <label className="block">
              <span className="mb-2 block text-[0.65rem] font-semibold text-ink">Email address</span>
              <div className="relative"><Mail className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sage-dark" aria-hidden="true" /><input name="email" type="email" autoComplete="email" autoCapitalize="none" spellCheck={false} required maxLength={254} value={email} onChange={(event) => setEmail(event.target.value)} disabled={loading} className={inputClass} /></div>
            </label>
            <div>
              <label htmlFor="auth-password" className="mb-2 block text-[0.65rem] font-semibold text-ink">Password</label>
              <div className="relative">
                <LockKeyhole className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sage-dark" aria-hidden="true" />
                <input id="auth-password" name="password" aria-describedby={registering ? "password-help" : undefined} type={showPassword ? "text" : "password"} autoComplete={registering ? "new-password" : "current-password"} required minLength={registering ? 8 : undefined} value={password} onChange={(event) => setPassword(event.target.value)} disabled={loading} className={`${inputClass} pr-12`} />
                <button type="button" onClick={() => setShowPassword((value) => !value)} className="absolute inset-y-0 right-1.5 grid w-9 place-items-center rounded-lg text-secondary hover:text-teal" aria-label={showPassword ? "Hide password" : "Show password"}>{showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button>
              </div>
              {registering && <span id="password-help" className="mt-2 block text-[0.6rem] text-secondary">At least 8 characters. Do not reuse an API key as a password.</span>}
            </div>
            {registering && <label className="block">
              <span className="mb-2 block text-[0.65rem] font-semibold text-ink">First workspace name</span>
              <div className="relative"><Building2 className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sage-dark" aria-hidden="true" /><input name="workspaceName" autoComplete="organization" maxLength={120} value={workspaceName} onChange={(event) => setWorkspaceName(event.target.value)} disabled={loading} className={inputClass} placeholder="My brand" /></div>
            </label>}
            <Button type="submit" disabled={loading} className="mt-2 w-full">{loading ? registering ? "Creating your workspace…" : "Verifying your session…" : registering ? "Create account & workspace" : "Sign in"}</Button>
          </form>

          <p className="mt-6 text-center text-[0.67rem] leading-6 text-secondary">{registering ? "Already created an account? " : "New to Serein? "}<Link href={registering ? "/login" : "/register"} className="font-semibold text-teal hover:text-forest">{registering ? "Sign in" : "Create your workspace"}</Link></p>
          {!registering && <p className="mt-4 border-t border-line pt-4 text-[0.61rem] leading-5 text-secondary">Existing workspace? Sign in with its account email, not its workspace name. Email password recovery is not configured yet.</p>}
        </Panel>
      </div>
    </main>
  );
}
