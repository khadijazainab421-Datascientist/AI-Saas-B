"use client";

import { apiFetch } from "@/lib/api-fetch";

import { useCallback, useEffect, useState } from "react";
import { Activity, ArrowUpRight, Bell, CheckCircle2, Cpu, PlayCircle, RefreshCw, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Panel } from "@/components/ui/panel";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

type Provider = {
  key: string; label: string; kind: string; isPaid: boolean; configured: boolean;
  envVar: string; docsUrl: string; freeTierNote: string; health: string;
  lastCheckedAt: string | null; lastError: string | null; quotaExhaustedUntil: string | null;
  totalRequests: number; totalInputTokens: number; totalOutputTokens: number;
};
type Task = {
  id: number; kind: string; status: string; providerKey: string | null;
  pausedReason: string | null; error: string | null; attempts: number;
  createdAt: string; resumeAfter: string | null;
};
type Notice = { id: number; type: string; title: string; body: string; read: boolean; createdAt: string };
type Settings = {
  allowPaidProviders: boolean; primaryProvider: string;
  dailyAiRequestLimit: number; dailyResearchLimit: number;
};
type Usage = { byProvider: Record<string, { requests: number; errors: number; inputTokens: number; outputTokens: number }>; totalEvents: number };

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await apiFetch(url, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  const data = (await response.json().catch(() => ({}))) as T & { error?: string };
  if (!response.ok) throw new Error(data.error ?? `Request failed (${response.status})`);
  return data;
}

function statusTone(provider: Provider) {
  if (!provider.configured) return "neutral" as const;
  if (provider.health === "healthy") return "sage" as const;
  if (provider.health === "quota_exhausted" || provider.health === "unavailable") return "amber" as const;
  return "neutral" as const;
}

export function AIEngine() {
  const [providers, setProviders] = useState<Provider[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [usage, setUsage] = useState<Usage | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");
  const [message, setMessage] = useState("");
  const [messageTone, setMessageTone] = useState<"info" | "error">("info");

  const load = useCallback(async () => {
    try {
      const [providerData, taskData, noticeData, usageData] = await Promise.all([
        api<{ providers: Provider[]; settings: Settings }>("/api/ai/providers"),
        api<{ tasks: Task[] }>("/api/agent/tasks"),
        api<{ notifications: Notice[]; unread: number }>("/api/notifications"),
        api<Usage>("/api/ai/usage"),
      ]);
      setProviders(providerData.providers);
      setSettings(providerData.settings);
      setTasks(taskData.tasks);
      setNotices(noticeData.notifications);
      setUsage(usageData);
    } catch (err) {
      setMessageTone("error");
      setMessage(err instanceof Error ? err.message : "Could not load AI engine state");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function action(name: string, fn: () => Promise<void>) {
    setBusy(name);
    setMessage("");
    setMessageTone("info");
    try { await fn(); await load(); } catch (err) {
      setMessageTone("error");
      setMessage(err instanceof Error ? err.message : "Action failed");
    } finally { setBusy(""); }
  }

  const configuredAi = providers.filter((p) => p.kind === "ai" && p.configured);
  const configuredResearch = providers.filter((p) => p.kind === "research" && p.configured);

  return (
    <div className="space-y-6">
      <Panel className={cn("p-5 sm:p-6", configuredAi.length === 0 ? "border-[#dfcfb6] bg-[#f7f2e8]" : "border-sage/40 bg-mint/35")}>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex gap-4">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-sage/40 bg-white/60 text-forest">
              <Cpu className="h-5 w-5" strokeWidth={1.4} aria-hidden="true" />
            </span>
            <div>
              <h2 className="font-display text-2xl text-ink">
                {configuredAi.length === 0 ? "Provider credentials pending" : "Provider layer configured"}
              </h2>
              <p className="mt-2 max-w-3xl text-xs leading-6 text-secondary">
                {configuredAi.length === 0
                  ? "No AI provider credential is configured in this environment. The fallback, health, quota, usage, pause, and resume logic is implemented, but no live model call has been made and no AI result has been simulated. Configure a free-tier key to enable live generation."
                  : `${configuredAi.length} AI provider(s) and ${configuredResearch.length} research provider(s) have credentials present. Status below reflects recorded health checks; live calls are only attempted for eligible providers.`}
              </p>
            </div>
          </div>
          <Badge tone={configuredAi.length === 0 ? "amber" : "sage"}>
            {configuredAi.length === 0 ? "Pending configuration" : "Live-capable"}
          </Badge>
        </div>
      </Panel>

      {message && <div role={messageTone === "error" ? "alert" : "status"} className={cn(
        "rounded-xl border p-4 text-xs leading-6",
        messageTone === "error" ? "border-[#e0c4c4] bg-[#fbf0f0] text-[#8b3d3d]" : "border-sage/45 bg-mint/40 text-forest",
      )}>{message}</div>}

      <div className="grid gap-5 xl:grid-cols-[1.45fr_0.55fr]">
        <div>
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="eyebrow">Provider registry</p>
              <h2 className="mt-2 font-display text-2xl text-ink">Primary, backup, and paid controls</h2>
            </div>
            <Button
              type="button"
              variant="secondary"
              disabled={busy === "health"}
              onClick={() => void action("health", async () => {
                const result = await api<{ results: Array<{ key: string; message: string; healthy: boolean }> }>("/api/ai/providers", { method: "POST" });
                const checked = result.results.filter((result) => providers.some((provider) => provider.key === result.key && provider.configured));
                const accepted = checked.filter((result) => result.healthy).length;
                const failed = checked.length - accepted;
                const skipped = result.results.length - checked.length;
                setMessageTone(failed > 0 ? "error" : "info");
                setMessage(`Credential probes: ${accepted} accepted, ${failed} failed; ${skipped} unconfigured providers skipped. This verifies credentials/model listing or usage access, not generation capacity. Run a strategy draft to verify generation and inspect actual fallback attempts.`);
              })}
              className="min-h-9 px-3 text-[0.65rem]"
            >
              <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" /> {busy === "health" ? "Checking…" : "Run health checks"}
            </Button>
          </div>

          {loading ? (
            <div className="grid gap-3 sm:grid-cols-2" role="status" aria-label="Loading providers">
              {[0, 1, 2, 3].map((i) => <div key={i} className="h-40 animate-pulse rounded-2xl bg-sage/10" />)}
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {providers.map((provider) => (
                <Panel key={provider.key} className="flex flex-col p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-[0.55rem] font-bold uppercase tracking-[0.12em] text-sage-dark">{provider.kind} · priority {provider.isPaid ? "paid" : "free"}</p>
                      <h3 className="mt-1 font-display text-xl text-ink">{provider.label}</h3>
                    </div>
                    <Badge tone={statusTone(provider)}>{provider.configured ? provider.health : "not configured"}</Badge>
                  </div>
                  <p className="mt-3 flex-1 text-[0.65rem] leading-5 text-secondary">{provider.freeTierNote}</p>
                  <div className="mt-4 rounded-lg bg-pale/65 p-3">
                    <p className="text-[0.56rem] font-bold uppercase tracking-[0.1em] text-teal">Server-side variable</p>
                    <code className="mt-1 block text-[0.62rem] text-forest">{provider.envVar}</code>
                    <p className="mt-2 text-[0.58rem] leading-4 text-secondary">No secret value is exposed here or stored in the database.</p>
                  </div>
                  {provider.lastError && <p className="mt-3 line-clamp-2 text-[0.58rem] text-[#8b3d3d]">{provider.lastError}</p>}
                  <div className="mt-4 flex items-center justify-between border-t border-line pt-3 text-[0.58rem] text-secondary">
                    <span>{provider.totalRequests} requests · {provider.totalInputTokens + provider.totalOutputTokens} tokens</span>
                    <a href={provider.docsUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-semibold text-teal hover:text-forest">
                      Docs <ArrowUpRight className="h-3 w-3" aria-hidden="true" />
                    </a>
                  </div>
                </Panel>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-5">
          <Panel className="p-5">
            <ShieldCheck className="h-5 w-5 text-teal" strokeWidth={1.4} aria-hidden="true" />
            <h3 className="mt-4 font-display text-2xl text-ink">Paid-provider authorization</h3>
            <p className="mt-2 text-[0.66rem] leading-5 text-secondary">
              Disabled by default. Paid providers are never eligible for automatic fallback or task resumption without explicit workspace authorization.
            </p>
            <label className="mt-5 flex cursor-pointer items-center justify-between gap-3 rounded-xl border border-line bg-pale/50 p-3">
              <span className="text-[0.66rem] font-semibold text-ink">Allow paid providers</span>
              <input
                type="checkbox"
                checked={settings?.allowPaidProviders ?? false}
                disabled={busy === "paid"}
                onChange={(event) => {
                  const value = event.target.checked;
                  void action("paid", async () => {
                    await api("/api/settings", { method: "POST", body: JSON.stringify({ allowPaidProviders: value }) });
                    setMessage(value ? "Paid providers authorized for this workspace." : "Paid providers are no longer eligible.");
                  });
                }}
                className="h-4 w-4 accent-teal"
              />
            </label>
            <label className="mt-4 block">
              <span className="mb-1.5 block text-[0.6rem] font-semibold text-ink">Primary AI provider</span>
              <select
                value={settings?.primaryProvider ?? "gemini"}
                disabled={busy === "primary"}
                onChange={(event) => {
                  const value = event.target.value;
                  void action("primary", async () => {
                    await api("/api/settings", { method: "POST", body: JSON.stringify({ primaryProvider: value }) });
                  });
                }}
                className="w-full rounded-xl border border-line bg-white px-3 py-2.5 text-xs text-ink outline-none focus:border-teal"
              >
                <option value="gemini">Google Gemini (free)</option>
                <option value="groq">Groq (free)</option>
                <option value="openai">OpenAI (paid, opt-in)</option>
              </select>
            </label>
            <p className="mt-4 border-t border-line pt-3 text-[0.58rem] leading-5 text-secondary">
              Daily limits: {settings?.dailyAiRequestLimit ?? "—"} AI requests · {settings?.dailyResearchLimit ?? "—"} research runs. Configurable limits, not unlimited usage.
            </p>
          </Panel>

          <Panel className="p-5">
            <Activity className="h-5 w-5 text-teal" strokeWidth={1.4} aria-hidden="true" />
            <h3 className="mt-4 font-display text-2xl text-ink">Usage tracking</h3>
            <p className="mt-2 text-[0.66rem] leading-5 text-secondary">{usage?.totalEvents ?? 0} recorded events in this workspace. Tokens are provider-reported where available.</p>
            <div className="mt-4 space-y-2">
              {usage && Object.entries(usage.byProvider).length > 0 ? Object.entries(usage.byProvider).map(([key, value]) => (
                <div key={key} className="flex items-center justify-between rounded-lg bg-pale/60 px-3 py-2 text-[0.62rem]">
                  <span className="font-semibold text-ink">{key}</span>
                  <span className="text-secondary">{value.requests} calls · {value.errors} errors · {value.inputTokens + value.outputTokens} tokens</span>
                </div>
              )) : (
                <p className="text-[0.62rem] leading-5 text-secondary">No usage events recorded yet. No estimates are shown as real usage.</p>
              )}
            </div>
          </Panel>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Panel className="p-5">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div>
              <p className="eyebrow">Pause & resume</p>
              <h3 className="mt-2 font-display text-2xl text-ink">Agent tasks</h3>
            </div>
            <Button
              type="button"
              variant="secondary"
              disabled={busy === "resume"}
              onClick={() => void action("resume", async () => {
                const result = await api<{ results: Array<{ taskId: number; status: string }> }>("/api/agent/tasks", { method: "POST", body: "{}" });
                setMessage(`${result.results.length} paused task(s) evaluated for resumption.`);
              })}
              className="min-h-9 px-3 text-[0.65rem]"
            >
              <PlayCircle className="h-3.5 w-3.5" aria-hidden="true" /> Resume eligible
            </Button>
          </div>
          {tasks.length === 0 ? (
            <p className="text-xs leading-6 text-secondary">No agent tasks have been created. Tasks appear only when a real generation attempt is made.</p>
          ) : (
            <div className="space-y-3">
              {tasks.slice(0, 8).map((task) => (
                <div key={task.id} className="rounded-xl border border-line bg-pale/40 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-[0.68rem] font-semibold text-ink">{task.kind} · #{task.id}</span>
                    <Badge tone={task.status === "completed" ? "sage" : task.status === "paused" ? "amber" : "neutral"}>{task.status}</Badge>
                  </div>
                  <p className="mt-2 text-[0.6rem] leading-5 text-secondary">
                    {task.status === "paused" ? task.pausedReason ?? task.error ?? "Paused" : `${task.attempts} attempt(s)${task.providerKey ? ` · ${task.providerKey}` : ""}`}
                  </p>
                  {task.status === "paused" && (
                    <button
                      type="button"
                      onClick={() => void action(`resume-${task.id}`, async () => {
                        await api("/api/agent/tasks", { method: "POST", body: JSON.stringify({ taskId: task.id }) });
                      })}
                      className="mt-2 text-[0.6rem] font-semibold text-teal hover:text-forest"
                    >
                      Retry this task →
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </Panel>

        <Panel className="p-5">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div>
              <p className="eyebrow">Interruption log</p>
              <h3 className="mt-2 font-display text-2xl text-ink">Notifications</h3>
            </div>
            <Button
              type="button"
              variant="ghost"
              disabled={busy === "read"}
              onClick={() => void action("read", async () => {
                await api("/api/notifications", { method: "POST", body: JSON.stringify({ all: true }) });
              })}
              className="min-h-9 px-3 text-[0.65rem]"
            >
              <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" /> Mark read
            </Button>
          </div>
          {notices.length === 0 ? (
            <p className="text-xs leading-6 text-secondary">No interruptions or resumed-task notifications. Alerts are created only for real events.</p>
          ) : (
            <div className="space-y-3">
              {notices.slice(0, 8).map((notice) => (
                <div key={notice.id} className={cn("rounded-xl border p-3", notice.read ? "border-line bg-white/60" : "border-sage/45 bg-mint/35")}>
                  <div className="flex items-center gap-2">
                    <Bell className="h-3.5 w-3.5 text-teal" strokeWidth={1.5} aria-hidden="true" />
                    <p className="text-[0.68rem] font-semibold text-ink">{notice.title}</p>
                  </div>
                  <p className="mt-2 text-[0.62rem] leading-5 text-secondary">{notice.body}</p>
                </div>
              ))}
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}
