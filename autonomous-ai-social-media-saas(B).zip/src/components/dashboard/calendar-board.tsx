"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { fromZonedTime, formatInTimeZone } from "date-fns-tz";
import { CalendarDays, ChevronLeft, ChevronRight, Clock3, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Panel } from "@/components/ui/panel";
import { Badge } from "@/components/ui/badge";
import { studioApi } from "@/lib/studio/client";
import type { PostDTO } from "@/lib/studio/types";
import { cn } from "@/lib/utils";

const weekdays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
function dayKey(date: Date) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`; }
export function CalendarBoard() {
  const [visibleMonth, setVisibleMonth] = useState(() => { const now = new Date(); return new Date(now.getFullYear(), now.getMonth(), 1); });
  const [direction, setDirection] = useState(1); const reduceMotion = useReducedMotion();
  const [zone, setZone] = useState("UTC"); const [businessId, setBusinessId] = useState("");
  const [businesses, setBusinesses] = useState<Array<{ id: number; name: string }>>([]);
  const [posts, setPosts] = useState<PostDTO[]>([]); const [loading, setLoading] = useState(true); const [error, setError] = useState("");
  const [selectedDay, setSelectedDay] = useState<string | null>(null); const [refresh, setRefresh] = useState(0);
  const today = dayKey(new Date());
  useEffect(() => {
    setZone(Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC");
    void studioApi<{ businesses: Array<{ id: number; name: string }> }>("/api/businesses").then((data) => setBusinesses(data.businesses)).catch((problem) => setError(problem instanceof Error ? problem.message : "Business list unavailable."));
  }, []);
  useEffect(() => {
    let cancelled = false;
    setLoading(true); setError("");
    const nextMonth = new Date(visibleMonth.getFullYear(), visibleMonth.getMonth() + 1, 1);
    const start = fromZonedTime(`${dayKey(visibleMonth)}T00:00`, zone).toISOString();
    const end = fromZonedTime(`${dayKey(nextMonth)}T00:00`, zone).toISOString();
    const params = new URLSearchParams({ start, end }); if (businessId) params.set("businessId", businessId);
    void studioApi<{ posts: PostDTO[] }>(`/api/studio/calendar?${params}`).then((data) => { if (!cancelled) setPosts(data.posts); }).catch((problem) => { if (!cancelled) setError(problem instanceof Error ? problem.message : "Calendar records unavailable."); }).finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [visibleMonth, zone, businessId, refresh]);
  const cells = useMemo(() => {
    const leading = (visibleMonth.getDay() + 6) % 7;
    const count = new Date(visibleMonth.getFullYear(), visibleMonth.getMonth() + 1, 0).getDate();
    return Array.from({ length: 42 }, (_, index) => { const day = index - leading + 1; return day > 0 && day <= count ? new Date(visibleMonth.getFullYear(), visibleMonth.getMonth(), day) : null; });
  }, [visibleMonth]);
  const byDay = useMemo(() => {
    const result: Record<string, PostDTO[]> = {};
    for (const post of posts) if (post.scheduledAt) { const key = formatInTimeZone(post.scheduledAt, zone, "yyyy-MM-dd"); (result[key] ??= []).push(post); }
    for (const list of Object.values(result)) list.sort((a, b) => Date.parse(a.scheduledAt!) - Date.parse(b.scheduledAt!));
    return result;
  }, [posts, zone]);
  function move(amount: number) { setDirection(amount); setSelectedDay(null); setVisibleMonth((date) => new Date(date.getFullYear(), date.getMonth() + amount, 1)); }
  const month = new Intl.DateTimeFormat("en", { month: "long", year: "numeric" }).format(visibleMonth);
  const zoneOptions = [...new Set([zone, "UTC", "Asia/Karachi", "Asia/Dubai", "Europe/London", "America/New_York", "America/Los_Angeles", "Australia/Sydney"])];
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end gap-3"><label className="text-[0.6rem] font-semibold text-secondary">Business<select aria-label="Calendar business" value={businessId} onChange={(event) => setBusinessId(event.target.value)} className="mt-2 block rounded-full border border-line bg-white px-4 py-2.5 text-xs text-ink"><option value="">All workspace businesses</option>{businesses.map((business) => <option key={business.id} value={business.id}>{business.name}</option>)}</select></label><label className="text-[0.6rem] font-semibold text-secondary">Display time zone<select aria-label="Calendar time zone" value={zone} onChange={(event) => setZone(event.target.value)} className="mt-2 block rounded-full border border-line bg-white px-4 py-2.5 text-xs text-ink">{zoneOptions.map((item) => <option key={item} value={item}>{item}</option>)}</select></label><Button type="button" variant="ghost" className="min-h-10 px-3" onClick={() => setRefresh((value) => value + 1)} aria-label="Refresh calendar"><RefreshCw className="h-4 w-4" /></Button><Badge tone="amber" className="sm:ml-auto">Publishing not connected</Badge></div>
      {error && <div role="alert" className="rounded-xl border border-[#dfcfb6] bg-[#f7f2e8] p-4 text-xs leading-6 text-[#735c32]">{error} No empty-result or publishing success is assumed.</div>}
      <Panel className="overflow-hidden">
        <div className="flex flex-col gap-5 border-b border-line p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6"><div className="flex items-center gap-4"><span className="grid h-10 w-10 place-items-center rounded-full bg-mint/55 text-forest"><CalendarDays className="h-4 w-4" strokeWidth={1.5} /></span><div><h2 className="font-display text-2xl text-ink" aria-live="polite">{month}</h2><p className="mt-1 text-[0.62rem] text-secondary">{loading ? "Loading saved plans…" : `${posts.length} planned ${posts.length === 1 ? "post" : "posts"} in this view`} · {zone}</p></div></div><div className="flex items-center gap-2"><Button variant="secondary" className="min-h-9 px-4 py-2 text-[0.65rem]" onClick={() => { const now = new Date(); setVisibleMonth(new Date(now.getFullYear(), now.getMonth(), 1)); setSelectedDay(today); }}>Today</Button><Button variant="secondary" aria-label="Previous month" className="min-h-9 w-9 p-0" onClick={() => move(-1)}><ChevronLeft className="h-4 w-4" /></Button><Button variant="secondary" aria-label="Next month" className="min-h-9 w-9 p-0" onClick={() => move(1)}><ChevronRight className="h-4 w-4" /></Button></div></div>
        <div className="grid grid-cols-7 border-b border-line bg-pale/45">{weekdays.map((day) => <div key={day} className="px-1 py-3 text-center text-[0.55rem] font-bold uppercase tracking-[0.11em] text-secondary sm:px-3 sm:text-left">{day}</div>)}</div>
        <div className="relative overflow-hidden"><AnimatePresence mode="popLayout" initial={false}><motion.div key={`${visibleMonth.getFullYear()}-${visibleMonth.getMonth()}`} initial={reduceMotion ? false : { opacity: 0, x: direction * 25 }} animate={{ opacity: 1, x: 0 }} exit={reduceMotion ? undefined : { opacity: 0, x: direction * -25 }} transition={{ duration: 0.22 }} className="grid grid-cols-7">{cells.map((date, index) => {
          const key = date ? dayKey(date) : `empty-${index}`; const events = byDay[key] ?? [];
          return <div key={key} className={cn("min-h-[5.5rem] border-b border-r border-line p-1.5 sm:min-h-36 sm:p-3", index % 7 === 6 && "border-r-0", index >= 35 && "border-b-0", !date && "bg-pale/25", key === selectedDay && "bg-mint/25")}>
            {date && <><button type="button" onClick={() => setSelectedDay(key)} aria-label={`${date.toDateString()}, ${events.length} planned posts`} className={cn("grid h-6 w-6 place-items-center rounded-full text-[0.6rem] font-semibold sm:h-7 sm:w-7 sm:text-[0.66rem]", key === today ? "bg-forest text-white" : "text-secondary hover:bg-mint")}><time dateTime={key}>{date.getDate()}</time></button><div className="mt-2 space-y-1">{events.slice(0, 2).map((post) => <Link key={post.id} href={`/dashboard/studio?post=${post.id}`} className="block overflow-hidden rounded-md border border-sage/25 bg-mint/70 px-1.5 py-1.5 text-[0.53rem] font-semibold leading-4 text-forest transition-colors hover:bg-mint sm:px-2 sm:text-[0.6rem]" title={post.title}><span className="block text-[0.5rem] font-normal opacity-70">{formatInTimeZone(post.scheduledAt!, zone, "HH:mm")}</span><span className="line-clamp-2">{post.title}</span></Link>)}{events.length > 2 && <button type="button" onClick={() => setSelectedDay(key)} className="text-[0.55rem] font-semibold text-teal">+{events.length - 2} more</button>}</div></>}
          </div>;
        })}</motion.div></AnimatePresence></div>
        <div className="flex flex-col gap-2 bg-soft-white px-5 py-4 text-[0.62rem] leading-5 text-secondary sm:flex-row sm:justify-between sm:px-6"><p>{loading ? "Reading actual schedule records…" : posts.length ? "Select a plan to open its saved draft." : "No planned content in this month."}</p><p>Calendar plans do not trigger publishing in Phase 4.</p></div>
      </Panel>
      {selectedDay && <Panel className="p-5"><div className="flex items-center gap-3"><Clock3 className="h-4 w-4 text-teal" /><h3 className="font-display text-2xl text-ink">Plans for {selectedDay}</h3></div>{(byDay[selectedDay] ?? []).length ? <div className="mt-4 divide-y divide-line">{byDay[selectedDay].map((post) => <Link key={post.id} href={`/dashboard/studio?post=${post.id}`} className="flex items-center justify-between gap-4 py-4 text-xs"><span className="font-semibold text-ink">{post.title}</span><span className="text-secondary">{formatInTimeZone(post.scheduledAt!, zone, "HH:mm")} · {post.format === "video" ? "video script" : post.format} ↗</span></Link>)}</div> : <p className="mt-4 text-xs leading-6 text-secondary">No saved plan for this date. Approve and schedule a draft from the Content Studio.</p>}</Panel>}
    </div>
  );
}
