"use client";

import { useEffect, useRef, useState, type ReactNode, type FormEvent } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import {
  ArrowLeft, BarChart3, Building2, CalendarDays, Check, ChevronDown, Compass, Cpu,
  LayoutDashboard, LogOut, Menu, PenTool, PlugZap, Plus, RefreshCw, X, type LucideIcon,
} from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DashboardSkeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { getSession, signOut, switchWorkspace, createWorkspace, navigateInApp, type CurrentSession } from "@/lib/auth-client";
import { PREVIEW_SESSION_EVENT } from "@/lib/session-constants";

const navigation: Array<{ label: string; href: string; icon: LucideIcon }> = [
  { label: "Overview", href: "/dashboard", icon: LayoutDashboard },
  { label: "Businesses", href: "/dashboard/businesses", icon: Building2 },
  { label: "Strategy", href: "/dashboard/strategy", icon: Compass },
  { label: "AI engine", href: "/dashboard/ai", icon: Cpu },
  { label: "Content studio", href: "/dashboard/studio", icon: PenTool },
  { label: "Calendar", href: "/dashboard/calendar", icon: CalendarDays },
  { label: "Integrations", href: "/dashboard/integrations", icon: PlugZap },
  { label: "Analytics", href: "/dashboard/analytics", icon: BarChart3 },
];

function Navigation({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();
  return (
    <nav className="mt-9 space-y-1" aria-label="Workspace navigation">
      <p className="mb-3 px-3 text-[0.56rem] font-bold uppercase tracking-[0.17em] text-sage-dark">Workspace</p>
      {navigation.map((item) => {
        const active = item.href === "/dashboard" ? pathname === item.href : pathname.startsWith(item.href);
        const Icon = item.icon;
        return (
          <Link key={item.href} href={item.href} onClick={onNavigate} aria-current={active ? "page" : undefined}
            className={cn("group relative flex items-center gap-3 rounded-xl px-3 py-3 text-xs font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal", active ? "bg-mint/65 text-forest" : "text-secondary hover:bg-pale hover:text-ink")}>
            {active && <motion.span layoutId="active-navigation" className="absolute bottom-2 left-0 top-2 w-0.5 rounded-full bg-teal" />}
            <Icon className={cn("h-[1.05rem] w-[1.05rem]", active ? "text-teal" : "text-sage-dark group-hover:text-teal")} strokeWidth={1.55} aria-hidden="true" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

function SidebarFooter() {
  return (
    <div className="mt-auto pt-8">
      <div className="rounded-2xl border border-line bg-pale/75 p-4">
        <div className="flex items-center justify-between">
          <p className="text-[0.6rem] font-bold uppercase tracking-[0.13em] text-forest">Foundation</p>
          <span className="text-[0.56rem] font-semibold text-sage-dark">Phase 04</span>
        </div>
        <p className="mt-3 text-[0.66rem] leading-5 text-secondary">Private workspaces, AI strategy, content drafts, media, review and calendar plans. Social publishing and billing are not active.</p>
        <div className="mt-4 h-1 overflow-hidden rounded-full bg-sage/20"><div className="h-full w-[50%] rounded-full bg-sage-dark" aria-label="Phase 4 of 8" /></div>
      </div>
      <Link href="/" className="mt-4 flex items-center gap-2 px-2 py-2 text-[0.65rem] font-semibold text-secondary hover:text-teal"><ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" /> Back to Serein site</Link>
    </div>
  );
}

function WorkspaceForm({ onDone }: { onDone?: () => void }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true); setError("");
    try {
      const workspace = await createWorkspace(name.trim());
      await switchWorkspace(workspace.id);
      onDone?.();
      navigateInApp("/dashboard", router);
    } catch (problem) {
      setError(problem instanceof Error ? problem.message : "Could not create workspace");
      setBusy(false);
    }
  }
  return (
    <form onSubmit={submit} className="space-y-3">
      <label className="block text-[0.65rem] font-semibold text-ink">New workspace name
        <input required maxLength={120} value={name} onChange={(event) => setName(event.target.value)} disabled={busy} className="mt-2 w-full rounded-xl border border-line bg-white px-3 py-2.5 text-xs outline-none focus:border-teal" />
      </label>
      {error && <p role="alert" className="text-[0.65rem] leading-5 text-[#8b3d3d]">{error}</p>}
      <Button type="submit" className="min-h-9 w-full px-3 py-2 text-[0.65rem]" disabled={busy || !name.trim()}>{busy ? "Creating…" : "Create workspace"}</Button>
    </form>
  );
}

function SessionBar({ session }: { session: CurrentSession }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    setOpen(false);
    setCreating(false);
    setBusy(false);
  }, [session.activeWorkspaceId]);
  const root = useRef<HTMLDivElement>(null);
  const activeWorkspace = session.workspaces.find((workspace) => workspace.id === session.activeWorkspaceId);
  const initials = (session.user.name?.split(/\s+/).map((part) => part[0]).join("") || session.user.email).slice(0, 2).toUpperCase();

  useEffect(() => {
    if (!open) return;
    const close = (event: PointerEvent) => { if (root.current && !root.current.contains(event.target as Node)) setOpen(false); };
    const escape = (event: KeyboardEvent) => { if (event.key === "Escape") setOpen(false); };
    document.addEventListener("pointerdown", close); document.addEventListener("keydown", escape);
    return () => { document.removeEventListener("pointerdown", close); document.removeEventListener("keydown", escape); };
  }, [open]);

  async function action(fn: () => Promise<void>) {
    setBusy(true); setError("");
    try { await fn(); } catch (problem) {
      setError(problem instanceof Error ? problem.message : "Account action could not be completed");
      setBusy(false);
    }
  }

  return (
    <div ref={root} className="relative">
      <button type="button" aria-label="Account and workspaces" aria-expanded={open} aria-controls="account-workspace-menu" onClick={() => setOpen((value) => !value)} className="flex min-h-10 items-center gap-2.5 rounded-full border border-line bg-white py-1 pl-1 pr-3 text-forest hover:border-sage/70">
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-mint/70 font-display text-xs" aria-hidden="true">{initials}</span>
        <span className="hidden max-w-40 truncate text-[0.68rem] font-semibold sm:block">{activeWorkspace?.name ?? "Choose workspace"}</span>
        <ChevronDown className="h-3.5 w-3.5 text-secondary" aria-hidden="true" />
      </button>
      {open && (
        <div id="account-workspace-menu" className="absolute right-0 z-50 mt-3 w-[min(20rem,calc(100vw-2rem))] overflow-hidden rounded-2xl border border-line bg-white shadow-[0_16px_50px_rgba(22,78,74,0.12)]">
          <div className="border-b border-line px-4 py-4">
            <p className="text-[0.55rem] font-bold uppercase tracking-[0.13em] text-sage-dark">Signed in as</p>
            <p className="mt-1 truncate text-xs font-semibold text-ink">{session.user.email}</p>
          </div>
          <div className="max-h-56 overflow-auto p-2">
            {session.workspaces.map((workspace) => (
              <button key={workspace.id} type="button" disabled={busy} aria-label={`Switch to workspace ${workspace.name}`} onClick={() => {
                if (workspace.id === session.activeWorkspaceId) { setOpen(false); return; }
                void action(async () => { await switchWorkspace(workspace.id); navigateInApp("/dashboard", router); });
              }} className={cn("flex w-full items-center gap-2 rounded-xl px-3 py-3 text-left text-xs transition-colors", workspace.id === session.activeWorkspaceId ? "bg-mint/55 text-forest" : "text-secondary hover:bg-pale")}>
                <Building2 className="h-4 w-4 shrink-0" strokeWidth={1.5} aria-hidden="true" /><span className="min-w-0 flex-1 truncate">{workspace.name}</span>
                {workspace.id === session.activeWorkspaceId && <Check className="h-3.5 w-3.5" aria-hidden="true" />}
              </button>
            ))}
            <button type="button" onClick={() => setCreating((value) => !value)} className="flex w-full items-center gap-2 rounded-xl px-3 py-3 text-xs font-semibold text-teal hover:bg-pale"><Plus className="h-4 w-4" aria-hidden="true" /> New workspace</button>
          </div>
          {creating && <div className="border-t border-line p-4"><WorkspaceForm /></div>}
          {error && <p role="alert" className="px-4 pb-3 text-[0.65rem] leading-5 text-[#8b3d3d]">{error}</p>}
          <button type="button" disabled={busy} onClick={() => void action(async () => { await signOut(); navigateInApp("/login", router); })} className="flex w-full items-center gap-2 border-t border-line px-5 py-4 text-xs font-semibold text-forest hover:bg-pale"><LogOut className="h-4 w-4" aria-hidden="true" /> {busy ? "Working…" : "Sign out"}</button>
        </div>
      )}
    </div>
  );
}

export function DashboardShell({ children }: { children: ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();
  const router = useRouter();
  const reduceMotion = useReducedMotion();
  const [session, setSession] = useState<CurrentSession | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [retry, setRetry] = useState(0);
  const current = navigation.find((item) => item.href === "/dashboard" ? pathname === item.href : pathname.startsWith(item.href));

  useEffect(() => {
    let cancelled = false;
    setLoading(true); setLoadError("");
    void getSession().then((data) => { if (!cancelled) setSession(data); })
      .catch((error: unknown) => { if (!cancelled) setLoadError(error instanceof Error ? error.message : "Session could not be loaded"); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [retry]);

  useEffect(() => {
    if (!loading && !loadError && !session) router.replace("/login");
  }, [loading, loadError, session, router]);

  useEffect(() => {
    const updateSession = () => setRetry((value) => value + 1);
    window.addEventListener(PREVIEW_SESSION_EVENT, updateSession);
    return () => window.removeEventListener(PREVIEW_SESSION_EVENT, updateSession);
  }, []);

  useEffect(() => { setMenuOpen(false); }, [pathname]);
  useEffect(() => {
    if (!menuOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = previous; };
  }, [menuOpen]);

  return (
    <div className="min-h-screen bg-pale/55">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-line bg-soft-white px-5 py-6 lg:flex">
        <div className="px-2"><Logo href="/dashboard" /></div><Navigation /><SidebarFooter />
      </aside>
      <AnimatePresence>
        {menuOpen && <>
          <motion.button type="button" aria-label="Close workspace navigation" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setMenuOpen(false)} className="fixed inset-0 z-50 bg-ink/25 backdrop-blur-sm lg:hidden" />
          <motion.aside initial={reduceMotion ? false : { x: "-100%" }} animate={{ x: 0 }} exit={reduceMotion ? undefined : { x: "-100%" }} transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }} className="fixed inset-y-0 left-0 z-50 flex w-[min(19rem,88vw)] flex-col bg-soft-white px-5 py-6 shadow-2xl lg:hidden">
            <div className="flex items-center justify-between px-2"><Logo href="/dashboard" /><button type="button" onClick={() => setMenuOpen(false)} aria-label="Close navigation" className="grid h-10 w-10 place-items-center rounded-full border border-line text-forest"><X className="h-4 w-4" aria-hidden="true" /></button></div>
            <Navigation onNavigate={() => setMenuOpen(false)} /><SidebarFooter />
          </motion.aside>
        </>}
      </AnimatePresence>
      <div className="min-h-screen lg:pl-64">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b border-line/90 bg-soft-white/90 px-5 backdrop-blur-xl sm:px-8 lg:px-10">
          <div className="flex min-w-0 items-center gap-3">
            <button type="button" onClick={() => setMenuOpen(true)} aria-label="Open workspace navigation" className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-line bg-white text-forest lg:hidden"><Menu className="h-4 w-4" aria-hidden="true" /></button>
            <div><p className="text-[0.55rem] font-semibold uppercase tracking-[0.13em] text-sage-dark">Your workspace</p><p className="mt-0.5 text-xs font-semibold text-ink">{current?.label ?? "Workspace"}</p></div>
          </div>
          <div className="flex shrink-0 items-center gap-3"><Badge tone="neutral" className="hidden xl:inline-flex">Phase 04 · Content studio</Badge>{session && <SessionBar session={session} />}</div>
        </header>
        <motion.main key={`${pathname}:${session?.activeWorkspaceId ?? "none"}`} initial={reduceMotion ? false : { opacity: 0, y: 9 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.38 }} className="mx-auto w-full max-w-[1500px] p-5 sm:p-8 lg:p-10">
          {session?.sessionTransport === "preview" && <div role="status" className="mb-6 rounded-xl border border-sage/45 bg-mint/40 px-4 py-3 text-xs leading-6 text-forest"><strong>Temporary preview session.</strong> Cookies are blocked here, so this tab uses a short-lived verified session. Keep the tab open; a full refresh requires sign-in again. Saved workspace data stays in the database.</div>}
          {loading ? <DashboardSkeleton /> : loadError ? (
            <div role="alert" className="mx-auto mt-16 max-w-md rounded-2xl border border-line bg-white p-7 text-center">
              <h1 className="font-display text-3xl text-ink">The session could not be loaded.</h1><p className="mt-3 text-xs leading-6 text-secondary">{loadError}</p>
              <Button onClick={() => setRetry((value) => value + 1)} className="mt-6"><RefreshCw className="h-4 w-4" aria-hidden="true" /> Retry session</Button>
              <Link href="/login" className="mt-4 block text-xs font-semibold text-teal">Return to sign in</Link>
            </div>
          ) : !session ? <p role="status" className="py-20 text-center text-sm text-secondary">Returning to sign in…</p> : !session.activeWorkspaceId ? (
            <section className="mx-auto mt-10 max-w-md rounded-2xl border border-line bg-white p-7"><h1 className="font-display text-3xl text-ink">Create a workspace to begin.</h1><p className="mb-6 mt-3 text-xs leading-6 text-secondary">Your account is signed in. Create a private workspace before adding businesses or running the agent.</p><WorkspaceForm /></section>
          ) : children}
        </motion.main>
      </div>
    </div>
  );
}
