"use client";

import { apiFetch } from "@/lib/api-fetch";

import { useEffect, useState } from "react";
import { Building2, Globe2, Plus, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Panel } from "@/components/ui/panel";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/empty-state";

type Business = {
  id: number;
  name: string;
  website: string | null;
  industry: string | null;
  description: string | null;
  targetAudience: string | null;
  brandVoice: string | null;
  createdAt: string;
};

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await apiFetch(url, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  const data = (await response.json().catch(() => ({}))) as T & { error?: string };
  if (!response.ok) throw new Error(data.error ?? `Request failed (${response.status})`);
  return data;
}

export function BusinessManager() {
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    name: "",
    website: "",
    industry: "",
    description: "",
    targetAudience: "",
    brandVoice: "",
  });

  async function load() {
    setLoading(true);
    setError("");
    try {
      const data = await api<{ businesses: Business[] }>("/api/businesses");
      setBusinesses(data.businesses);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load businesses");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load(); }, []);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setSaving(true);
    setError("");
    try {
      await api("/api/businesses", { method: "POST", body: JSON.stringify(form) });
      setForm({ name: "", website: "", industry: "", description: "", targetAudience: "", brandVoice: "" });
      setShowForm(false);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create business");
    } finally {
      setSaving(false);
    }
  }

  const field = (key: keyof typeof form, label: string, placeholder: string) => (
    <label className="block">
      <span className="mb-1.5 block text-[0.62rem] font-semibold text-ink">{label}</span>
      <input
        value={form[key]}
        onChange={(event) => setForm((current) => ({ ...current, [key]: event.target.value }))}
        placeholder={placeholder}
        className="w-full rounded-xl border border-line bg-white px-3 py-2.5 text-xs text-ink outline-none transition-colors focus:border-teal"
      />
    </label>
  );

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="eyebrow">Tenant-scoped records</p>
          <h2 className="mt-2 font-display text-2xl text-ink">Your business profiles</h2>
        </div>
        <div className="flex gap-2">
          <Button type="button" variant="secondary" onClick={() => void load()} className="min-h-9 px-3 text-[0.65rem]">
            <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" /> Refresh
          </Button>
          <Button type="button" onClick={() => setShowForm((v) => !v)} className="min-h-9 px-3 text-[0.65rem]">
            <Plus className="h-3.5 w-3.5" aria-hidden="true" /> Add business
          </Button>
        </div>
      </div>

      {error && (
        <div role="alert" className="mb-5 rounded-xl border border-[#dfcfb6] bg-[#f7f2e8] p-4 text-xs text-[#735c32]">{error}</div>
      )}

      {showForm && (
        <Panel className="mb-5 p-5">
          <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
            {field("name", "Business name *", "e.g. Northline Studio")}
            {field("website", "Website", "https://example.com")}
            {field("industry", "Industry", "e.g. Architecture")}
            {field("targetAudience", "Target audience", "Who do you serve?")}
            <label className="sm:col-span-2">
              <span className="mb-1.5 block text-[0.62rem] font-semibold text-ink">Description</span>
              <textarea
                value={form.description}
                onChange={(event) => setForm((current) => ({ ...current, description: event.target.value }))}
                rows={3}
                placeholder="Products, services, and what makes the business distinct"
                className="w-full resize-y rounded-xl border border-line bg-white px-3 py-2.5 text-xs text-ink outline-none focus:border-teal"
              />
            </label>
            <label className="sm:col-span-2">
              <span className="mb-1.5 block text-[0.62rem] font-semibold text-ink">Brand voice notes</span>
              <textarea
                value={form.brandVoice}
                onChange={(event) => setForm((current) => ({ ...current, brandVoice: event.target.value }))}
                rows={2}
                placeholder="Tone, vocabulary, and communication style"
                className="w-full resize-y rounded-xl border border-line bg-white px-3 py-2.5 text-xs text-ink outline-none focus:border-teal"
              />
            </label>
            <div className="sm:col-span-2">
              <Button type="submit" disabled={saving || !form.name.trim()}>
                {saving ? "Saving…" : "Save business"}
              </Button>
            </div>
          </form>
        </Panel>
      )}

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2" role="status" aria-label="Loading businesses">
          {[0, 1].map((i) => <div key={i} className="h-36 animate-pulse rounded-2xl bg-sage/10" />)}
        </div>
      ) : businesses.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="No business profiles yet"
          description="Create a business to give the AI agent real, user-provided context. Business records are persisted in PostgreSQL and scoped to this workspace only."
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {businesses.map((business) => (
            <Panel key={business.id} className="p-5">
              <div className="flex items-start justify-between gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-mint/60 text-forest">
                  <Building2 className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
                </span>
                <Badge tone="neutral">ID {business.id}</Badge>
              </div>
              <h3 className="mt-4 font-display text-2xl text-ink">{business.name}</h3>
              {business.industry && <p className="mt-1 text-[0.66rem] font-semibold uppercase tracking-[0.1em] text-teal">{business.industry}</p>}
              {business.description && <p className="mt-3 line-clamp-3 text-xs leading-6 text-secondary">{business.description}</p>}
              {business.website && (
                <a href={business.website} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 text-[0.65rem] font-semibold text-teal hover:text-forest">
                  <Globe2 className="h-3.5 w-3.5" aria-hidden="true" /> {business.website}
                </a>
              )}
            </Panel>
          ))}
        </div>
      )}
    </div>
  );
}
