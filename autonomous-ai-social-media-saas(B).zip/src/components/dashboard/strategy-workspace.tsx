"use client";

import { apiFetch } from "@/lib/api-fetch";

import { useCallback, useEffect, useState } from "react";
import { ArrowUpRight, BookOpen, Compass, FileSearch, Globe2, Search, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Panel } from "@/components/ui/panel";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/empty-state";
import { cn } from "@/lib/utils";

type Business = { id: number; name: string; website: string | null };
type BrandProfile = {
  tone: string | null; voiceDescription: string | null; vocabulary: string[] | null;
  audience: string | null; objectives: string | null; claimsPolicy: string | null;
  restrictedTopics: string[] | null; styleExamples: string[] | null;
};
type Analysis = {
  id: number; url: string; status: string; title: string | null; metaDescription: string | null;
  headings: string[] | null; wordCount: number; aiSummary: unknown; providerKey: string | null; error: string | null;
};
type Source = { id: number; url: string; title: string | null; snippet: string | null; providerKey: string };
type ResearchRun = { id: number; query: string; status: string; providerKey: string | null; creditsUsed: number; error: string | null };
type Strategy = {
  id: number; version: number; status: string; pillars: unknown; formats: unknown; cadence: unknown;
  rationale: string | null; reviewFlags: string[] | null; sources: string[] | null; providerKey: string | null; createdAt: string;
};

const TABS = [
  { id: "brand", label: "Brand profile", icon: BookOpen },
  { id: "website", label: "Website analysis", icon: Globe2 },
  { id: "research", label: "Research", icon: Search },
  { id: "strategy", label: "Strategy", icon: Compass },
] as const;
type TabId = (typeof TABS)[number]["id"];

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await apiFetch(url, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  const data = (await response.json().catch(() => ({}))) as T & { error?: string };
  if (!response.ok) throw new Error(data.error ?? `Request failed (${response.status})`);
  return data;
}

function json(value: unknown) {
  return JSON.stringify(value ?? null, null, 2);
}

export function StrategyWorkspace() {
  const [tab, setTab] = useState<TabId>("brand");
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [businessId, setBusinessId] = useState<number | null>(null);
  const [notice, setNotice] = useState<{ tone: "ok" | "warn" | "error"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  const [profile, setProfile] = useState<BrandProfile>({
    tone: "", voiceDescription: "", vocabulary: [], audience: "", objectives: "",
    claimsPolicy: "", restrictedTopics: [], styleExamples: [],
  });
  const [lists, setLists] = useState({ vocabulary: "", restrictedTopics: "", styleExamples: "" });
  const [analyses, setAnalyses] = useState<Analysis[]>([]);
  const [websiteUrl, setWebsiteUrl] = useState("");
  const [researchQuery, setResearchQuery] = useState("");
  const [runs, setRuns] = useState<ResearchRun[]>([]);
  const [sources, setSources] = useState<Source[]>([]);
  const [strategies, setStrategies] = useState<Strategy[]>([]);

  const loadContext = useCallback(async (id: number) => {
    try {
      const [profileData, analysisData, researchData, strategyData] = await Promise.all([
        api<{ profile: BrandProfile | null }>(`/api/brand-profiles?businessId=${id}`),
        api<{ analyses: Analysis[] }>(`/api/analysis/website?businessId=${id}`),
        api<{ runs: ResearchRun[]; sources: Source[] }>(`/api/research?businessId=${id}`),
        api<{ context: { strategies: Strategy[] } }>(`/api/strategy?businessId=${id}`),
      ]);
      if (profileData.profile) {
        const p = profileData.profile;
        setProfile({
          tone: p.tone ?? "", voiceDescription: p.voiceDescription ?? "", vocabulary: p.vocabulary ?? [],
          audience: p.audience ?? "", objectives: p.objectives ?? "", claimsPolicy: p.claimsPolicy ?? "",
          restrictedTopics: p.restrictedTopics ?? [], styleExamples: p.styleExamples ?? [],
        });
        setLists({
          vocabulary: (p.vocabulary ?? []).join(", "),
          restrictedTopics: (p.restrictedTopics ?? []).join(", "),
          styleExamples: (p.styleExamples ?? []).join("\n"),
        });
      } else {
        setProfile({
          tone: "", voiceDescription: "", vocabulary: [], audience: "", objectives: "",
          claimsPolicy: "", restrictedTopics: [], styleExamples: [],
        });
        setLists({ vocabulary: "", restrictedTopics: "", styleExamples: "" });
      }
      setWebsiteUrl("");
      setAnalyses(analysisData.analyses);
      setRuns(researchData.runs);
      setSources(researchData.sources);
      setStrategies(strategyData.context.strategies);
    } catch (err) {
      setNotice({ tone: "error", text: err instanceof Error ? err.message : "Could not load strategy context" });
    }
  }, []);

  useEffect(() => {
    void (async () => {
      try {
        const data = await api<{ businesses: Business[] }>("/api/businesses");
        setBusinesses(data.businesses);
        if (data.businesses[0]) {
          setBusinessId(data.businesses[0].id);
          await loadContext(data.businesses[0].id);
        }
      } catch (err) {
        setNotice({ tone: "error", text: err instanceof Error ? err.message : "Could not load businesses" });
      }
    })();
  }, [loadContext]);

  async function selectBusiness(id: number) {
    setBusinessId(id);
    setNotice(null);
    await loadContext(id);
  }

  async function withBusy(fn: () => Promise<void>) {
    setBusy(true);
    setNotice(null);
    try { await fn(); } finally { setBusy(false); }
  }

  async function saveProfile(event: React.FormEvent) {
    event.preventDefault();
    if (!businessId) return;
    await withBusy(async () => {
      try {
        await api("/api/brand-profiles", {
          method: "POST",
          body: JSON.stringify({
            businessId,
            ...profile,
            vocabulary: lists.vocabulary.split(",").map((v) => v.trim()).filter(Boolean),
            restrictedTopics: lists.restrictedTopics.split(",").map((v) => v.trim()).filter(Boolean),
            styleExamples: lists.styleExamples.split("\n").map((v) => v.trim()).filter(Boolean),
          }),
        });
        setNotice({ tone: "ok", text: "Brand profile saved to this workspace." });
      } catch (err) {
        setNotice({ tone: "error", text: err instanceof Error ? err.message : "Could not save brand profile" });
      }
    });
  }

  async function analyze(event: React.FormEvent) {
    event.preventDefault();
    if (!businessId) return;
    await withBusy(async () => {
      try {
        const result = await api<{ aiStatus: string; reason?: string }>("/api/analysis/website", {
          method: "POST",
          body: JSON.stringify({
            businessId,
            url: websiteUrl.trim() || businesses.find((business) => business.id === businessId)?.website || "",
          }),
        });
        setNotice({
          tone: result.aiStatus === "completed" ? "ok" : "warn",
          text: result.aiStatus === "completed"
            ? "Website extracted and interpreted by an eligible AI provider."
            : result.reason ?? "Website content was extracted; AI interpretation is pending.",
        });
        await loadContext(businessId);
      } catch (err) {
        setNotice({ tone: "error", text: err instanceof Error ? err.message : "Website analysis failed" });
      }
    });
  }

  async function research(event: React.FormEvent) {
    event.preventDefault();
    if (!businessId) return;
    await withBusy(async () => {
      try {
        const result = await api<{ status: string; reason?: string; providerKey?: string; sources: Source[] }>("/api/research", {
          method: "POST",
          body: JSON.stringify({ businessId, query: researchQuery, maxResults: 5 }),
        });
        setNotice({
          tone: result.status === "completed" ? "ok" : "warn",
          text: result.status === "completed"
            ? `${result.sources.length} sources returned by ${result.providerKey}. Provenance was recorded.`
            : result.reason ?? "Research paused. No sources were invented.",
        });
        await loadContext(businessId);
      } catch (err) {
        setNotice({ tone: "error", text: err instanceof Error ? err.message : "Research request failed" });
      }
    });
  }

  async function generate() {
    if (!businessId) return;
    await withBusy(async () => {
      try {
        const result = await api<{ status: string; reason?: string; providerKey?: string; strategyId?: number; taskId?: number }>("/api/strategy", {
          method: "POST",
          body: JSON.stringify({ businessId }),
        });
        setNotice({
          tone: result.status === "completed" ? "ok" : "warn",
          text: result.status === "completed"
            ? `Strategy draft #${result.strategyId ?? "?"} created using ${result.providerKey}. It requires human review.`
            : `Task ${result.taskId ?? ""} was paused: ${result.reason ?? "no eligible provider"}. Work was preserved and can be resumed from the AI Engine.`,
        });
        await loadContext(businessId);
      } catch (err) {
        setNotice({ tone: "error", text: err instanceof Error ? err.message : "Strategy generation failed" });
      }
    });
  }

  if (businesses.length === 0) {
    return (
      <EmptyState
        icon={Compass}
        title="Add a business first"
        description="Strategy generation needs a real business profile. Create one under Businesses, then return here to configure its brand voice, website analysis, and research."
      />
    );
  }

  const activeBusiness = businesses.find((b) => b.id === businessId);

  return (
    <div>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">
          {businesses.map((business) => (
            <button
              key={business.id}
              type="button"
              onClick={() => void selectBusiness(business.id)}
              className={cn(
                "rounded-full border px-4 py-2 text-[0.68rem] font-semibold transition-colors",
                business.id === businessId ? "border-teal/25 bg-mint/70 text-forest" : "border-line bg-white text-secondary hover:text-ink",
              )}
            >
              {business.name}
            </button>
          ))}
        </div>
        <Badge tone="neutral">Workspace-scoped context</Badge>
      </div>

      <div className="no-scrollbar mb-6 flex gap-2 overflow-x-auto border-b border-line pb-3">
        {TABS.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              aria-pressed={tab === item.id}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-full px-4 py-2.5 text-[0.68rem] font-semibold transition-colors",
                tab === item.id ? "bg-forest text-white" : "text-secondary hover:bg-mint/50 hover:text-forest",
              )}
            >
              <Icon className="h-3.5 w-3.5" strokeWidth={1.5} aria-hidden="true" /> {item.label}
            </button>
          );
        })}
      </div>

      {notice && (
        <div role="status" className={cn(
          "mb-6 rounded-xl border p-4 text-xs leading-6",
          notice.tone === "ok" ? "border-sage/45 bg-mint/45 text-forest" :
          notice.tone === "warn" ? "border-[#dfcfb6] bg-[#f7f2e8] text-[#735c32]" :
          "border-[#e0c4c4] bg-[#fbf0f0] text-[#8b3d3d]",
        )}>
          {notice.text}
        </div>
      )}

      {tab === "brand" && (
        <Panel className="p-6">
          <p className="eyebrow">User-provided brand rules</p>
          <h2 className="mt-2 font-display text-2xl text-ink">Voice, boundaries, and evidence</h2>
          <p className="mt-2 max-w-2xl text-xs leading-6 text-secondary">
            These rules are persisted per business and injected into every strategy prompt. Restricted topics also drive deterministic claim-review flags.
          </p>
          <form onSubmit={saveProfile} className="mt-6 grid gap-4 sm:grid-cols-2">
            {([
              ["tone", "Tone", "Calm, precise, warm"],
              ["voiceDescription", "Voice description", "How the brand should sound"],
              ["vocabulary", "Approved vocabulary (comma separated)", "craft, longevity, considered"],
              ["restrictedTopics", "Restricted topics (comma separated)", "pricing guarantees, medical claims"],
              ["audience", "Audience", "Who this brand speaks to"],
              ["objectives", "Objectives", "What content should accomplish"],
            ] as const).map(([key, label, placeholder]) => (
              <label key={key} className="block">
                <span className="mb-1.5 block text-[0.62rem] font-semibold text-ink">{label}</span>
                <input
                  value={key === "vocabulary" || key === "restrictedTopics" ? lists[key] : (profile[key] as string) ?? ""}
                  onChange={(event) => {
                    if (key === "vocabulary" || key === "restrictedTopics") {
                      setLists((current) => ({ ...current, [key]: event.target.value }));
                    } else {
                      setProfile((current) => ({ ...current, [key]: event.target.value }));
                    }
                  }}
                  placeholder={placeholder}
                  className="w-full rounded-xl border border-line bg-white px-3 py-2.5 text-xs text-ink outline-none focus:border-teal"
                />
              </label>
            ))}
            <label className="sm:col-span-2">
              <span className="mb-1.5 block text-[0.62rem] font-semibold text-ink">Claims policy</span>
              <textarea
                rows={2}
                value={profile.claimsPolicy ?? ""}
                onChange={(event) => setProfile((current) => ({ ...current, claimsPolicy: event.target.value }))}
                placeholder="What the brand must never assert without evidence"
                className="w-full resize-y rounded-xl border border-line bg-white px-3 py-2.5 text-xs text-ink outline-none focus:border-teal"
              />
            </label>
            <label className="sm:col-span-2">
              <span className="mb-1.5 block text-[0.62rem] font-semibold text-ink">Style examples (one per line)</span>
              <textarea
                rows={3}
                value={lists.styleExamples}
                onChange={(event) => setLists((current) => ({ ...current, styleExamples: event.target.value }))}
                placeholder="Example captions the brand approves of"
                className="w-full resize-y rounded-xl border border-line bg-white px-3 py-2.5 text-xs text-ink outline-none focus:border-teal"
              />
            </label>
            <div className="sm:col-span-2">
              <Button type="submit" disabled={busy || !activeBusiness}>{busy ? "Saving…" : "Save brand profile"}</Button>
            </div>
          </form>
        </Panel>
      )}

      {tab === "website" && (
        <div className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
          <Panel className="p-6">
            <p className="eyebrow">Deterministic extraction</p>
            <h2 className="mt-2 font-display text-2xl text-ink">Read the business website</h2>
            <p className="mt-2 text-xs leading-6 text-secondary">
              Public HTML is fetched server-side with private-host blocking and redirect protection. Extraction works without credentials; AI interpretation is a separate, explicitly reported step.
            </p>
            <form onSubmit={analyze} className="mt-6">
              <label htmlFor="website-url" className="mb-1.5 block text-[0.62rem] font-semibold text-ink">Public website URL</label>
              <input
                id="website-url"
                type="url"
                required
                value={websiteUrl || activeBusiness?.website || ""}
                onChange={(event) => setWebsiteUrl(event.target.value)}
                placeholder="https://example.com"
                className="w-full rounded-xl border border-line bg-white px-3 py-2.5 text-xs text-ink outline-none focus:border-teal"
              />
              <Button type="submit" disabled={busy} className="mt-4">{busy ? "Analysing…" : "Extract & interpret"}</Button>
            </form>
            <p className="mt-5 border-t border-line pt-4 text-[0.62rem] leading-5 text-secondary">
              DNS-rebinding protection requires an egress proxy in production. This limitation is disclosed rather than hidden.
            </p>
          </Panel>
          <Panel className="p-6">
            <h3 className="font-display text-2xl text-ink">Analysis records</h3>
            {analyses.length === 0 ? (
              <p className="mt-4 text-xs leading-6 text-secondary">No website has been extracted for this business yet. No interpretation is assumed.</p>
            ) : (
              <div className="mt-4 space-y-3">
                {analyses.map((analysis) => (
                  <article key={analysis.id} className="rounded-xl border border-line bg-pale/45 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <Badge tone={analysis.status === "failed" ? "amber" : analysis.status === "analysed" ? "sage" : "neutral"}>{analysis.status}</Badge>
                      <span className="text-[0.58rem] text-secondary">{analysis.wordCount} words extracted</span>
                    </div>
                    <p className="mt-3 truncate text-xs font-semibold text-ink">{analysis.title ?? analysis.url}</p>
                    {analysis.metaDescription && <p className="mt-1 line-clamp-2 text-[0.65rem] leading-5 text-secondary">{analysis.metaDescription}</p>}
                    {analysis.error && <p className="mt-2 text-[0.65rem] text-[#8b3d3d]">{analysis.error}</p>}
                    {Boolean(analysis.aiSummary) && (
                      <details className="mt-3">
                        <summary className="cursor-pointer text-[0.62rem] font-semibold text-teal">View AI interpretation / pending status</summary>
                        <pre className="mt-2 max-h-48 overflow-auto rounded-lg bg-white p-3 text-[0.6rem] leading-5 text-secondary">{json(analysis.aiSummary)}</pre>
                      </details>
                    )}
                  </article>
                ))}
              </div>
            )}
          </Panel>
        </div>
      )}

      {tab === "research" && (
        <div className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
          <Panel className="p-6">
            <p className="eyebrow">Source-aware discovery</p>
            <h2 className="mt-2 font-display text-2xl text-ink">Research a topic</h2>
            <p className="mt-2 text-xs leading-6 text-secondary">
              Queries run through an eligible configured provider. Returned URLs, titles, snippets, provider name, and credit cost are stored. If no provider is available, the run is paused with an explicit reason — no topics are invented.
            </p>
            <form onSubmit={research} className="mt-6">
              <label htmlFor="research-query" className="mb-1.5 block text-[0.62rem] font-semibold text-ink">Research query</label>
              <textarea
                id="research-query"
                required
                rows={3}
                minLength={3}
                value={researchQuery}
                onChange={(event) => setResearchQuery(event.target.value)}
                placeholder="e.g. current topics in sustainable architecture for 2026"
                className="w-full resize-y rounded-xl border border-line bg-white px-3 py-2.5 text-xs text-ink outline-none focus:border-teal"
              />
              <Button type="submit" disabled={busy} className="mt-4">{busy ? "Researching…" : "Run research"}</Button>
            </form>
            <div className="mt-6 border-t border-line pt-4">
              <p className="text-[0.58rem] font-bold uppercase tracking-[0.12em] text-sage-dark">Recent runs</p>
              {runs.length === 0 ? <p className="mt-2 text-[0.65rem] text-secondary">No research runs recorded.</p> : (
                <ul className="mt-3 space-y-2">
                  {runs.slice(0, 5).map((run) => (
                    <li key={run.id} className="flex items-start justify-between gap-3 text-[0.65rem]">
                      <span className="line-clamp-1 text-ink">{run.query}</span>
                      <Badge tone={run.status === "completed" ? "sage" : "amber"}>{run.status}</Badge>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </Panel>
          <Panel className="p-6">
            <h3 className="font-display text-2xl text-ink">Verified sources</h3>
            {sources.length === 0 ? (
              <p className="mt-4 text-xs leading-6 text-secondary">No sources have been retrieved. Strategy generation will state that research is unavailable rather than implying otherwise.</p>
            ) : (
              <div className="mt-4 space-y-3">
                {sources.slice(0, 12).map((source) => (
                  <a key={source.id} href={source.url} target="_blank" rel="noreferrer" className="group block rounded-xl border border-line bg-pale/40 p-4 transition-colors hover:border-sage/60">
                    <div className="flex items-start justify-between gap-3">
                      <p className="text-xs font-semibold leading-5 text-ink">{source.title ?? source.url}</p>
                      <ArrowUpRight className="h-3.5 w-3.5 shrink-0 text-sage-dark transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
                    </div>
                    <p className="mt-2 line-clamp-2 text-[0.65rem] leading-5 text-secondary">{source.snippet}</p>
                    <p className="mt-2 text-[0.56rem] font-semibold uppercase tracking-[0.1em] text-teal">{source.providerKey} · {source.url}</p>
                  </a>
                ))}
              </div>
            )}
          </Panel>
        </div>
      )}

      {tab === "strategy" && (
        <div className="grid gap-5 lg:grid-cols-[0.82fr_1.18fr]">
          <Panel className="bg-forest p-6 text-white">
            <FileSearch className="h-5 w-5 text-sage" strokeWidth={1.4} aria-hidden="true" />
            <h2 className="mt-5 font-display text-3xl leading-tight">Evidence-bounded strategy</h2>
            <p className="mt-4 text-xs leading-6 text-white/65">
              The prompt includes only user-provided brand rules, extracted website text, and stored research sources. It forbids invented statistics, claims, competitors, and trends. Output must be valid structured JSON and is saved as a draft for human review.
            </p>
            <ul className="mt-6 space-y-3 border-t border-white/10 pt-5 text-[0.68rem] leading-5 text-white/70">
              <li>Primary and backup provider fallback with preserved work</li>
              <li>Automatic review flags for claims and restricted topics</li>
              <li>Paused tasks remain resumable from the AI Engine</li>
              <li>No publishing occurs in Phase 3</li>
            </ul>
            <Button type="button" variant="light" onClick={() => void generate()} disabled={busy || !businessId} className="mt-7">
              <Sparkles className="h-4 w-4" aria-hidden="true" />
              {busy ? "Running agent task…" : "Generate strategy draft"}
            </Button>
          </Panel>
          <Panel className="p-6">
            <h3 className="font-display text-2xl text-ink">Strategy drafts</h3>
            {strategies.length === 0 ? (
              <p className="mt-4 text-xs leading-6 text-secondary">No strategy has been generated. Nothing is pre-filled or simulated.</p>
            ) : (
              <div className="mt-4 space-y-4">
                {strategies.map((strategy) => (
                  <article key={strategy.id} className="rounded-xl border border-line bg-pale/40 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="text-xs font-semibold text-ink">Version {strategy.version}</p>
                      <div className="flex gap-2">
                        {strategy.providerKey && <Badge tone="neutral">{strategy.providerKey}</Badge>}
                        <Badge tone={strategy.status === "needs_review" ? "amber" : "sage"}>{strategy.status}</Badge>
                      </div>
                    </div>
                    {strategy.rationale && <p className="mt-3 text-[0.68rem] leading-6 text-secondary">{strategy.rationale}</p>}
                    <details className="mt-3">
                      <summary className="cursor-pointer text-[0.62rem] font-semibold text-teal">Inspect structured output</summary>
                      <pre className="mt-2 max-h-60 overflow-auto rounded-lg bg-white p-3 text-[0.6rem] leading-5 text-secondary">{json({ pillars: strategy.pillars, formats: strategy.formats, cadence: strategy.cadence })}</pre>
                    </details>
                    {strategy.reviewFlags && strategy.reviewFlags.length > 0 && (
                      <div className="mt-3 rounded-lg border border-[#dfcfb6] bg-[#f7f2e8] p-3 text-[0.62rem] leading-5 text-[#735c32]">
                        <p className="font-bold uppercase tracking-[0.1em]">Human review required</p>
                        <ul className="mt-1 list-inside list-disc">{strategy.reviewFlags.map((flag) => <li key={flag}>{flag}</li>)}</ul>
                      </div>
                    )}
                    {strategy.sources && strategy.sources.length > 0 && (
                      <p className="mt-3 text-[0.58rem] text-secondary">{strategy.sources.length} stored source URLs referenced</p>
                    )}
                  </article>
                ))}
              </div>
            )}
          </Panel>
        </div>
      )}
    </div>
  );
}
