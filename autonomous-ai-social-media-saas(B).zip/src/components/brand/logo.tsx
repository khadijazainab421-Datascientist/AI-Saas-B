import Link from "next/link";
import { cn } from "@/lib/utils";

type LogoProps = {
  href?: string;
  compact?: boolean;
  inverse?: boolean;
  className?: string;
};

export function Logo({ href = "/", compact = false, inverse = false, className }: LogoProps) {
  return (
    <Link
      href={href}
      aria-label="Serein home"
      className={cn("group inline-flex items-center gap-3", className)}
    >
      <svg
        aria-hidden="true"
        viewBox="0 0 40 40"
        className="h-9 w-9 shrink-0 overflow-visible"
        fill="none"
      >
        <circle
          cx="20"
          cy="20"
          r="18.5"
          className={cn(
            "transition-transform duration-500 group-hover:rotate-45",
            inverse ? "stroke-white/40" : "stroke-forest/20",
          )}
          strokeWidth="1"
        />
        <path
          d="M12 25.5c5.6-.2 9.7-3.1 12.2-8.8 1.1-2.5 2.1-4 4.2-4.7"
          className={inverse ? "stroke-white" : "stroke-forest"}
          strokeWidth="1.7"
          strokeLinecap="round"
        />
        <path
          d="M11.5 16.5c3.9.1 6.5 1.8 7.9 5.2.8 2 2.1 3.3 4.2 3.8 2.3.5 4-.3 5-2.4"
          className={inverse ? "stroke-mint" : "stroke-sage-dark"}
          strokeWidth="1.7"
          strokeLinecap="round"
        />
        <circle cx="12" cy="25.5" r="1.8" className={inverse ? "fill-white" : "fill-forest"} />
        <circle cx="28.4" cy="12" r="1.8" className={inverse ? "fill-mint" : "fill-sage-dark"} />
      </svg>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span
            className={cn(
              "font-display text-[1.55rem] tracking-[-0.02em]",
              inverse ? "text-white" : "text-ink",
            )}
          >
            Serein
          </span>
          <span
            className={cn(
              "mt-1 text-[0.52rem] font-semibold uppercase tracking-[0.24em]",
              inverse ? "text-white/55" : "text-secondary",
            )}
          >
            Social intelligence
          </span>
        </span>
      )}
    </Link>
  );
}
