"use client";

import { useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";

const questions = [
  {
    question: "Is Serein another caption generator?",
    answer:
      "No. The product architecture connects business understanding, research, strategy, content operations, publishing controls, and learning. Caption generation is one step in that system—not the whole product.",
  },
  {
    question: "Can the agent publish without asking me?",
    answer:
      "Only when the autonomous agent phase is implemented and you explicitly allow eligible routine content to publish. Review-required categories, sensitive topics, unsupported claims, publishing limits, and a global pause remain part of the control model.",
  },
  {
    question: "Which social platforms are planned?",
    answer:
      "Instagram, Facebook, and LinkedIn are the initial platforms. Each will use official OAuth and supported publishing APIs. Account eligibility, permissions, app review, and verified publishing tests are required before an integration can be called operational.",
  },
  {
    question: "What happens if an AI provider reaches its free quota?",
    answer:
      "The planned provider layer tries eligible configured backups, preserves completed work, and pauses the task if no eligible provider is available. It must not silently discard work or switch to a paid provider without your authorization.",
  },
  {
    question: "Does this preview contain live customer analytics?",
    answer:
      "No. Phase 3 includes authentication, tenant-isolated brand profiles, website analysis, sourced research, and an AI fallback engine using configured server-side providers. Real provider outcomes and usage appear in the AI Engine. Social analytics remain empty until supported platform insights are ingested in Phase 7.",
  },
  {
    question: "How will my business data be separated from other customers?",
    answer:
      "Workspace-scoped data models, authenticated membership checks, server-side authorization, and tenant-isolation tests are specified for Phases 2 and 8. Those controls are not represented as active in this UI-only phase.",
  },
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const reduceMotion = useReducedMotion();

  return (
    <div className="divide-y divide-line border-y border-line">
      {questions.map((item, index) => {
        const isOpen = openIndex === index;
        return (
          <div key={item.question}>
            <button
              type="button"
              className="flex w-full items-center justify-between gap-6 py-6 text-left focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-teal"
              aria-expanded={isOpen}
              aria-controls={`faq-answer-${index}`}
              onClick={() => setOpenIndex(isOpen ? null : index)}
            >
              <span className="flex items-baseline gap-5">
                <span className="hidden text-[0.58rem] font-bold tracking-[0.14em] text-sage-dark sm:inline">
                  0{index + 1}
                </span>
                <span className="font-display text-xl leading-snug text-ink sm:text-2xl">{item.question}</span>
              </span>
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-line bg-white text-forest">
                <Plus
                  className={cn("h-4 w-4 transition-transform duration-300", isOpen && "rotate-45")}
                  strokeWidth={1.5}
                  aria-hidden="true"
                />
              </span>
            </button>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  id={`faq-answer-${index}`}
                  initial={reduceMotion ? false : { height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={reduceMotion ? undefined : { height: 0, opacity: 0 }}
                  transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                  className="overflow-hidden"
                >
                  <p className="max-w-3xl pb-7 text-sm leading-7 text-secondary sm:ml-11">{item.answer}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}
