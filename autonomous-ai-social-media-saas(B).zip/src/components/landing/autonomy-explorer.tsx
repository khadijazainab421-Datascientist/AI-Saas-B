"use client";

import { useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { Check, Eye, Pause, ShieldCheck, SlidersHorizontal, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const modes = [
  {
    id: "review",
    label: "Review everything",
    title: "A diligent creative partner.",
    description:
      "The agent can research and prepare drafts. Every individual post waits for your explicit approval before it can enter the publishing queue.",
    rules: ["Research and draft", "Schedule after approval", "Publish after approval"],
    note: "Best for finding your rhythm and refining a new brand voice.",
  },
  {
    id: "categories",
    label: "Approve by category",
    title: "Trust, with thoughtful boundaries.",
    description:
      "Choose which content categories always need review. Evergreen education might be pre-approved while offers, claims, and sensitive topics stay locked behind approval.",
    rules: ["Routine categories can proceed", "Selected categories need review", "Sensitive topics always reviewed"],
    note: "Best for teams with established content pillars and review policies.",
  },
  {
    id: "autopilot",
    label: "Routine autopilot",
    title: "Consistency without complacency.",
    description:
      "Eligible routine content can move from planning to publishing within your schedule and limits. Claims, sensitive subjects, and policy exceptions still require a person.",
    rules: ["Routine posts can auto-publish", "Weekly limits apply", "Exceptions return to review"],
    note: "Best for mature strategies backed by verified performance data.",
  },
  {
    id: "paused",
    label: "Pause the agent",
    title: "Everything stops. Nothing disappears.",
    description:
      "Autonomous activity and eligible publishing jobs pause together. Drafts, approvals, research, and logs remain intact so work can resume without silent loss or duplication.",
    rules: ["Autonomous activity paused", "Existing work preserved", "Resume only when you choose"],
    note: "A deliberate pause is always available and never discards work.",
  },
];

export function AutonomyExplorer() {
  const [selected, setSelected] = useState(0);
  const [cap, setCap] = useState(7);
  const reduceMotion = useReducedMotion();
  const mode = modes[selected];

  return (
    <div className="grid overflow-hidden rounded-[2rem] border border-line bg-white lg:grid-cols-[0.82fr_1.18fr]">
      <div className="border-b border-line bg-pale/70 p-5 sm:p-8 lg:border-b-0 lg:border-r">
        <div className="flex items-center gap-2 text-[0.62rem] font-bold uppercase tracking-[0.15em] text-teal">
          <SlidersHorizontal className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
          Explore the control model
        </div>
        <div className="mt-7 space-y-2" role="group" aria-label="Autonomy modes">
          {modes.map((item, index) => (
            <button
              key={item.id}
              type="button"
              aria-pressed={selected === index}
              onClick={() => setSelected(index)}
              className={cn(
                "flex w-full items-center justify-between rounded-xl border px-4 py-3.5 text-left text-xs font-semibold transition-all duration-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal",
                selected === index
                  ? "border-teal/20 bg-white text-forest shadow-[0_5px_20px_rgba(22,78,74,0.05)]"
                  : "border-transparent text-secondary hover:border-line hover:bg-white/55 hover:text-ink",
              )}
            >
              <span className="flex items-center gap-3">
                {item.id === "paused" ? (
                  <Pause className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
                ) : item.id === "review" ? (
                  <Eye className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
                ) : (
                  <Sparkles className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
                )}
                {item.label}
              </span>
              <span
                className={cn(
                  "h-2 w-2 rounded-full border transition-colors",
                  selected === index ? "border-teal bg-teal" : "border-sage/60 bg-transparent",
                )}
                aria-hidden="true"
              />
            </button>
          ))}
        </div>
        <p className="mt-6 text-[0.65rem] leading-5 text-secondary">
          Interactive product model only. This preview does not connect accounts or publish content.
        </p>
      </div>

      <div className="flex min-h-[31rem] flex-col p-6 sm:p-10">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={mode.id}
            initial={reduceMotion ? false : { opacity: 0, y: 16, filter: "blur(5px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            exit={reduceMotion ? undefined : { opacity: 0, y: -10, filter: "blur(4px)" }}
            transition={{ duration: 0.35 }}
          >
            <span className="grid h-11 w-11 place-items-center rounded-full bg-mint/65 text-forest">
              <ShieldCheck className="h-5 w-5" strokeWidth={1.5} aria-hidden="true" />
            </span>
            <h3 className="mt-6 font-display text-3xl leading-tight tracking-[-0.02em] text-ink sm:text-4xl">
              {mode.title}
            </h3>
            <p className="mt-4 max-w-xl text-sm leading-7 text-secondary">{mode.description}</p>
            <ul className="mt-6 grid gap-3 sm:grid-cols-3">
              {mode.rules.map((rule) => (
                <li key={rule} className="rounded-xl border border-line bg-soft-white p-3.5 text-[0.68rem] font-semibold leading-5 text-forest">
                  <Check className="mb-2 h-3.5 w-3.5 text-sage-dark" strokeWidth={1.8} aria-hidden="true" />
                  {rule}
                </li>
              ))}
            </ul>
            <p className="mt-5 border-l-2 border-sage/50 pl-4 text-xs italic leading-6 text-secondary">{mode.note}</p>
          </motion.div>
        </AnimatePresence>

        <div className="mt-auto border-t border-line pt-6">
          <div className="flex items-end justify-between gap-4">
            <label htmlFor="weekly-cap" className="text-[0.67rem] font-bold uppercase tracking-[0.12em] text-ink">
              Preview a weekly publishing cap
            </label>
            <output htmlFor="weekly-cap" className="font-display text-2xl text-teal">
              {cap === 0 ? "Off" : cap}
            </output>
          </div>
          <input
            id="weekly-cap"
            type="range"
            min="0"
            max="21"
            step="1"
            value={cap}
            onChange={(event) => setCap(Number(event.target.value))}
            className="mt-4 h-1.5 w-full accent-teal"
          />
          <p className="mt-3 text-[0.66rem] text-secondary" aria-live="polite">
            {cap === 0
              ? "No autonomous posts would be permitted."
              : `At most ${cap} eligible routine ${cap === 1 ? "post" : "posts"} per week; approvals and safety exceptions still apply.`}
          </p>
        </div>
      </div>
    </div>
  );
}
