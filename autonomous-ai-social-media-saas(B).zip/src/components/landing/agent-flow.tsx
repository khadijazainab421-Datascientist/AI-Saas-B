"use client";

import { useEffect, useRef, useState } from "react";
import {
  motion,
  useReducedMotion,
  useScroll,
  useTransform,
  type MotionValue,
} from "motion/react";
import {
  BarChart3,
  CalendarCheck,
  FileText,
  Lightbulb,
  Search,
  ShieldCheck,
  type LucideIcon,
} from "lucide-react";

const steps: Array<{
  title: string;
  caption: string;
  icon: LucideIcon;
}> = [
  { title: "Understand", caption: "Business, audience, voice", icon: Search },
  { title: "Research", caption: "Trends, topics, moments", icon: Lightbulb },
  { title: "Create", caption: "Ideas, captions, carousels", icon: FileText },
  { title: "Publish", caption: "Approved, scheduled, logged", icon: CalendarCheck },
  { title: "Learn", caption: "Verified signals, next actions", icon: BarChart3 },
];

const origins = [
  [-400, -120, -7],
  [360, -155, 6],
  [-430, 155, 5],
  [400, 140, -6],
  [0, -245, 3],
];

function FlowCard({
  step,
  index,
  progress,
  compact,
  reduceMotion,
}: {
  step: (typeof steps)[number];
  index: number;
  progress: MotionValue<number>;
  compact: boolean;
  reduceMotion: boolean | null;
}) {
  const origin = origins[index];
  const spread = compact ? 142 : 190;
  const x = useTransform(
    progress,
    [0, 0.42, 0.58, 1],
    [origin[0] * (compact ? 0.72 : 1), origin[0] * 0.07, origin[0] * 0.07, (index - 2) * spread],
  );
  const y = useTransform(
    progress,
    [0, 0.42, 0.58, 1],
    [origin[1], index * 5 - 10, index * 5 - 10, 142],
  );
  const rotate = useTransform(progress, [0, 0.48, 1], [origin[2], 0, 0]);
  const scale = useTransform(progress, [0, 0.46, 0.62, 1], [1, 0.78, 0.84, 1]);
  const opacity = useTransform(progress, [0, 0.43, 0.56, 0.67, 1], [1, 0.38, 0.38, 1, 1]);
  const Icon = step.icon;

  return (
    <motion.article
      style={reduceMotion ? { x: (index - 2) * spread, y: 142 } : { x, y, rotate, scale, opacity }}
      className="absolute left-1/2 top-1/2 z-10 w-[10.5rem] -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-white/80 bg-white/88 p-4 shadow-[0_12px_45px_rgba(22,78,74,0.08)] backdrop-blur-lg"
    >
      <div className="flex items-center justify-between">
        <span className="grid h-8 w-8 place-items-center rounded-full bg-mint/70 text-forest">
          <Icon className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
        </span>
        <span className="text-[0.56rem] font-bold tracking-[0.14em] text-sage-dark">0{index + 1}</span>
      </div>
      <h3 className="mt-4 font-display text-xl text-ink">{step.title}</h3>
      <p className="mt-1 text-[0.61rem] leading-5 text-secondary">{step.caption}</p>
    </motion.article>
  );
}

export function AgentFlow() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const reduceMotion = useReducedMotion();
  const [compact, setCompact] = useState(false);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end end"],
  });
  const hubScale = useTransform(scrollYProgress, [0, 0.42, 0.62, 1], [0.8, 1.25, 1.05, 0.88]);
  const hubY = useTransform(scrollYProgress, [0, 0.58, 1], [0, 0, -105]);
  const orbitRotate = useTransform(scrollYProgress, [0, 1], [0, 160]);
  const finalMessageOpacity = useTransform(scrollYProgress, [0.68, 0.86], [0, 1]);

  useEffect(() => {
    const update = () => setCompact(window.innerWidth < 1180);
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  return (
    <section id="agent" className="relative bg-forest text-white" aria-labelledby="agent-title">
      <div ref={sectionRef} className="relative hidden h-[280vh] md:block">
        <div className="sticky top-0 h-screen overflow-hidden">
          <div className="fine-grid absolute inset-0 opacity-20" aria-hidden="true" />
          <div className="absolute left-1/2 top-[12%] w-full max-w-3xl -translate-x-1/2 px-8 text-center">
            <p className="eyebrow justify-center text-mint before:bg-sage">One connected intelligence</p>
            <h2 id="agent-title" className="mt-5 font-display text-5xl leading-[1.03] tracking-[-0.035em] lg:text-6xl">
              Five disciplines. <span className="italic text-sage">One clear direction.</span>
            </h2>
          </div>

          <div className="absolute inset-x-0 bottom-[7%] top-[29%]">
            <motion.div
              style={reduceMotion ? undefined : { rotate: orbitRotate }}
              className="absolute left-1/2 top-1/2 h-[28rem] w-[28rem] -translate-x-1/2 -translate-y-1/2 rounded-full border border-sage/20"
              aria-hidden="true"
            >
                <span className="absolute left-1/2 top-0 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-sage/60 bg-forest" />
                <span className="absolute bottom-8 right-8 h-1.5 w-1.5 rounded-full bg-sage/50" />
            </motion.div>

            <motion.div
              style={reduceMotion ? { y: -105 } : { scale: hubScale, y: hubY }}
              className="absolute left-1/2 top-1/2 z-20 grid h-36 w-36 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-sage/35 bg-[#1b5651] text-center shadow-[0_0_0_18px_rgba(167,189,177,0.04)]"
            >
              <div>
                <ShieldCheck className="mx-auto h-5 w-5 text-mint" strokeWidth={1.4} aria-hidden="true" />
                <p className="mt-2 font-display text-2xl">Serein</p>
                <p className="mt-1 text-[0.52rem] font-semibold uppercase tracking-[0.17em] text-sage">
                  Your agent
                </p>
              </div>
            </motion.div>

            {steps.map((step, index) => (
              <FlowCard
                key={step.title}
                step={step}
                index={index}
                progress={scrollYProgress}
                compact={compact}
                reduceMotion={reduceMotion}
              />
            ))}
          </div>

          <motion.p
            style={reduceMotion ? undefined : { opacity: finalMessageOpacity }}
            className="absolute inset-x-0 bottom-[3%] text-center text-[0.64rem] font-semibold uppercase tracking-[0.17em] text-sage"
          >
            Connected by context · Governed by your rules
          </motion.p>
        </div>
      </div>

      <div className="px-5 py-24 md:hidden">
        <p className="eyebrow text-mint before:bg-sage">One connected intelligence</p>
        <h2 className="mt-5 font-display text-5xl leading-[1.02] tracking-[-0.035em]">
          Five disciplines. <span className="italic text-sage">One direction.</span>
        </h2>
        <div className="relative mt-12 space-y-3 before:absolute before:bottom-8 before:left-[1.45rem] before:top-8 before:w-px before:bg-sage/25">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <article key={step.title} className="relative flex gap-5 rounded-2xl border border-white/10 bg-white/[0.045] p-5">
                <span className="z-10 grid h-12 w-12 shrink-0 place-items-center rounded-full border border-sage/25 bg-forest text-mint">
                  <Icon className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
                </span>
                <div>
                  <p className="text-[0.55rem] font-bold tracking-[0.15em] text-sage">STEP 0{index + 1}</p>
                  <h3 className="mt-1 font-display text-2xl">{step.title}</h3>
                  <p className="mt-1 text-xs leading-5 text-white/60">{step.caption}</p>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
