"use client";

import { useRef } from "react";
import Image from "next/image";
import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";
import { ArrowDown, ArrowUpRight, Check, Sparkles } from "lucide-react";
import { ButtonLink } from "@/components/ui/button";

const disciplines = ["Research", "Strategy", "Creation", "Publishing", "Learning"];

export function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const reduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"],
  });
  const imageY = useTransform(scrollYProgress, [0, 1], [0, 150]);
  const imageScale = useTransform(scrollYProgress, [0, 1], [1, 1.14]);
  const copyY = useTransform(scrollYProgress, [0, 1], [0, -90]);
  const copyOpacity = useTransform(scrollYProgress, [0, 0.82], [1, 0]);
  const archRadius = useTransform(scrollYProgress, [0, 1], [180, 32]);
  const borderRadius = useTransform(archRadius, (value) => `${value}px ${value}px 28px 28px`);

  const lineTransition = (delay: number) => ({
    duration: 1.05,
    delay,
    ease: [0.22, 1, 0.36, 1] as const,
  });

  return (
    <section
      ref={sectionRef}
      className="fine-grid relative min-h-[100svh] overflow-hidden border-b border-line bg-pale/55 pt-[var(--header-height)]"
      aria-labelledby="hero-heading"
    >
      <div
        className="pointer-events-none absolute -left-40 top-16 h-[36rem] w-[36rem] rounded-full bg-mint/50 blur-[110px]"
        aria-hidden="true"
      />
      <div
        className="ambient-ring pointer-events-none absolute right-[5%] top-[11%] h-[36rem] w-[36rem] rounded-full border border-sage/25"
        aria-hidden="true"
      />

      <div className="relative mx-auto grid min-h-[calc(100svh-var(--header-height))] max-w-[1440px] grid-cols-1 items-center gap-10 px-5 pb-28 pt-12 sm:px-8 lg:grid-cols-12 lg:px-12 lg:pb-24 lg:pt-6">
        <motion.div
          style={reduceMotion ? undefined : { y: copyY, opacity: copyOpacity }}
          className="relative z-20 lg:col-span-7 lg:pr-4"
        >
          <motion.div
            initial={reduceMotion ? false : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mb-7 flex items-center gap-3"
          >
            <span className="grid h-7 w-7 place-items-center rounded-full border border-sage/40 bg-white/60 text-forest">
              <Sparkles className="h-3.5 w-3.5" strokeWidth={1.5} aria-hidden="true" />
            </span>
            <p className="text-[0.62rem] font-bold uppercase tracking-[0.18em] text-teal">
              Autonomous social, under your direction
            </p>
          </motion.div>

          <h1
            id="hero-heading"
            className="font-display text-[clamp(3.6rem,7.2vw,7.6rem)] leading-[0.87] tracking-[-0.052em] text-ink"
          >
            {["Social media", "with a mind", "for your brand."].map((line, index) => (
              <span key={line} className="-mb-[0.08em] block overflow-hidden pb-[0.08em]">
                <motion.span
                  className={index === 1 ? "block italic text-teal" : "block"}
                  initial={reduceMotion ? false : { y: "110%", rotate: 2 }}
                  animate={{ y: "0%", rotate: 0 }}
                  transition={lineTransition(0.2 + index * 0.11)}
                >
                  {line}
                </motion.span>
              </span>
            ))}
          </h1>

          <motion.p
            initial={reduceMotion ? false : { opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.68 }}
            className="mt-7 max-w-[31rem] text-[0.94rem] leading-7 text-secondary sm:text-base"
          >
            Meet the AI agent that learns your business, finds what matters, and turns it into
            thoughtful social content—without letting go of your standards.
          </motion.p>

          <motion.div
            initial={reduceMotion ? false : { opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center"
          >
            <ButtonLink href="/dashboard" className="sm:min-w-48" arrow>
              Explore the workspace
            </ButtonLink>
            <ButtonLink href="#agent" variant="ghost" className="sm:min-w-44">
              Meet the agent
              <ArrowDown className="h-4 w-4" aria-hidden="true" />
            </ButtonLink>
          </motion.div>
        </motion.div>

        <motion.div
          initial={reduceMotion ? false : { opacity: 0, scale: 0.94, x: 45 }}
          animate={{ opacity: 1, scale: 1, x: 0 }}
          transition={{ duration: 1.25, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto h-[31rem] w-full max-w-[30rem] sm:h-[38rem] lg:col-span-5 lg:h-[min(73vh,47rem)] lg:max-w-none"
        >
          <motion.div
            style={reduceMotion ? undefined : { borderRadius }}
            className="absolute inset-0 overflow-hidden rounded-[11rem_11rem_1.75rem_1.75rem] border border-white/70 bg-mint shadow-[0_24px_80px_rgba(22,78,74,0.09)]"
          >
            <motion.div
              className="absolute -inset-[8%]"
              style={reduceMotion ? undefined : { y: imageY, scale: imageScale }}
            >
              <Image
                src="/images/serein-hero.jpg"
                alt="Editorial portrait representing thoughtful creative direction"
                fill
                priority
                sizes="(max-width: 1024px) 90vw, 40vw"
                className="object-cover object-center"
              />
            </motion.div>
            <div
              className="absolute inset-0 bg-[linear-gradient(180deg,transparent_55%,rgba(22,78,74,0.2))]"
              aria-hidden="true"
            />
          </motion.div>

          <motion.div
            initial={reduceMotion ? false : { opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1 }}
            className="glass-panel ambient-drift absolute -left-3 bottom-8 w-[15.5rem] rounded-2xl p-4 sm:-left-10 sm:bottom-12"
          >
            <div className="flex items-center justify-between">
              <p className="text-[0.6rem] font-bold uppercase tracking-[0.15em] text-secondary">
                Agent state
              </p>
              <span className="flex items-center gap-1.5 text-[0.62rem] font-semibold text-forest">
                <span className="h-1.5 w-1.5 rounded-full bg-sage-dark" aria-hidden="true" />
                Standing by
              </span>
            </div>
            <p className="mt-4 font-display text-[1.4rem] leading-tight text-ink">
              Your voice. Your rules.
            </p>
            <div className="mt-3 flex items-center gap-2 border-t border-forest/10 pt-3 text-[0.68rem] text-secondary">
              <Check className="h-3.5 w-3.5 text-teal" aria-hidden="true" />
              Approval required before publishing
            </div>
          </motion.div>

          <motion.div
            initial={reduceMotion ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 0.8 }}
            className="absolute -right-2 top-10 hidden items-center gap-2 rounded-full border border-white/70 bg-white/65 px-3 py-2 text-[0.58rem] font-semibold uppercase tracking-[0.13em] text-forest backdrop-blur-md sm:flex lg:-right-5"
          >
            Human-directed AI
            <ArrowUpRight className="h-3 w-3" aria-hidden="true" />
          </motion.div>
        </motion.div>
      </div>

      <motion.div
        initial={reduceMotion ? false : { opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.05, duration: 0.8 }}
        className="absolute inset-x-0 bottom-0 z-30 border-t border-line/90 bg-soft-white/72 backdrop-blur-lg"
      >
        <div className="no-scrollbar mx-auto flex max-w-[1440px] items-center overflow-x-auto px-5 sm:px-8 lg:px-12">
          {disciplines.map((item, index) => (
            <div
              key={item}
              className="flex min-w-max flex-1 items-center gap-3 py-4 pr-6 text-[0.61rem] font-bold uppercase tracking-[0.15em] text-secondary"
            >
              <span className="text-sage-dark">0{index + 1}</span>
              {item}
              {index < disciplines.length - 1 && (
                <span className="ml-auto hidden h-px w-8 bg-sage/40 sm:block" aria-hidden="true" />
              )}
            </div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}
