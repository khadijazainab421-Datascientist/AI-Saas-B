"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { Logo } from "@/components/brand/logo";
import { ButtonLink } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navigation = [
  { label: "Product", href: "#product" },
  { label: "The agent", href: "#agent" },
  { label: "Autonomy", href: "#autonomy" },
  { label: "Platforms", href: "#platforms" },
  { label: "Plans", href: "#plans" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [open]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled ? "border-b border-line/80 bg-soft-white/88 backdrop-blur-xl" : "bg-transparent",
      )}
    >
      <div className="mx-auto flex h-[var(--header-height)] max-w-[1440px] items-center justify-between px-5 sm:px-8 lg:px-12">
        <Logo />
        <nav className="hidden items-center gap-7 lg:flex" aria-label="Main navigation">
          {navigation.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-[0.7rem] font-semibold text-secondary transition-colors duration-300 hover:text-forest"
            >
              {item.label}
            </a>
          ))}
        </nav>
        <div className="hidden lg:block">
          <ButtonLink href="/dashboard" variant="secondary" className="min-h-10 px-4 py-2" arrow>
            Open product preview
          </ButtonLink>
        </div>
        <button
          type="button"
          className="grid h-11 w-11 place-items-center rounded-full border border-line bg-white/70 text-forest lg:hidden"
          aria-label={open ? "Close navigation" : "Open navigation"}
          aria-expanded={open}
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="h-[calc(100svh-var(--header-height))] border-t border-line bg-soft-white px-6 py-8 lg:hidden"
          >
            <nav className="flex flex-col" aria-label="Mobile navigation">
              {navigation.map((item, index) => (
                <motion.a
                  key={item.href}
                  href={item.href}
                  initial={{ opacity: 0, x: -18 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.055 }}
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-between border-b border-line py-5 font-display text-3xl text-ink"
                >
                  {item.label}
                  <span className="font-sans text-[0.62rem] tracking-[0.16em] text-sage-dark">
                    0{index + 1}
                  </span>
                </motion.a>
              ))}
            </nav>
            <ButtonLink href="/dashboard" className="mt-8 w-full" arrow>
              Open product preview
              <ArrowUpRight className="hidden" aria-hidden="true" />
            </ButtonLink>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
