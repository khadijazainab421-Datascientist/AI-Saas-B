"use client";

import { useCallback, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { formatInTimeZone } from "date-fns-tz";
import { Archive, ArrowDown, ArrowUp, Check, Clock3, Download, History, Layers3, Palette, PenTool, Plus, RefreshCw, Save, ShieldCheck, Sparkles, Trash2 } from "lucide-react";
import { Panel } from "@/components/ui/panel";
import { PageHeader } from "@/components/ui/page-header";
import { Button, ButtonLink } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/empty-state";
import { DashboardSkeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { studioApi, downloadStudioFile } from "@/lib/studio/client";
import { emptyDraft, DEFAULT_STYLE, type StudioBootstrap, type PostDTO, type DraftInput, type RevisionDTO, type Platform, type BrandStyle, type ContentFormat } from "@/lib/studio/types";
import { ChannelPreview } from "./channel-preview";
import { MediaLibrary } from "./media-library";

type Tab = "write" | "carousel" | "media" | "brand" | "history";
const tabs: Array<{ id: Tab; label: string }> = [{ id: "write", label: "Write" }, { id: "carousel", label: "Carousel" }, { id: "media", label: "Media" }, { id: "brand", label: "Brand kit" }, { id: "history", label: "History" }];
const zones = ["UTC", "Asia/Karachi", "Asia/Dubai", "Europe/London", "Europe/Paris", "America/New_York", "America/Los_Angeles", "Australia/Sydney"];
const inputClass = "w-full rounded-xl border border-line bg-white px-3 py-2.5 text-xs leading-6 text-ink outline-none transition-colors focus:border-teal focus:ring-2 focus:ring-mint/60 disabled:bg-pale/60";

export function ContentStudio() {
  const query = useSearchParams();
  const [data, setData] = useState<StudioBootstrap | null>(null);
  const [businessId, setBusinessId] = useState<number | undefined>();
  const [post, setPost] = useState<PostDTO | null>(null);
  const [draft, setDraft] = useState<DraftInput>(emptyDraft());
  const [revisions, setRevisions] = useState<RevisionDTO[]>([]);
  const [style, setStyle] = useState<BrandStyle>({ ...DEFAULT_STYLE });
  const [dirty, setDirty] = useState(false); const [styleDirty, setStyleDirty] = useState(false);
  const [hashText, setHashText] = useState(""); const [tab, setTab] = useState<Tab>("write");
  const [captionMode, setCaptionMode] = useState<"base" | Platform>("base");
  const [busy, setBusy] = useState(""); const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState<{ error: boolean; text: string } | null>(null);
  const [search, setSearch] = useState(""); const [showArchived, setShowArchived] = useState(false);
  const [acknowledged, setAcknowledged] = useState(false);
  const [zone, setZone] = useState("UTC"); const [wallTime, setWallTime] = useState("");

  const acceptPost = useCallback((value: PostDTO) => {
    setPost(value); setDraft(value.document); setHashText(value.document.hashtags.join(", ")); setDirty(false); setAcknowledged(false);
  }, []);
  const refreshLists = useCallback(async (id: number) => {
    const result = await studioApi<StudioBootstrap>(`/api/studio?businessId=${id}`); setData(result); return result;
  }, []);
  const choosePost = useCallback(async (id: number) => {
    const detail = await studioApi<{ post: PostDTO; revisions: RevisionDTO[] }>(`/api/studio/posts/${id}`);
    acceptPost(detail.post); setRevisions(detail.revisions);
  }, [acceptPost]);
  const loadBusiness = useCallback(async (id?: number, selectedPost?: number) => {
    setLoading(true);
    try {
      const result = await studioApi<StudioBootstrap>(`/api/studio${id ? `?businessId=${id}` : ""}`);
      setData(result); setStyle(result.style); setStyleDirty(false);
      const chosenBusiness = id ?? result.businesses[0]?.id; setBusinessId(chosenBusiness);
      const selected = selectedPost ?? result.posts.find((item) => item.status !== "archived")?.id;
      if (selected) await choosePost(selected); else { setPost(null); setDraft(emptyDraft()); setRevisions([]); setHashText(""); setDirty(false); }
    } catch (error) { setNotice({ error: true, text: error instanceof Error ? error.message : "Could not load studio." }); }
    finally { setLoading(false); }
  }, [choosePost]);

  useEffect(() => {
    const localZone = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC"; setZone(localZone);
    setWallTime(formatInTimeZone(new Date(Date.now() + 86400000), localZone, "yyyy-MM-dd'T'HH:mm"));
    void (async () => {
      const requested = Number(query.get("post"));
      if (Number.isSafeInteger(requested) && requested > 0) {
        try { const detail = await studioApi<{ post: PostDTO }>(`/api/studio/posts/${requested}`); await loadBusiness(detail.post.businessId, requested); }
        catch (error) { setNotice({ error: true, text: error instanceof Error ? error.message : "Draft not available." }); setLoading(false); }
      } else await loadBusiness();
    })();
  }, [loadBusiness, query]);
  useEffect(() => {
    const guard = (event: BeforeUnloadEvent) => { if (dirty || styleDirty) { event.preventDefault(); event.returnValue = ""; } };
    window.addEventListener("beforeunload", guard); return () => window.removeEventListener("beforeunload", guard);
  }, [dirty, styleDirty]);

  async function perform(key: string, operation: () => Promise<void>) {
    setBusy(key); setNotice(null);
    try { await operation(); } catch (error) { setNotice({ error: true, text: error instanceof Error ? error.message : "This operation did not complete." }); }
    finally { setBusy(""); }
  }
  function patch(values: Partial<DraftInput>) { setDraft((current) => ({ ...current, ...values })); setDirty(true); }
  function canLeave() { return !(dirty || styleDirty) || window.confirm("Discard unsaved editor/brand-kit changes and open another record?"); }
  async function newDraft(format: ContentFormat = "post", title?: string, brief?: string) {
    if (!businessId || !canLeave()) return;
    await perform("new", async () => {
      const document = { ...emptyDraft(format), ...(title ? { title } : {}), ...(brief ? { brief } : {}) };
      const result = await studioApi<{ post: PostDTO }>("/api/studio", { method: "POST", body: JSON.stringify({ businessId, document }) });
      acceptPost(result.post); setRevisions([]); setTab("write"); await refreshLists(businessId); setNotice({ error: false, text: "A new draft was saved. Nothing has been generated or published." });
    });
  }
  async function mutate(action: string, extra: Record<string, unknown> = {}) {
    if (!post || !businessId) return;
    await perform(action, async () => {
      const result = await studioApi<{ post: PostDTO; notice?: string }>(`/api/studio/posts/${post.id}`, { method: "PATCH", body: JSON.stringify({ action, version: post.version, ...extra }) });
      acceptPost(result.post); await refreshLists(businessId); await choosePost(result.post.id);
      setNotice({ error: false, text: result.notice || (action === "save" ? `Draft saved as version ${result.post.version}. Prior approvals/schedules were cleared for this edit.` : action === "approve" ? "This version was approved by a human for planning. It has not been published." : `Draft action recorded: ${action.replaceAll("_", " ")}.`) });
    });
  }
  async function generate(kind: string) {
    if (!businessId || (kind !== "studio_ideas" && (!post || dirty))) return;
    await perform(kind, async () => {
      const result = await studioApi<{ status: string; taskId: number; generationId?: number; reason?: string; providerKey?: string }>("/api/studio/generate", { method: "POST", body: JSON.stringify({ businessId, postId: post?.id, kind, brief: draft.brief }) });
      await refreshLists(businessId);
      setNotice({ error: result.status !== "completed", text: result.status === "completed" ? `Suggestion #${result.generationId} saved from ${result.providerKey}. Inspect it, then explicitly apply it to the draft. No editor text was overwritten.` : `Task #${result.taskId} is ${result.status}: ${result.reason || "provider unavailable"}. Work is retained in AI Engine; no generated result is claimed.` });
    });
  }
  async function saveStyle() {
    if (!businessId) return;
    await perform("style", async () => {
      const result = await studioApi<{ style: BrandStyle }>("/api/studio", { method: "POST", body: JSON.stringify({ action: "brand_style", businessId, style }) });
      setStyle(result.style); setStyleDirty(false); setNotice({ error: false, text: "Brand template saved for this business." });
    });
  }
  async function exportFile(bundle: boolean) {
    if (!post || dirty || styleDirty) return;
    await perform("export", async () => { await downloadStudioFile(`/api/studio/export/${post.id}${bundle ? "?bundle=1" : ""}`); setNotice({ error: false, text: "Saved draft graphic assets exported. This is a local template render, not AI image generation or publication." }); });
  }

  if (loading) return <DashboardSkeleton />;
  if (!data) return <EmptyState icon={PenTool} title="The studio could not load" description={notice?.text || "No content was changed. Retry the workspace service."} action={<Button onClick={() => void loadBusiness()}>Retry studio</Button>} />;
  if (!data.businesses.length || !businessId) return <><PageHeader eyebrow="Content studio · Phase 4" title="Start with a real business." description="Drafts, brand assets and generated suggestions need an authorized business profile. No sample business is created on your behalf." /><EmptyState icon={PenTool} title="No business selected" description="Create a business profile first, then return here to write, review and plan its content." action={<ButtonLink href="/dashboard/businesses" arrow>Open Businesses</ButtonLink>} /></>;

  const business = data.businesses.find((item) => item.id === businessId)!;
  const canApprove = ["owner", "admin"].includes(data.actorRole);
  const visiblePosts = data.posts.filter((item) => (showArchived || item.status !== "archived") && item.title.toLowerCase().includes(search.toLowerCase()));
  const suggestions = data.generations.filter((item) => item.postId === post?.id && item.kind !== "studio_ideas").slice(0, 5);
  const ideas = data.generations.filter((item) => item.kind === "studio_ideas").flatMap((item) => (Array.isArray(item.output.ideas) ? item.output.ideas as Array<{ title: string; brief: string; format: ContentFormat }> : []).map((idea, index) => ({ ...idea, key: `${item.id}-${index}` }))).slice(0, 12);
  const zoneOptions = [...new Set([zone, ...zones])];

  return (
    <>
      <PageHeader eyebrow="Content studio · Phase 4" title="A clear idea. A considered expression." description="Create a draft, shape it in your brand's voice, and plan its moment. AI suggestions stay separate until you apply them. Scheduling records intent—not a live publishing promise." status="Drafts are private">
        <Button variant="secondary" onClick={() => { if (canLeave()) void loadBusiness(businessId, post?.id); }} disabled={Boolean(busy)} className="min-h-10 px-4"><RefreshCw className="h-3.5 w-3.5" /> Refresh</Button>
        <Button onClick={() => void newDraft()} disabled={Boolean(busy)}><Plus className="h-4 w-4" /> New draft</Button>
      </PageHeader>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3"><label className="flex items-center gap-3 text-[0.65rem] font-semibold text-secondary">Business<select aria-label="Studio business" value={businessId} onChange={(event) => { if (canLeave()) void loadBusiness(Number(event.target.value)); }} className="max-w-64 rounded-full border border-line bg-white px-4 py-2.5 text-xs text-ink outline-none">{data.businesses.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><div className="flex flex-wrap gap-2"><Badge tone={data.capabilities.aiConfigured ? "sage" : "amber"}>{data.capabilities.aiConfigured ? "AI key present" : "AI pending"}</Badge><Badge tone="neutral">Publishing not connected</Badge></div></div>
      {notice && <div role={notice.error ? "alert" : "status"} className={cn("mb-6 rounded-xl border p-4 text-xs leading-6", notice.error ? "border-[#dfcfb6] bg-[#f7f2e8] text-[#735c32]" : "border-sage/45 bg-mint/40 text-forest")}>{notice.text}</div>}

      <div className="grid items-start gap-5 lg:grid-cols-[12rem_minmax(0,1fr)] xl:grid-cols-[12rem_minmax(0,1fr)_17rem] 2xl:grid-cols-[14rem_minmax(0,1fr)_19rem]">
        <aside className="space-y-5">
          <Panel className="overflow-hidden"><div className="border-b border-line p-4"><p className="eyebrow">Saved library</p><div className="mt-3 flex items-baseline justify-between"><h2 className="font-display text-2xl text-ink">Drafts</h2><span className="text-[0.6rem] text-secondary">{data.posts.length} loaded</span></div><input aria-label="Find a draft" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Find a draft…" className="mt-3 w-full rounded-lg border border-line bg-pale/40 px-3 py-2 text-xs outline-none focus:border-teal" /><label className="mt-3 flex items-center gap-2 text-[0.6rem] text-secondary"><input type="checkbox" checked={showArchived} onChange={(event) => setShowArchived(event.target.checked)} className="accent-teal" /> Show archived</label></div><div className="max-h-[28rem] overflow-auto p-2">{visiblePosts.length ? visiblePosts.map((item) => <button key={item.id} type="button" onClick={() => { if (canLeave()) void perform("open", () => choosePost(item.id)); }} className={cn("mb-1 block w-full rounded-xl border p-3 text-left transition-colors", post?.id === item.id ? "border-sage/50 bg-mint/45" : "border-transparent hover:bg-pale")}><span className="line-clamp-2 block text-xs font-semibold leading-5 text-ink">{item.title}</span><span className="mt-2 flex items-center justify-between gap-2 text-[0.55rem] uppercase tracking-wider text-secondary"><span>{item.format}</span><span>{item.status.replaceAll("_", " ")}</span></span></button>) : <p className="p-4 text-xs leading-6 text-secondary">No saved drafts match. New content starts with your action—not sample posts.</p>}</div></Panel>
          <Panel className="bg-forest p-5 text-white"><Sparkles className="h-4 w-4 text-sage" strokeWidth={1.4} /><h2 className="mt-4 font-display text-2xl">Find the next angle.</h2><p className="mt-3 text-[0.65rem] leading-6 text-white/65">Ask the configured agent for ideas based on this business, its saved voice, strategy and actual research context.</p><Button variant="light" className="mt-5 min-h-9 w-full px-3 text-[0.65rem]" onClick={() => void generate("studio_ideas")} disabled={Boolean(busy)}>{busy === "studio_ideas" ? "Researching the brief…" : "Generate ideas"}</Button></Panel>
          {ideas.length > 0 && <div className="space-y-3">{ideas.map((idea) => <Panel key={idea.key} className="p-4"><Badge tone="neutral">AI idea · {idea.format}</Badge><h3 className="mt-3 font-display text-xl leading-tight text-ink">{idea.title}</h3><p className="mt-2 line-clamp-3 text-[0.65rem] leading-5 text-secondary">{idea.brief}</p><button type="button" disabled={Boolean(busy)} onClick={() => void newDraft(idea.format, idea.title, idea.brief)} className="mt-3 text-[0.65rem] font-semibold text-teal hover:text-forest">Start a draft →</button></Panel>)}</div>}
        </aside>

        <div className="min-w-0 space-y-5">
          {!post ? <EmptyState icon={PenTool} title="A draft is a good beginning." description="Create a blank, saved draft to start writing. You can work manually without spending AI quota, or request an attributed AI suggestion when ready." action={<Button onClick={() => void newDraft()}><Plus className="h-4 w-4" /> Create first draft</Button>} /> : <>
            <Panel className="p-5 sm:p-6">
              <div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div className="flex flex-wrap gap-2"><Badge tone={post.status === "approved" || post.status === "scheduled" ? "sage" : post.status === "in_review" ? "amber" : "neutral"}>{post.status.replaceAll("_", " ")}</Badge><Badge tone="neutral">Version {post.version}</Badge>{dirty && <Badge tone="amber">Unsaved edits</Badge>}</div><Button type="button" onClick={() => void mutate("save", { document: draft })} disabled={Boolean(busy) || !dirty} className="min-h-9 px-4 text-[0.68rem]"><Save className="h-3.5 w-3.5" /> {busy === "save" ? "Saving…" : "Save draft"}</Button></div>
              <label className="block"><span className="mb-2 block text-[0.6rem] font-bold uppercase tracking-[0.12em] text-secondary">Draft title</span><input aria-label="Draft title" value={draft.title} maxLength={180} onChange={(event) => patch({ title: event.target.value })} className="w-full border-0 bg-transparent font-display text-[1.8rem] leading-tight tracking-[-0.02em] text-ink outline-none placeholder:text-sage" /></label>
              <div className="mt-5 flex flex-wrap items-center gap-4 border-y border-line py-4"><label className="flex items-center gap-2 text-[0.65rem] text-secondary">Format<select aria-label="Draft format" value={draft.format} onChange={(event) => patch({ format: event.target.value as ContentFormat })} className="rounded-full border border-line bg-pale/50 px-3 py-2 text-[0.65rem] text-forest"><option value="post">Single post</option><option value="carousel">Carousel</option><option value="video">Video script</option></select></label><div className="flex flex-wrap gap-3">{(["instagram", "facebook", "linkedin"] as Platform[]).map((platform) => <label key={platform} className="flex items-center gap-1.5 text-[0.65rem] capitalize text-secondary"><input type="checkbox" className="accent-teal" checked={draft.platforms.includes(platform)} disabled={draft.platforms.length === 1 && draft.platforms.includes(platform)} onChange={() => patch({ platforms: draft.platforms.includes(platform) ? draft.platforms.filter((p) => p !== platform) : [...draft.platforms, platform] })} />{platform}</label>)}</div></div>
              <div className="no-scrollbar my-5 flex gap-1 overflow-x-auto">{tabs.map((item) => <button key={item.id} type="button" onClick={() => setTab(item.id)} aria-pressed={tab === item.id} className={cn("shrink-0 rounded-full px-3.5 py-2 text-[0.65rem] font-semibold transition-colors", tab === item.id ? "bg-forest text-white" : "text-secondary hover:bg-mint/50")}>{item.label}</button>)}</div>

              {tab === "write" && <div className="space-y-5">
                <label className="block"><span className="mb-2 block text-[0.65rem] font-semibold text-ink">Creative brief</span><textarea aria-label="Creative brief" rows={3} maxLength={6000} value={draft.brief} onChange={(event) => patch({ brief: event.target.value })} placeholder="What should this content say, to whom, and why?" className={inputClass} /></label>
                <div className="rounded-xl border border-sage/35 bg-pale/60 p-4"><p className="text-[0.6rem] font-bold uppercase tracking-[0.12em] text-teal">AI assists. You direct.</p><p className="mt-2 text-[0.65rem] leading-6 text-secondary">Your saved business/brand context and brief are sent server-side to eligible providers. Paid fallback requires workspace authorization. Save edits first; suggestions never replace your draft automatically. Do not put secrets or confidential client material into AI briefs; free-tier data-use terms may differ.</p><div className="mt-3 flex flex-wrap gap-2"><Button variant="secondary" className="min-h-9 px-3 text-[0.65rem]" disabled={Boolean(busy) || dirty} onClick={() => void generate("studio_caption")}><Sparkles className="h-3.5 w-3.5" /> Generate caption</Button><Button variant="secondary" className="min-h-9 px-3 text-[0.65rem]" disabled={Boolean(busy) || dirty} onClick={() => void generate("studio_carousel")}><Layers3 className="h-3.5 w-3.5" /> Generate carousel</Button><Button variant="ghost" className="min-h-9 px-3 text-[0.65rem]" disabled={Boolean(busy) || dirty} onClick={() => void generate("studio_video_script")}>Write video script</Button></div>{busy.startsWith("studio_") && <p role="status" className="mt-3 text-xs text-teal">Running a real provider task… fallback may take up to a minute. Work is retained on the task.</p>}</div>
                <div><div className="mb-3 flex flex-wrap items-center justify-between gap-2"><label htmlFor="caption-editor" className="text-[0.65rem] font-semibold text-ink">Caption editor</label><select aria-label="Caption variant" value={captionMode} onChange={(event) => setCaptionMode(event.target.value as typeof captionMode)} className="rounded-full border border-line bg-white px-3 py-2 text-[0.6rem] text-teal"><option value="base">Base caption</option>{draft.platforms.map((platform) => <option key={platform} value={platform}>{platform} adaptation</option>)}</select></div><textarea id="caption-editor" rows={9} maxLength={10000} value={captionMode === "base" ? draft.caption : draft.platformCaptions[captionMode]} onChange={(event) => captionMode === "base" ? patch({ caption: event.target.value }) : patch({ platformCaptions: { ...draft.platformCaptions, [captionMode]: event.target.value } })} className={inputClass} placeholder="Write something your audience has a reason to care about." /><p className="mt-2 text-[0.59rem] text-secondary">{(captionMode === "base" ? draft.caption : draft.platformCaptions[captionMode]).length} characters · platform API constraints will be validated during publishing integration.</p></div>
                <label className="block"><span className="mb-2 block text-[0.65rem] font-semibold text-ink">Hashtags (spaces or commas)</span><input aria-label="Hashtags" value={hashText} onChange={(event) => { setHashText(event.target.value); patch({ hashtags: [...new Set(event.target.value.split(/[\s,]+/).map((tag) => tag.replace(/^#+/, "").trim()).filter(Boolean))] }); }} className={inputClass} placeholder="brandvoice, thoughtfulcontent" /></label>
                {draft.format === "video" && <div><label htmlFor="video-script" className="mb-2 block text-[0.65rem] font-semibold text-ink">Video script / storyboard</label><textarea id="video-script" rows={8} value={draft.videoScript} onChange={(event) => patch({ videoScript: event.target.value })} className={inputClass} /><p className="mt-2 rounded-lg bg-[#f7f2e8] p-3 text-[0.62rem] leading-5 text-[#735c32]">Script creation is supported. Video generation, encoding and FFmpeg processing are not configured; no rendered video is claimed.</p></div>}
              </div>}

              {tab === "carousel" && <div className="space-y-4"><div className="flex items-center justify-between gap-3"><div><h3 className="font-display text-2xl text-ink">Build the sequence.</h3><p className="mt-1 text-[0.65rem] leading-5 text-secondary">Edit, reorder and describe 2–10 slides. Each saved version stays in history.</p></div><Button variant="secondary" className="min-h-9 px-3 text-[0.65rem]" disabled={draft.slides.length >= 10} onClick={() => patch({ format: "carousel", slides: [...draft.slides, { id: crypto.randomUUID(), heading: "", body: "", altText: "", imageAssetId: null }] })}><Plus className="h-3.5 w-3.5" /> Add slide</Button></div>{draft.slides.length === 0 && <p className="rounded-xl border border-dashed border-sage/40 bg-pale/50 p-6 text-xs leading-6 text-secondary">No slides yet. Add one or generate a carousel from the saved brief.</p>}{draft.slides.map((slide, index) => <div key={slide.id} className="rounded-xl border border-line bg-pale/45 p-4"><div className="mb-3 flex items-center justify-between"><span className="text-[0.6rem] font-bold uppercase tracking-[0.1em] text-teal">Slide {String(index + 1).padStart(2, "0")}</span><div className="flex gap-1">{[-1, 1].map((delta) => <button key={delta} type="button" aria-label={`${delta < 0 ? "Move slide up" : "Move slide down"} ${index + 1}`} disabled={index + delta < 0 || index + delta >= draft.slides.length} onClick={() => { const slides = [...draft.slides]; [slides[index], slides[index + delta]] = [slides[index + delta], slides[index]]; patch({ slides }); }} className="grid h-7 w-7 place-items-center rounded-full border border-line bg-white text-secondary disabled:opacity-30">{delta < 0 ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}</button>)}<button type="button" aria-label={`Remove slide ${index + 1}`} onClick={() => patch({ slides: draft.slides.filter((_, i) => i !== index) })} className="grid h-7 w-7 place-items-center rounded-full border border-line bg-white text-secondary"><Trash2 className="h-3 w-3" /></button></div></div><input aria-label={`Slide ${index + 1} heading`} value={slide.heading} maxLength={160} placeholder="Slide heading" onChange={(event) => patch({ slides: draft.slides.map((s, i) => i === index ? { ...s, heading: event.target.value } : s) })} className={inputClass} /><textarea aria-label={`Slide ${index + 1} body`} rows={4} maxLength={1400} value={slide.body} placeholder="One thought, clearly expressed." onChange={(event) => patch({ slides: draft.slides.map((s, i) => i === index ? { ...s, body: event.target.value } : s) })} className={`${inputClass} mt-3`} /><input aria-label={`Slide ${index + 1} alt text`} value={slide.altText} placeholder="Accessible description" onChange={(event) => patch({ slides: draft.slides.map((s, i) => i === index ? { ...s, altText: event.target.value } : s) })} className={`${inputClass} mt-3`} /><select aria-label={`Slide ${index + 1} image`} value={slide.imageAssetId ?? ""} onChange={(event) => patch({ slides: draft.slides.map((s, i) => i === index ? { ...s, imageAssetId: event.target.value ? Number(event.target.value) : null } : s) })} className={`${inputClass} mt-3`}><option value="">Use brand template / primary image</option>{data.assets.map((asset) => <option key={asset.id} value={asset.id}>{asset.name}</option>)}</select></div>)}</div>}

              {tab === "media" && <><MediaLibrary assets={data.assets} businessId={businessId} stockConfigured={data.capabilities.stockConfigured} onRefresh={async () => { await refreshLists(businessId); }} onChoose={(asset) => { patch({ primaryMediaId: asset.id }); setNotice({ error: false, text: "Primary media selected in the editor. Save the draft to persist this choice." }); }} />{draft.primaryMediaId && <Button type="button" variant="ghost" className="mt-4" onClick={() => patch({ primaryMediaId: null })}>Remove primary image</Button>}</>}

              {tab === "brand" && <div><div className="flex items-center gap-3"><Palette className="h-5 w-5 text-teal" strokeWidth={1.4} /><h3 className="font-display text-2xl text-ink">A reusable visual language.</h3></div><p className="mt-3 text-xs leading-6 text-secondary">These settings drive deterministic branded PNGs and carousel exports. They are not AI image generation.</p><div className="mt-5 grid gap-4 sm:grid-cols-3">{(["background", "foreground", "accent"] as const).map((key) => <label key={key} className="rounded-xl border border-line bg-pale/50 p-3"><span className="block text-[0.6rem] font-semibold capitalize text-ink">{key}</span><div className="mt-3 flex items-center gap-2"><input aria-label={`Brand ${key} color`} type="color" value={style[key]} onChange={(event) => { setStyle({ ...style, [key]: event.target.value }); setStyleDirty(true); }} className="h-8 w-8 cursor-pointer rounded border-0 bg-transparent" /><code className="text-[0.6rem] text-secondary">{style[key]}</code></div></label>)}</div><div className="mt-4 grid gap-4 sm:grid-cols-2"><label className="text-[0.65rem] font-semibold text-ink">Display style<select aria-label="Brand display style" value={style.font} onChange={(event) => { setStyle({ ...style, font: event.target.value as BrandStyle["font"] }); setStyleDirty(true); }} className={`${inputClass} mt-2`}><option value="editorial">Editorial serif</option><option value="modern">Modern sans</option></select></label><label className="text-[0.65rem] font-semibold text-ink">Uploaded logo<select aria-label="Brand logo" value={style.logoAssetId ?? ""} onChange={(event) => { setStyle({ ...style, logoAssetId: event.target.value ? Number(event.target.value) : null }); setStyleDirty(true); }} className={`${inputClass} mt-2`}><option value="">No logo</option>{data.assets.filter((asset) => asset.source === "upload").map((asset) => <option key={asset.id} value={asset.id}>{asset.name}</option>)}</select></label></div><Button type="button" className="mt-5" disabled={Boolean(busy) || !styleDirty || !canApprove} onClick={() => void saveStyle()}>Save brand kit</Button>{styleDirty && <p className="mt-3 text-[0.62rem] text-secondary">Unsaved brand changes are visible in the preview. Save them before exporting.</p>}</div>}

              {tab === "history" && <div><div className="flex items-center gap-3"><History className="h-5 w-5 text-teal" /><h3 className="font-display text-2xl text-ink">The work, preserved.</h3></div><p className="mt-3 text-xs leading-6 text-secondary">Restore creates a new editable version. It does not restore approval or an old publishing schedule.</p><div className="mt-5 divide-y divide-line">{revisions.length ? revisions.map((revision) => <div key={revision.id} className="flex items-center justify-between gap-4 py-4"><div><p className="text-xs font-semibold text-ink">Version {revision.version} · {revision.action.replaceAll("_", " ")}</p><p className="mt-1 text-[0.6rem] text-secondary">{new Date(revision.createdAt).toLocaleString()}</p></div><button type="button" disabled={Boolean(busy) || revision.version === post.version} onClick={() => { if (canLeave()) void mutate("restore", { revisionId: revision.id }); }} className="text-[0.65rem] font-semibold text-teal disabled:opacity-35">Restore</button></div>) : <p className="text-xs text-secondary">The creation record appears after refreshing this draft.</p>}</div></div>}
            </Panel>

            {suggestions.length > 0 && <Panel className="p-5"><p className="eyebrow">Generated suggestions · not auto-applied</p><div className="mt-4 space-y-3">{suggestions.map((generation) => <div key={generation.id} className="rounded-xl border border-line bg-pale/45 p-4"><div className="flex flex-wrap items-center justify-between gap-2"><span className="text-xs font-semibold text-ink">{generation.kind.replace("studio_", "").replaceAll("_", " ")} · #{generation.id}</span><Badge tone="neutral">{generation.providerKey}</Badge></div><p className="mt-3 line-clamp-4 whitespace-pre-wrap text-[0.68rem] leading-6 text-secondary">{typeof generation.output.caption === "string" ? generation.output.caption : typeof generation.output.script === "string" ? generation.output.script : "Structured carousel suggestion is ready for inspection."}</p><details className="mt-2"><summary className="cursor-pointer text-[0.62rem] font-semibold text-teal">Inspect complete output</summary><pre className="mt-3 max-h-64 overflow-auto rounded-lg bg-white p-3 text-[0.6rem] leading-5 text-secondary">{JSON.stringify(generation.output, null, 2)}</pre></details><div className="mt-4 flex items-center justify-between"><span className="text-[0.58rem] text-secondary">{generation.sources.length} source URLs supplied as context</span><Button variant="secondary" className="min-h-8 px-3 py-1.5 text-[0.62rem]" disabled={Boolean(busy) || dirty || Boolean(generation.appliedAt)} onClick={() => void mutate("apply", { generationId: generation.id })}>{generation.appliedAt ? "Applied" : "Apply to draft"}</Button></div></div>)}</div></Panel>}

            <Panel className="p-5 sm:p-6"><div className="flex items-center gap-3"><ShieldCheck className="h-5 w-5 text-teal" strokeWidth={1.4} /><h2 className="font-display text-2xl text-ink">Review, then make a plan.</h2></div><p className="mt-3 text-xs leading-6 text-secondary">Owner/admin approval is required for scheduling. Editing an approved or scheduled version clears its approval and planned time. Nothing here publishes to a social API.</p>
              {post.reviewFlags.length > 0 && <div className="mt-4 rounded-xl border border-[#dfcfb6] bg-[#f7f2e8] p-4 text-[0.65rem] leading-6 text-[#735c32]"><p className="font-bold uppercase tracking-wider">Review flags</p><ul className="mt-2 list-inside list-disc">{post.reviewFlags.map((flag) => <li key={flag}>{flag}</li>)}</ul></div>}
              <label className="mt-5 flex items-start gap-3 text-[0.65rem] leading-6 text-secondary"><input type="checkbox" aria-label="Acknowledge content review flags" checked={acknowledged} onChange={(event) => setAcknowledged(event.target.checked)} className="mt-1.5 accent-teal" /> I reviewed this version's claims, sensitive topics, source rights and brand policy. This is a human acknowledgement, not automatic verification of a claim.</label>
              <div className="mt-4 flex flex-wrap gap-2"><Button variant="secondary" disabled={Boolean(busy) || dirty} onClick={() => void mutate("review")}>Request review</Button><Button disabled={Boolean(busy) || dirty || !canApprove || (post.reviewFlags.length > 0 && !acknowledged)} onClick={() => void mutate("approve", { acknowledgeFlags: acknowledged })}><Check className="h-4 w-4" /> Approve version</Button><Button variant="ghost" disabled={Boolean(busy)} onClick={() => void mutate("archive")}><Archive className="h-3.5 w-3.5" /> Archive</Button></div>
              <div className="mt-6 grid gap-3 border-t border-line pt-5 sm:grid-cols-2"><label className="text-[0.65rem] font-semibold text-ink">Planned date and time<input aria-label="Planned date and time" type="datetime-local" value={wallTime} onChange={(event) => setWallTime(event.target.value)} className={`${inputClass} mt-2`} /></label><label className="text-[0.65rem] font-semibold text-ink">Time zone<select aria-label="Schedule time zone" value={zone} onChange={(event) => setZone(event.target.value)} className={`${inputClass} mt-2`}>{zoneOptions.map((item) => <option key={item} value={item}>{item}</option>)}</select></label></div>
              <div className="mt-4 flex flex-wrap items-center gap-3"><Button disabled={Boolean(busy) || dirty || !canApprove || post.status !== "approved"} onClick={() => void mutate("schedule", { wallTime, timeZone: zone })}><Clock3 className="h-4 w-4" /> Save schedule</Button>{post.status === "scheduled" && <Button variant="secondary" disabled={Boolean(busy)} onClick={() => void mutate("unschedule")}>Remove schedule</Button>}<ButtonLink href="/dashboard/calendar" variant="ghost">Open calendar →</ButtonLink></div>
              {post.scheduledAt && <p className="mt-4 rounded-xl bg-mint/40 p-4 text-xs leading-6 text-forest">Planned for {formatInTimeZone(post.scheduledAt, post.timeZone, "dd MMM yyyy, HH:mm zzz")} · {post.timeZone}. Publishing integrations/workers are not connected; this entry will not publish automatically.</p>}
            </Panel>
            <div className="flex flex-wrap items-center gap-3"><Button variant="secondary" disabled={Boolean(busy) || dirty || styleDirty} onClick={() => void exportFile(false)}><Download className="h-4 w-4" /> Export graphic PNG</Button><Button variant="secondary" disabled={Boolean(busy) || dirty || styleDirty} onClick={() => void exportFile(true)}><Layers3 className="h-4 w-4" /> Export slide bundle</Button><span className="text-[0.6rem] text-secondary">Saved template render · no image API charge</span></div>
          </>}
        </div>
        <div className="lg:col-start-2 xl:col-start-auto">{post && <ChannelPreview document={draft} style={style} brand={business.name} assets={data.assets} />}</div>
      </div>
    </>
  );
}
