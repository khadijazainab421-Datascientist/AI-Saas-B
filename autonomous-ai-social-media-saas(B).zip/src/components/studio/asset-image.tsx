"use client";

import { useEffect, useState } from "react";
import { ImageOff } from "lucide-react";
import { apiFetch } from "@/lib/api-fetch";
import type { AssetDTO } from "@/lib/studio/types";
import { cn } from "@/lib/utils";

export function AssetImage({ asset, className }: { asset: AssetDTO; className?: string }) {
  const [url, setUrl] = useState<string | null>(asset.remoteUrl);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let disposed = false; let objectUrl: string | null = null;
    setFailed(false); setUrl(asset.remoteUrl);
    if (!asset.remoteUrl) void apiFetch(`/api/studio/assets/${asset.id}`).then(async (response) => {
      if (!response.ok) throw new Error();
      const blob = await response.blob();
      objectUrl = URL.createObjectURL(blob);
      if (!disposed) setUrl(objectUrl); else URL.revokeObjectURL(objectUrl);
    }).catch(() => { if (!disposed) setFailed(true); });
    return () => { disposed = true; if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [asset.id, asset.remoteUrl]);
  if (failed) return <div className={cn("grid place-items-center bg-pale text-secondary", className)} role="img" aria-label="Asset could not be loaded"><ImageOff className="h-5 w-5" /></div>;
  if (!url) return <div className={cn("animate-pulse bg-mint/40", className)} role="status" aria-label="Loading private image" />;
  // Blob URLs preserve authenticated access; Unsplash URLs are hotlinked as required by its API.
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={url} alt={asset.altText || asset.name} className={className} referrerPolicy="no-referrer" onError={() => setFailed(true)} />;
}
