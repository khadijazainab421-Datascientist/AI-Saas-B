"use client";

import { useState, type ChangeEvent } from "react";
import { ArrowUpRight, ImagePlus, Search, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AssetImage } from "./asset-image";
import { studioApi } from "@/lib/studio/client";
import type { AssetDTO } from "@/lib/studio/types";
import type { StockPhoto } from "@/lib/studio/unsplash";

export function MediaLibrary({ assets, businessId, stockConfigured, onChoose, onRefresh }: {
  assets: AssetDTO[]; businessId: number; stockConfigured: boolean;
  onChoose: (asset: AssetDTO) => void; onRefresh: () => Promise<void>;
}) {
  const [query, setQuery] = useState(""); const [photos, setPhotos] = useState<StockPhoto[]>([]);
  const [busy, setBusy] = useState(false); const [message, setMessage] = useState("");
  async function upload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]; if (!file) return;
    setBusy(true); setMessage("");
    try {
      const body = new FormData(); body.append("file", file); body.append("businessId", String(businessId));
      const result = await studioApi<{ asset: AssetDTO }>("/api/studio/assets", { method: "POST", body });
      await onRefresh(); onChoose(result.asset); setMessage("Image uploaded and normalized. Choose Save draft to retain the selection.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "Upload failed."); }
    finally { setBusy(false); event.target.value = ""; }
  }
  async function search() {
    setBusy(true); setMessage("");
    try { const result = await studioApi<{ photos: StockPhoto[] }>(`/api/studio/stock?q=${encodeURIComponent(query)}`); setPhotos(result.photos); if (!result.photos.length) setMessage("The provider returned no photos for this query."); }
    catch (error) { setMessage(error instanceof Error ? error.message : "Search failed."); } finally { setBusy(false); }
  }
  async function link(photo: StockPhoto) {
    setBusy(true); setMessage("");
    try { const result = await studioApi<{ asset: AssetDTO }>("/api/studio/assets", { method: "POST", body: JSON.stringify({ businessId, photoId: photo.id }) }); await onRefresh(); onChoose(result.asset); setMessage("Credited provider photo linked. Its CDN URL remains hotlinked; no local stock-file copy was made."); }
    catch (error) { setMessage(error instanceof Error ? error.message : "Photo selection failed."); } finally { setBusy(false); }
  }
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><p className="eyebrow">Your image library</p><p className="mt-2 text-xs leading-6 text-secondary">JPG, PNG or WebP · max 5 MiB · EXIF stripped · private PostgreSQL storage.</p></div>
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-full border border-sage/50 bg-mint/40 px-4 py-2.5 text-xs font-semibold text-forest"><Upload className="h-3.5 w-3.5" aria-hidden="true" /> {busy ? "Working…" : "Upload image"}<input className="sr-only" type="file" aria-label="Upload image" accept="image/jpeg,image/png,image/webp" disabled={busy} onChange={(event) => void upload(event)} /></label>
      </div>
      <p className="text-[0.62rem] leading-5 text-secondary">Upload only media you have rights to use. Uploads are user-supplied, not independently rights-verified.</p>
      {message && <p role="status" className="rounded-xl border border-line bg-pale p-3 text-xs leading-6 text-forest">{message}</p>}
      {assets.length ? <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">{assets.slice(0, 24).map((asset) => <div key={asset.id} className="overflow-hidden rounded-xl border border-line bg-white">
        <button type="button" onClick={() => onChoose(asset)} className="block w-full text-left" aria-label={`Use image ${asset.name}`}><AssetImage asset={asset} className="aspect-square w-full object-cover" /><span className="block truncate px-3 pt-2 text-[0.65rem] font-semibold text-ink">{asset.name}</span></button>
        <div className="px-3 pb-3 pt-1">{asset.source === "unsplash" ? <a href={asset.photographerUrl || asset.sourceUrl || "https://unsplash.com"} target="_blank" rel="noreferrer" className="text-[0.56rem] text-teal">Photo by {asset.photographer} on Unsplash ↗</a> : <span className="text-[0.56rem] uppercase tracking-wider text-secondary">Private upload</span>}</div>
      </div>)}</div> : <div className="rounded-2xl border border-dashed border-sage/50 bg-pale/40 p-8 text-center"><ImagePlus className="mx-auto h-6 w-6 text-sage-dark" strokeWidth={1.4} /><p className="mt-3 text-xs text-secondary">No media for this business. Your first upload will appear here.</p></div>}
      <div className="border-t border-line pt-5">
        <div className="flex flex-wrap items-center justify-between gap-3"><h3 className="font-display text-2xl text-ink">Find a considered visual.</h3><Badge tone={stockConfigured ? "sage" : "amber"}>{stockConfigured ? "Unsplash configured" : "Stock key pending"}</Badge></div>
        <p className="mt-2 text-xs leading-6 text-secondary">{stockConfigured ? "Unsplash photos remain hotlinked and credited. Selection triggers required download tracking." : "Configure UNSPLASH_ACCESS_KEY to enable real photo search. No results or integration success are simulated. Uploads and local graphic exports do not need this key."}</p>
        <div className="mt-4 flex gap-2"><input aria-label="Stock photo query" value={query} onChange={(event) => setQuery(event.target.value)} disabled={!stockConfigured || busy} placeholder="e.g. quiet architecture" className="min-w-0 flex-1 rounded-xl border border-line bg-white px-3 py-2.5 text-xs outline-none focus:border-teal disabled:bg-pale" /><Button type="button" variant="secondary" disabled={!stockConfigured || busy || query.trim().length < 2} onClick={() => void search()}><Search className="h-4 w-4" aria-hidden="true" /> Search</Button></div>
        {!stockConfigured && <a href="https://unsplash.com/oauth/applications" target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-1 text-[0.65rem] font-semibold text-teal">Official developer setup <ArrowUpRight className="h-3 w-3" /></a>}
        {photos.length > 0 && <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">{photos.map((photo) => <div key={photo.id} className="overflow-hidden rounded-xl border border-line bg-white">
          {/* eslint-disable-next-line @next/next/no-img-element */}<img src={photo.thumbnail} alt={photo.altText} className="aspect-square w-full object-cover" />
          <div className="space-y-2 p-3"><a href={photo.photographerUrl} target="_blank" rel="noreferrer" className="block text-[0.58rem] text-teal">Photo by {photo.photographer} on Unsplash ↗</a><button type="button" onClick={() => void link(photo)} disabled={busy} className="text-[0.65rem] font-semibold text-forest underline underline-offset-4">Use photo</button></div>
        </div>)}</div>}
      </div>
    </div>
  );
}
