"use client";

import { useState } from "react";
import { ChevronLeft, ChevronRight, Heart, MessageCircle, Send, Bookmark } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { DraftInput, BrandStyle, AssetDTO, Platform } from "@/lib/studio/types";
import { graphicSvg } from "@/lib/studio/graphic-template";
import { AssetImage } from "./asset-image";

export function ChannelPreview({ document, style, brand, assets }: { document: DraftInput; style: BrandStyle; brand: string; assets: AssetDTO[] }) {
  const [channel, setChannel] = useState<Platform>(document.platforms[0]); const [index, setIndex] = useState(0);
  const currentChannel = document.platforms.includes(channel) ? channel : document.platforms[0];
  const slideIndex = Math.min(index, Math.max(document.slides.length - 1, 0));
  const slide = document.format === "carousel" ? document.slides[slideIndex] : undefined;
  const assetId = slide?.imageAssetId ?? document.primaryMediaId;
  const asset = assets.find((item) => item.id === assetId);
  const svg = graphicSvg({ brand, heading: slide?.heading || document.title, body: slide?.body || (document.format === "video" ? "Video script / poster concept. No rendered video is attached." : document.caption), style, index: slideIndex, count: document.format === "carousel" ? Math.max(document.slides.length, 1) : 1 });
  const text = document.platformCaptions[currentChannel] || document.caption;
  return (
    <div className="lg:sticky lg:top-24">
      <div className="mb-4 flex items-center justify-between"><p className="eyebrow">Channel preview</p><Badge tone="neutral">Not published</Badge></div>
      <select aria-label="Preview channel" value={currentChannel} onChange={(event) => setChannel(event.target.value as Platform)} className="mb-4 w-full rounded-xl border border-line bg-white px-3 py-2.5 text-xs capitalize text-ink outline-none focus:border-teal">{document.platforms.map((platform) => <option key={platform} value={platform}>{platform}</option>)}</select>
      <div className="overflow-hidden rounded-2xl border border-line bg-white">
        <div className="flex items-center gap-3 border-b border-line p-4"><span className="grid h-8 w-8 place-items-center rounded-full bg-mint font-display text-sm text-forest">{brand.slice(0, 1)}</span><div className="min-w-0"><p className="truncate text-[0.68rem] font-bold text-ink">{brand}</p><p className="text-[0.54rem] text-secondary">Draft preview · {currentChannel}</p></div><span className="ml-auto text-secondary" aria-hidden="true">···</span></div>
        {asset ? <AssetImage asset={asset} className="aspect-square w-full object-cover" /> : <>
          {/* eslint-disable-next-line @next/next/no-img-element */}<img src={`data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`} alt="Branded template draft preview" className="aspect-square w-full object-cover" />
        </>}
        {document.format === "carousel" && document.slides.length > 0 && <div className="flex items-center justify-between border-t border-line px-3 py-2"><button type="button" aria-label="Previous preview slide" disabled={slideIndex === 0} onClick={() => setIndex(slideIndex - 1)} className="grid h-7 w-7 place-items-center rounded-full border border-line disabled:opacity-30"><ChevronLeft className="h-3 w-3" /></button><p className="text-[0.6rem] text-secondary">Slide {slideIndex + 1} of {document.slides.length}</p><button type="button" aria-label="Next preview slide" disabled={slideIndex >= document.slides.length - 1} onClick={() => setIndex(slideIndex + 1)} className="grid h-7 w-7 place-items-center rounded-full border border-line disabled:opacity-30"><ChevronRight className="h-3 w-3" /></button></div>}
        <div className="p-4"><div className="mb-3 flex items-center gap-3 text-forest" aria-hidden="true"><Heart className="h-4 w-4" strokeWidth={1.5} /><MessageCircle className="h-4 w-4" strokeWidth={1.5} /><Send className="h-4 w-4" strokeWidth={1.5} /><Bookmark className="ml-auto h-4 w-4" strokeWidth={1.5} /></div><p className="whitespace-pre-wrap break-words text-[0.68rem] leading-6 text-secondary">{text || "Your saved or edited caption will appear here."}</p>{document.hashtags.length > 0 && <p className="mt-3 break-words text-[0.64rem] leading-5 text-teal">{document.hashtags.map((tag) => `#${tag.replace(/^#/, "")}`).join(" ")}</p>}{asset?.source === "unsplash" && <a href={asset.photographerUrl || asset.sourceUrl || "https://unsplash.com"} target="_blank" rel="noreferrer" className="mt-3 block text-[0.56rem] text-teal">Photo by {asset.photographer} on Unsplash ↗</a>}</div>
      </div>
      <p className="mt-3 text-[0.6rem] leading-5 text-secondary">A layout approximation, not a connected social account. No engagement numbers are fabricated. Local graphic exports use the saved brand template; image rights and platform eligibility still require review.</p>
    </div>
  );
}
