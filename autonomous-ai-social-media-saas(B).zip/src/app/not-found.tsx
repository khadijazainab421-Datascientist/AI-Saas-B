import { ButtonLink } from "@/components/ui/button";
import { Logo } from "@/components/brand/logo";

export default function NotFound() {
  return (
    <main className="fine-grid flex min-h-screen flex-col bg-pale/55 p-6">
      <Logo />
      <div className="m-auto max-w-xl py-20 text-center">
        <p className="text-[0.62rem] font-bold uppercase tracking-[0.17em] text-teal">404 · Outside the workspace</p>
        <h1 className="mt-6 font-display text-6xl leading-[0.95] tracking-[-0.04em] text-ink sm:text-7xl">This page has<br /><span className="italic text-teal">gone quiet.</span></h1>
        <p className="mx-auto mt-6 max-w-md text-sm leading-7 text-secondary">The address does not match a Serein page. Return to the overview or continue exploring the product.</p>
        <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <ButtonLink href="/dashboard">Workspace overview</ButtonLink>
          <ButtonLink href="/" variant="secondary">Back to the site</ButtonLink>
        </div>
      </div>
    </main>
  );
}
