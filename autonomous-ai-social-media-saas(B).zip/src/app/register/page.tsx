import type { Metadata } from "next";
import { headers } from "next/headers";
import { AuthForm } from "@/components/auth/auth-form";
import { standalonePreviewOrigin } from "@/lib/preview-origin";

export const metadata: Metadata = { title: "Create your workspace" };
export const dynamic = "force-dynamic";

export default async function RegisterPage() {
  return <AuthForm mode="register" standaloneOrigin={standalonePreviewOrigin(await headers())} />;
}
