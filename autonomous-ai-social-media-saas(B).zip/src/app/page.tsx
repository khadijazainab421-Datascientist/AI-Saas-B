import Image from "next/image";
import {
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  BookOpen,
  Building2,
  CalendarRange,
  Check,
  Compass,
  Database,
  FileText,
  Globe2,
  KeyRound,
  Layers3,
  LockKeyhole,
  PenTool,
  Search,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { FacebookIcon, InstagramIcon, LinkedInIcon } from "@/components/brand/social-icons";
import { SiteHeader } from "@/components/landing/site-header";
import { Hero } from "@/components/landing/hero";
import { Reveal } from "@/components/landing/reveal";
import { AgentFlow } from "@/components/landing/agent-flow";
import { AutonomyExplorer } from "@/components/landing/autonomy-explorer";
import { FAQ } from "@/components/landing/faq";
import { Logo } from "@/components/brand/logo";
import { Badge } from "@/components/ui/badge";
import { ButtonLink } from "@/components/ui/button";

const platforms = [
  {
    name: "Instagram",
    icon: InstagramIcon,
    description:
      "Planned support for eligible professional accounts, approved media formats, and publishing through the official Instagram Platform.",
    details: ["Professional account eligibility", "Supported feed media formats", "Meta app permissions and review"],
    href: "https://developers.facebook.com/docs/instagram-platform/",
  },
  {
    name: "Facebook",
    icon: FacebookIcon,
    description:
      "Designed for authorized Facebook Pages—not personal passwords—with page-scoped access and explicit publishing permissions.",
    details: ["Page access through OAuth", "Page-scoped publishing", "Token expiry and revocation handling"],
    href: "https://developers.facebook.com/docs/pages-api/",
  },
  {
    name: "LinkedIn",
    icon: LinkedInIcon,
    description:
      "Planned member and organization publishing only where the approved LinkedIn API products and roles permit it.",
    details: ["Approved API product access", "Member or organization roles", "Supported post and media types"],
    href: "https://learn.microsoft.com/en-us/linkedin/marketing/",
  },
];

const plans = [
  {
    name: "Free",
    label: "Begin with clarity",
    description: "For individuals establishing a consistent, considered social presence.",
    features: ["Limited business workspace", "Limited connected accounts", "Basic research and generation", "Basic scheduling"],
  },
  {
    name: "Starter",
    label: "Find your rhythm",
    description: "For growing brands ready for a more distinctive voice and workflow.",
    features: ["Higher content allowances", "More social accounts", "Advanced scheduling", "Brand voice configuration"],
  },
  {
    name: "Professional",
    label: "Build intelligence",
    description: "For businesses that want deeper automation and competitive context.",
    features: ["Multiple businesses", "Advanced autonomous controls", "Competitor research", "Advanced verified analytics"],
  },
  {
    name: "Agency",
    label: "Orchestrate portfolios",
    description: "For teams managing separate clients, approvals, and reporting.",
    features: ["Multiple client workspaces", "Team management", "Higher usage allowances", "Centralized client reporting"],
  },
];

export default function HomePage() {
  return (
    <>
      <SiteHeader />
      <main>
        <Hero />

        <section className="overflow-hidden bg-soft-white py-24 sm:py-32" aria-labelledby="philosophy-title">
          <div className="mx-auto max-w-[1440px] px-5 sm:px-8 lg:px-12">
            <Reveal>
              <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
                <div className="lg:col-span-7">
                  <p className="eyebrow">A different kind of social platform</p>
                  <h2
                    id="philosophy-title"
                    className="mt-6 max-w-4xl font-display text-[clamp(2.9rem,5.4vw,5.7rem)] leading-[0.98] tracking-[-0.04em] text-ink"
                  >
                    Less feeding the feed.<br />
                    <span className="italic text-teal">More building the brand.</span>
                  </h2>
                </div>
                <div className="flex items-end lg:col-span-5">
                  <div className="max-w-md border-l border-sage/45 pl-6 lg:pb-2">
                    <p className="text-base leading-8 text-secondary">
                      The internet has enough content. Serein is being designed for something harder:
                      a recognizable point of view, expressed consistently, with the operational
                      intelligence to improve over time.
                    </p>
                    <p className="mt-5 text-xs font-semibold uppercase tracking-[0.12em] text-forest">
                      Technology handles the repetition. You keep the judgment.
                    </p>
                  </div>
                </div>
              </div>
            </Reveal>

            <div className="mt-16 grid gap-6 lg:grid-cols-12 lg:items-stretch">
              <Reveal className="lg:col-span-7" delay={0.08}>
                <div className="relative h-full min-h-[28rem] overflow-hidden rounded-[1.8rem] border border-line bg-mint/40">
                  <Image
                    src="/images/serein-editorial.jpg"
                    alt="Sculptural glass and sage composition representing clarity and structure"
                    fill
                    sizes="(max-width: 1024px) 100vw, 58vw"
                    className="object-cover transition-transform duration-1000 hover:scale-[1.025]"
                  />
                  <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8">
                    <p className="inline-flex rounded-full border border-white/70 bg-white/75 px-4 py-2 text-[0.6rem] font-bold uppercase tracking-[0.15em] text-forest backdrop-blur-lg">
                      Context before content
                    </p>
                  </div>
                </div>
              </Reveal>

              <div className="grid gap-6 sm:grid-cols-3 lg:col-span-5 lg:grid-cols-1">
                {[
                  {
                    icon: BookOpen,
                    number: "01",
                    title: "Understand before writing",
                    text: "Your website, offers, audience, objectives, and voice become the foundation—not an afterthought in a prompt.",
                  },
                  {
                    icon: Compass,
                    number: "02",
                    title: "Choose with intention",
                    text: "Research becomes content pillars, formats, timing, and a strategy you can inspect and shape.",
                  },
                  {
                    icon: ShieldCheck,
                    number: "03",
                    title: "Automate with boundaries",
                    text: "Approval rules, claim checks, sensitive-topic review, limits, and pause controls define what autonomy means.",
                  },
                ].map((item, index) => {
                  const Icon = item.icon;
                  return (
                    <Reveal key={item.title} delay={0.12 + index * 0.07}>
                      <article className="group flex h-full gap-5 rounded-[1.5rem] border border-line bg-white p-6 transition-colors duration-500 hover:border-sage/60">
                        <div className="flex flex-col items-center">
                          <span className="grid h-10 w-10 place-items-center rounded-full bg-pale text-forest">
                            <Icon className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
                          </span>
                          <span className="mt-3 h-full w-px bg-line" aria-hidden="true" />
                        </div>
                        <div>
                          <span className="text-[0.56rem] font-bold tracking-[0.14em] text-sage-dark">{item.number}</span>
                          <h3 className="mt-2 font-display text-2xl leading-tight text-ink">{item.title}</h3>
                          <p className="mt-3 text-xs leading-6 text-secondary">{item.text}</p>
                        </div>
                      </article>
                    </Reveal>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        <section id="product" className="border-y border-line bg-pale/70 py-24 sm:py-32" aria-labelledby="product-title">
          <div className="mx-auto max-w-[1440px] px-5 sm:px-8 lg:px-12">
            <Reveal>
              <div className="grid gap-8 lg:grid-cols-12 lg:items-end">
                <div className="lg:col-span-8">
                  <p className="eyebrow">The workspace</p>
                  <h2 id="product-title" className="mt-6 font-display text-[clamp(2.8rem,5vw,5.2rem)] leading-[0.98] tracking-[-0.04em] text-ink">
                    One brand mind.<br />
                    <span className="italic text-teal">Every moving part.</span>
                  </h2>
                </div>
                <p className="max-w-md text-sm leading-7 text-secondary lg:col-span-4">
                  A shared context connects each decision, so research does not disappear into a tab,
                  drafts do not lose the strategy, and learning can inform what happens next.
                </p>
              </div>
            </Reveal>

            <div className="mt-14 grid auto-rows-auto gap-5 md:grid-cols-2 lg:grid-cols-12">
              <Reveal className="lg:col-span-7" delay={0.05}>
                <article className="relative h-full overflow-hidden rounded-[1.7rem] border border-line bg-white p-7 sm:p-9">
                  <div className="flex items-start justify-between gap-5">
                    <div>
                      <span className="grid h-11 w-11 place-items-center rounded-full bg-mint/60 text-forest">
                        <Building2 className="h-5 w-5" strokeWidth={1.4} aria-hidden="true" />
                      </span>
                      <h3 className="mt-6 font-display text-3xl text-ink">A living understanding of your business</h3>
                      <p className="mt-3 max-w-lg text-sm leading-7 text-secondary">
                        Website analysis, products and services, audience segments, objectives, and
                        your own guidance come together in a brand context the agent can use across tasks.
                      </p>
                    </div>
                    <Globe2 className="hidden h-16 w-16 text-sage/30 sm:block" strokeWidth={0.8} aria-hidden="true" />
                  </div>
                  <div className="mt-9 grid gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-3">
                    {["Offers & expertise", "Audience & intent", "Voice & vocabulary"].map((item, index) => (
                      <div key={item} className="bg-soft-white p-4">
                        <span className="text-[0.55rem] font-bold tracking-[0.13em] text-sage-dark">CONTEXT 0{index + 1}</span>
                        <p className="mt-2 text-xs font-semibold text-forest">{item}</p>
                      </div>
                    ))}
                  </div>
                </article>
              </Reveal>

              <Reveal className="lg:col-span-5" delay={0.1}>
                <article className="flex h-full flex-col rounded-[1.7rem] bg-forest p-7 text-white sm:p-9">
                  <span className="grid h-11 w-11 place-items-center rounded-full border border-sage/25 bg-white/5 text-mint">
                    <Search className="h-5 w-5" strokeWidth={1.4} aria-hidden="true" />
                  </span>
                  <h3 className="mt-6 font-display text-3xl">Research with a reason</h3>
                  <p className="mt-3 text-sm leading-7 text-white/65">
                    Industry shifts, audience interests, seasonal moments, public competitor content,
                    and useful topics become sourced inputs for planning—not a stream of random ideas.
                  </p>
                  <div className="mt-auto space-y-3 pt-8">
                    {["Industry & cultural moments", "Audience questions & interests", "Public competitor patterns"].map((item) => (
                      <div key={item} className="flex items-center gap-3 border-t border-white/10 pt-3 text-xs text-white/80">
                        <ArrowUpRight className="h-3.5 w-3.5 text-sage" aria-hidden="true" />
                        {item}
                      </div>
                    ))}
                  </div>
                </article>
              </Reveal>

              <Reveal className="lg:col-span-4" delay={0.06}>
                <article className="h-full rounded-[1.7rem] border border-line bg-white p-7">
                  <Layers3 className="h-5 w-5 text-teal" strokeWidth={1.4} aria-hidden="true" />
                  <h3 className="mt-6 font-display text-3xl text-ink">Strategy you can see</h3>
                  <p className="mt-3 text-sm leading-7 text-secondary">
                    Content pillars, formats, frequency, channel roles, and calendar logic make the plan inspectable and adaptable for each business.
                  </p>
                  <div className="mt-7 flex flex-wrap gap-2">
                    {["Educate", "Build trust", "Show the work", "Invite conversation"].map((item) => (
                      <span key={item} className="rounded-full border border-line bg-pale px-3 py-2 text-[0.62rem] font-semibold text-forest">
                        {item}
                      </span>
                    ))}
                  </div>
                </article>
              </Reveal>

              <Reveal className="lg:col-span-8" delay={0.12}>
                <article className="grid h-full gap-8 rounded-[1.7rem] border border-line bg-white p-7 sm:grid-cols-2 sm:p-9">
                  <div>
                    <PenTool className="h-5 w-5 text-teal" strokeWidth={1.4} aria-hidden="true" />
                    <h3 className="mt-6 font-display text-3xl text-ink">A studio shaped by the idea</h3>
                    <p className="mt-3 text-sm leading-7 text-secondary">
                      Captions, concepts, carousels, sourced visuals, branded graphics, hashtags, and channel adaptations stay connected to the same brief and voice.
                    </p>
                  </div>
                  <div className="flex flex-col justify-center gap-3">
                    {[
                      { label: "Single post", detail: "Caption + visual direction", icon: FileText },
                      { label: "Carousel", detail: "Narrative across slides", icon: Layers3 },
                      { label: "Channel adaptation", detail: "Native tone and constraints", icon: Sparkles },
                    ].map((item) => {
                      const Icon = item.icon;
                      return (
                        <div key={item.label} className="flex items-center gap-4 rounded-xl bg-pale/70 p-4">
                          <Icon className="h-4 w-4 shrink-0 text-sage-dark" strokeWidth={1.5} aria-hidden="true" />
                          <div>
                            <p className="text-xs font-semibold text-ink">{item.label}</p>
                            <p className="mt-1 text-[0.62rem] text-secondary">{item.detail}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </article>
              </Reveal>

              <Reveal className="lg:col-span-5" delay={0.06}>
                <article className="h-full rounded-[1.7rem] border border-line bg-mint/45 p-7 sm:p-9">
                  <CalendarRange className="h-5 w-5 text-teal" strokeWidth={1.4} aria-hidden="true" />
                  <h3 className="mt-6 font-display text-3xl text-ink">Publishing with a paper trail</h3>
                  <p className="mt-3 text-sm leading-7 text-secondary">
                    Official APIs, scheduling rules, idempotency safeguards, publishing logs, safe retries, and failure states form the planned automation pipeline.
                  </p>
                  <div className="mt-7 flex items-center gap-2 text-[0.63rem] font-bold uppercase tracking-[0.12em] text-forest">
                    <ShieldCheck className="h-4 w-4" aria-hidden="true" />
                    No silent failures. No duplicate posts.
                  </div>
                </article>
              </Reveal>

              <Reveal className="lg:col-span-7" delay={0.12}>
                <article className="flex h-full flex-col justify-between gap-8 rounded-[1.7rem] border border-line bg-white p-7 sm:flex-row sm:p-9">
                  <div className="max-w-md">
                    <BarChart3 className="h-5 w-5 text-teal" strokeWidth={1.4} aria-hidden="true" />
                    <h3 className="mt-6 font-display text-3xl text-ink">Learning grounded in evidence</h3>
                    <p className="mt-3 text-sm leading-7 text-secondary">
                      Verified platform insights can reveal successful patterns and inform future recommendations. Until then, Serein shows an empty state—not invented charts.
                    </p>
                  </div>
                  <div className="relative min-h-32 min-w-48 overflow-hidden rounded-xl border border-dashed border-sage/40 bg-pale/50 p-4" aria-label="No analytics data available">
                    <div className="fine-grid absolute inset-0 opacity-70" aria-hidden="true" />
                    <div className="relative flex h-full min-h-24 flex-col items-center justify-center text-center">
                      <BarChart3 className="h-4 w-4 text-sage-dark" strokeWidth={1.4} aria-hidden="true" />
                      <p className="mt-2 text-[0.58rem] font-bold uppercase tracking-[0.12em] text-secondary">Awaiting verified data</p>
                    </div>
                  </div>
                </article>
              </Reveal>
            </div>
          </div>
        </section>

        <AgentFlow />

        <section id="autonomy" className="bg-soft-white py-24 sm:py-32" aria-labelledby="autonomy-title">
          <div className="mx-auto max-w-[1280px] px-5 sm:px-8 lg:px-12">
            <Reveal>
              <div className="mx-auto max-w-3xl text-center">
                <p className="eyebrow justify-center">Autonomy is a dial, not a leap of faith</p>
                <h2 id="autonomy-title" className="mt-6 text-balance font-display text-[clamp(2.8rem,5vw,5rem)] leading-[1] tracking-[-0.04em] text-ink">
                  Decide what the agent<br className="hidden sm:block" /> <span className="italic text-teal">may do without you.</span>
                </h2>
                <p className="mx-auto mt-6 max-w-2xl text-sm leading-7 text-secondary">
                  Start with review everywhere. Introduce trust by category. Set schedules and limits.
                  Pause at any time. Sensitive content and unsupported claims remain subject to additional review.
                </p>
              </div>
            </Reveal>
            <Reveal className="mt-14" delay={0.1}>
              <AutonomyExplorer />
            </Reveal>
          </div>
        </section>

        <section id="platforms" className="border-y border-line bg-pale/65 py-24 sm:py-32" aria-labelledby="platforms-title">
          <div className="mx-auto max-w-[1440px] px-5 sm:px-8 lg:px-12">
            <Reveal>
              <div className="grid gap-8 lg:grid-cols-12 lg:items-end">
                <div className="lg:col-span-8">
                  <p className="eyebrow">Permission-based by design</p>
                  <h2 id="platforms-title" className="mt-6 font-display text-[clamp(2.8rem,4.8vw,4.9rem)] leading-[1] tracking-[-0.04em] text-ink">
                    Your channels.<br /><span className="italic text-teal">Never your passwords.</span>
                  </h2>
                </div>
                <div className="lg:col-span-4">
                  <p className="text-sm leading-7 text-secondary">
                    Serein is being structured around official OAuth, explicit permissions, account eligibility, and each platform’s supported publishing formats.
                  </p>
                  <Badge tone="amber" className="mt-5">Live connections pending Phase 5</Badge>
                </div>
              </div>
            </Reveal>

            <div className="mt-14 grid gap-5 lg:grid-cols-3">
              {platforms.map((platform, index) => {
                const Icon = platform.icon;
                return (
                  <Reveal key={platform.name} delay={index * 0.08}>
                    <article className="group flex h-full flex-col rounded-[1.6rem] border border-line bg-white p-7 transition-all duration-500 hover:-translate-y-1 hover:border-sage/65 sm:p-8">
                      <div className="flex items-center justify-between">
                        <span className="grid h-12 w-12 place-items-center rounded-full border border-line bg-soft-white text-forest">
                          <Icon className="h-5 w-5" strokeWidth={1.45} aria-hidden="true" />
                        </span>
                        <Badge tone="neutral">Not connected</Badge>
                      </div>
                      <h3 className="mt-8 font-display text-3xl text-ink">{platform.name}</h3>
                      <p className="mt-3 text-sm leading-7 text-secondary">{platform.description}</p>
                      <ul className="mt-7 space-y-3">
                        {platform.details.map((detail) => (
                          <li key={detail} className="flex gap-3 text-xs leading-5 text-secondary">
                            <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sage-dark" strokeWidth={1.6} aria-hidden="true" />
                            {detail}
                          </li>
                        ))}
                      </ul>
                      <a
                        href={platform.href}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-auto inline-flex items-center gap-2 pt-8 text-[0.65rem] font-bold uppercase tracking-[0.12em] text-teal hover:text-forest"
                      >
                        Official developer documentation
                        <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden="true" />
                      </a>
                    </article>
                  </Reveal>
                );
              })}
            </div>
            <p className="mt-6 text-xs leading-6 text-secondary">
              Connection status describes the Phase 4 preview. No OAuth or publishing flow is represented as operational before authorization and real publishing tests are complete.
            </p>
          </div>
        </section>

        <section id="plans" className="bg-soft-white py-24 sm:py-32" aria-labelledby="plans-title">
          <div className="mx-auto max-w-[1440px] px-5 sm:px-8 lg:px-12">
            <Reveal>
              <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
                <div className="max-w-3xl">
                  <p className="eyebrow">A model that grows with the work</p>
                  <h2 id="plans-title" className="mt-6 font-display text-[clamp(2.8rem,4.8vw,4.9rem)] leading-[1] tracking-[-0.04em] text-ink">
                    Start small.<br /><span className="italic text-teal">Keep your standards.</span>
                  </h2>
                </div>
                <p className="max-w-sm text-sm leading-7 text-secondary">
                  Four plan shapes support different operating models. Usage allowances will be configurable; payment architecture remains flexible until a gateway is selected.
                </p>
              </div>
            </Reveal>

            <div className="mt-14 grid gap-px overflow-hidden rounded-[1.7rem] border border-line bg-line md:grid-cols-2 xl:grid-cols-4">
              {plans.map((plan, index) => (
                <article key={plan.name} className="flex flex-col bg-white p-7 sm:p-8">
                  <div className="flex items-center justify-between">
                    <span className="text-[0.58rem] font-bold tracking-[0.15em] text-sage-dark">0{index + 1}</span>
                    {index === 0 && <Badge>Free entry</Badge>}
                  </div>
                  <h3 className="mt-8 font-display text-4xl text-ink">{plan.name}</h3>
                  <p className="mt-1 text-[0.62rem] font-bold uppercase tracking-[0.12em] text-teal">{plan.label}</p>
                  <p className="mt-5 min-h-20 text-xs leading-6 text-secondary">{plan.description}</p>
                  <ul className="mt-7 space-y-3 border-t border-line pt-6">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex gap-3 text-xs leading-5 text-secondary">
                        <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sage-dark" strokeWidth={1.6} aria-hidden="true" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <p className="mt-auto pt-8 text-[0.62rem] font-semibold text-forest">
                    {index === 0 ? "Free plan · configured limits" : "Paid plan · pricing not yet configured"}
                  </p>
                </article>
              ))}
            </div>
            <p className="mt-5 text-xs text-secondary">No payment gateway is enabled in Phase 4. No paid usage or unlimited allowance is implied.</p>
          </div>
        </section>

        <section className="bg-forest py-24 text-white sm:py-28" aria-labelledby="security-title">
          <div className="mx-auto max-w-[1280px] px-5 sm:px-8 lg:px-12">
            <Reveal>
              <div className="grid gap-12 lg:grid-cols-12">
                <div className="lg:col-span-5">
                  <p className="eyebrow text-mint before:bg-sage">Trust is architecture</p>
                  <h2 id="security-title" className="mt-6 font-display text-5xl leading-[1] tracking-[-0.035em] sm:text-6xl">
                    Quietly careful<br /><span className="italic text-sage">with what matters.</span>
                  </h2>
                  <p className="mt-6 max-w-md text-sm leading-7 text-white/60">
                    Security requirements are part of the product specification, not a final polish pass. Implementation and tenant-isolation testing belong to Phases 2 and 8.
                  </p>
                </div>
                <div className="grid gap-8 sm:grid-cols-3 lg:col-span-7">
                  {[
                    { icon: Database, title: "Workspace isolation", text: "Tenant-scoped records and server-side authorization are required before private business data is introduced." },
                    { icon: KeyRound, title: "Protected credentials", text: "Secrets belong in server-side environments, with token expiry, revocation, and encryption where appropriate." },
                    { icon: LockKeyhole, title: "No hidden escalation", text: "Provider fallback must respect eligibility, preserve work, and never authorize paid usage on your behalf." },
                  ].map((item, index) => {
                    const Icon = item.icon;
                    return (
                      <Reveal key={item.title} delay={index * 0.08}>
                        <article className="border-t border-sage/25 pt-6">
                          <Icon className="h-5 w-5 text-sage" strokeWidth={1.4} aria-hidden="true" />
                          <h3 className="mt-5 font-display text-2xl">{item.title}</h3>
                          <p className="mt-3 text-xs leading-6 text-white/55">{item.text}</p>
                        </article>
                      </Reveal>
                    );
                  })}
                </div>
              </div>
            </Reveal>
          </div>
        </section>

        <section className="bg-soft-white py-24 sm:py-32" aria-labelledby="faq-title">
          <div className="mx-auto grid max-w-[1280px] gap-12 px-5 sm:px-8 lg:grid-cols-12 lg:px-12">
            <Reveal className="lg:col-span-4">
              <div className="lg:sticky lg:top-32">
                <p className="eyebrow">Clear answers</p>
                <h2 id="faq-title" className="mt-6 font-display text-5xl leading-[1] tracking-[-0.035em] text-ink">
                  Before you<br /><span className="italic text-teal">hand over the reins.</span>
                </h2>
                <p className="mt-5 max-w-xs text-sm leading-7 text-secondary">
                  A few important details about autonomy, integrations, evidence, and the current product preview.
                </p>
              </div>
            </Reveal>
            <Reveal className="lg:col-span-8" delay={0.08}>
              <FAQ />
            </Reveal>
          </div>
        </section>

        <section className="px-5 pb-6 sm:px-8 sm:pb-8 lg:px-12">
          <Reveal>
            <div className="fine-grid relative mx-auto max-w-[1344px] overflow-hidden rounded-[2rem] border border-sage/35 bg-mint/50 px-6 py-20 text-center sm:px-12 sm:py-24">
              <div className="absolute left-1/2 top-1/2 h-[28rem] w-[28rem] -translate-x-1/2 -translate-y-1/2 rounded-full border border-sage/25" aria-hidden="true" />
              <div className="absolute left-1/2 top-1/2 h-[38rem] w-[38rem] -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/60" aria-hidden="true" />
              <div className="relative">
                <p className="text-[0.62rem] font-bold uppercase tracking-[0.18em] text-teal">A calmer way to be everywhere</p>
                <h2 className="mx-auto mt-6 max-w-4xl text-balance font-display text-[clamp(3rem,6vw,6.3rem)] leading-[0.94] tracking-[-0.045em] text-ink">
                  Let your brand<br /><span className="italic text-teal">think ahead.</span>
                </h2>
                <p className="mx-auto mt-6 max-w-lg text-sm leading-7 text-secondary">
                  Step inside the Phase 4 workspace and explore the authenticated foundation for a more thoughtful social operation.
                </p>
                <ButtonLink href="/dashboard" className="mt-8 min-w-52" arrow>
                  Open the product preview
                </ButtonLink>
              </div>
            </div>
          </Reveal>
        </section>
      </main>

      <footer className="bg-soft-white px-5 pb-8 pt-16 sm:px-8 lg:px-12">
        <div className="mx-auto max-w-[1344px]">
          <div className="grid gap-10 border-b border-line pb-12 sm:grid-cols-2 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <Logo />
              <p className="mt-5 max-w-xs text-xs leading-6 text-secondary">
                Autonomous social media management for brands that value context, craft, and control.
              </p>
            </div>
            <div className="lg:col-span-3">
              <p className="text-[0.6rem] font-bold uppercase tracking-[0.15em] text-forest">Explore</p>
              <div className="mt-5 flex flex-col items-start gap-3 text-xs text-secondary">
                <a href="#product" className="hover:text-teal">Product</a>
                <a href="#agent" className="hover:text-teal">The agent</a>
                <a href="#autonomy" className="hover:text-teal">Autonomy</a>
                <a href="#plans" className="hover:text-teal">Plan architecture</a>
              </div>
            </div>
            <div className="lg:col-span-4">
              <p className="text-[0.6rem] font-bold uppercase tracking-[0.15em] text-forest">Product preview</p>
              <p className="mt-5 max-w-sm text-xs leading-6 text-secondary">
                Phase 4 includes saved drafts, editable AI suggestions, uploaded media, branded PNG/carousel exports, review history and calendar plans. Stock search awaits its optional key; social publishing, verified analytics and billing are not active.
              </p>
              <ButtonLink href="/dashboard/integrations" variant="ghost" className="mt-4 -ml-4">
                View integration readiness <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
              </ButtonLink>
            </div>
          </div>
          <div className="flex flex-col gap-4 pt-7 text-[0.6rem] font-semibold uppercase tracking-[0.12em] text-secondary sm:flex-row sm:items-center sm:justify-between">
            <p>© {new Date().getFullYear()} Serein · Foundation preview</p>
            <div className="flex items-center gap-5">
              <span>Instagram</span><span>Facebook</span><span>LinkedIn</span>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}
