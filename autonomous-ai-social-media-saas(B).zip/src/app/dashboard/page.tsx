import Link from "next/link";
import {
  ArrowUpRight,
  Building2,
  CalendarDays,
  Check,
  CirclePause,
  Compass,
  Cpu,
  History,
  KeyRound,
  PlugZap,
  ShieldCheck,
} from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { Panel } from "@/components/ui/panel";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/empty-state";
import { ButtonLink } from "@/components/ui/button";

const setupSteps = [
  {
    title: "Create your private workspace",
    description: "Authentication, membership, and tenant-scoped persistence.",
    phase: "Available",
    href: "/dashboard/businesses",
    icon: KeyRound,
  },
  {
    title: "Add your first business",
    description: "Profile, website, offers, audience, and objectives.",
    phase: "Available",
    href: "/dashboard/businesses",
    icon: Building2,
  },
  {
    title: "Shape a strategy and brand voice",
    description: "Brand profile, website extraction, research, and strategy drafts.",
    phase: "Phase 3",
    href: "/dashboard/strategy",
    icon: Compass,
  },
  {
    title: "Configure AI and research providers",
    description: "Free-tier keys, health checks, fallback, and usage tracking.",
    phase: "Inspect AI Engine",
    href: "/dashboard/ai",
    icon: Cpu,
  },
  {
    title: "Connect a social account",
    description: "Official OAuth, permissions, and verified account eligibility.",
    phase: "Phase 5",
    href: "/dashboard/integrations",
    icon: PlugZap,
  },
];

export default function DashboardOverview() {
  return (
    <>
      <PageHeader
        eyebrow="Workspace overview"
        title="Your social operation, in one calm place."
        description="Phase 4 adds saved content drafts, AI suggestions, image uploads, brand templates, revision history, human review and calendar plans. Live provider outcomes stay inspectable in AI Engine; social publishing is not connected."
        status="Phase 4 preview"
      >
        <ButtonLink href="/dashboard/ai" variant="secondary" arrow>
          AI Engine
        </ButtonLink>
      </PageHeader>

      <div className="grid gap-5 xl:grid-cols-[1.65fr_0.85fr]">
        <Panel className="p-6 sm:p-7">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="eyebrow">What is live now</p>
              <h2 className="mt-3 font-display text-3xl text-ink">Your setup path</h2>
              <p className="mt-2 max-w-lg text-xs leading-6 text-secondary">
                Business and brand profiles persist real data. Inspect the AI Engine for current provider configuration, credential probes, actual generation outcomes, and recorded usage.
              </p>
            </div>
            <Badge tone="neutral">0 connected accounts</Badge>
          </div>
          <div className="mt-7 divide-y divide-line border-y border-line">
            {setupSteps.map((step, index) => {
              const Icon = step.icon;
              return (
                <Link key={step.title} href={step.href} className="group flex items-center gap-4 py-5 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-teal">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-line bg-pale text-sage-dark transition-colors group-hover:border-sage/50 group-hover:text-teal">
                    <Icon className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-xs font-semibold text-ink">{step.title}</h3>
                      <span className="text-[0.55rem] font-semibold uppercase tracking-[0.1em] text-sage-dark">{step.phase}</span>
                    </div>
                    <p className="mt-1 text-[0.66rem] leading-5 text-secondary">{step.description}</p>
                  </div>
                  <span className="hidden text-[0.56rem] font-bold text-sage-dark sm:inline">0{index + 1}</span>
                  <ArrowUpRight className="h-4 w-4 shrink-0 text-sage transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-teal" aria-hidden="true" />
                </Link>
              );
            })}
          </div>
        </Panel>

        <Panel className="relative overflow-hidden bg-forest p-6 text-white sm:p-7">
          <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full border border-sage/15" aria-hidden="true" />
          <div className="relative">
            <div className="flex items-center justify-between">
              <span className="grid h-10 w-10 place-items-center rounded-full border border-sage/25 bg-white/5 text-mint">
                <CirclePause className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
              </span>
              <Badge className="border-white/10 bg-white/5 text-mint">Safe default</Badge>
            </div>
            <p className="mt-7 text-[0.58rem] font-bold uppercase tracking-[0.15em] text-sage">Autonomous agent</p>
            <h2 className="mt-2 font-display text-4xl">Standing by.</h2>
            <p className="mt-4 text-xs leading-6 text-white/60">
              No autonomous publishing worker exists yet. Strategy generation runs only when requested, and every task is stored, reviewable, and resumable.
            </p>
            <div className="mt-7 space-y-3 border-t border-white/10 pt-5">
              {["No publishing jobs created", "Provider API keys stay server-side", "Paused work is preserved, not discarded"].map((item) => (
                <div key={item} className="flex items-center gap-3 text-[0.67rem] text-white/70">
                  <Check className="h-3.5 w-3.5 text-sage" strokeWidth={1.5} aria-hidden="true" />
                  {item}
                </div>
              ))}
            </div>
          </div>
        </Panel>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Panel className="p-5 sm:p-6">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <p className="text-[0.6rem] font-bold uppercase tracking-[0.14em] text-teal">Coming up</p>
              <h2 className="mt-2 font-display text-2xl text-ink">Content calendar</h2>
            </div>
            <ButtonLink href="/dashboard/calendar" variant="ghost" className="min-h-9 px-3 text-[0.66rem]">Open calendar</ButtonLink>
          </div>
          <EmptyState icon={CalendarDays} title="A deliberate publishing plan" description="Review and approve content in the Studio, then save its intended time. Open the calendar to inspect actual records; this overview does not invent counts or assume an empty schedule." className="min-h-56 py-8" />
        </Panel>

        <Panel className="p-5 sm:p-6">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <p className="text-[0.6rem] font-bold uppercase tracking-[0.14em] text-teal">A truthful record</p>
              <h2 className="mt-2 font-display text-2xl text-ink">Agent tasks</h2>
            </div>
            <Badge tone="neutral">No events until requested</Badge>
          </div>
          <EmptyState icon={History} title="Inspect the recorded work" description="Strategy runs, Studio generations, provider fallbacks, paused tasks and resumptions are recorded in AI Engine. Open that view for actual events rather than illustrative activity." className="min-h-56 py-8" />
        </Panel>
      </div>

      <Panel className="mt-5 flex flex-col gap-5 p-6 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex gap-4">
          <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-teal" strokeWidth={1.4} aria-hidden="true" />
          <div>
            <h2 className="text-xs font-semibold text-ink">Trust is enforced at the data boundary</h2>
            <p className="mt-1 max-w-2xl text-[0.67rem] leading-5 text-secondary">
              Protected Phase 3/4 routes validate the session and workspace membership directly. Brand, research, strategy, task, usage, and notification records are filtered by workspace. Basic tenant-isolation regression checks have run; a comprehensive security audit remains a launch requirement.
            </p>
          </div>
        </div>
      </Panel>
    </>
  );
}
