import { Globe2, LockKeyhole, Target, Users } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { Panel } from "@/components/ui/panel";
import { BusinessManager } from "@/components/dashboard/business-manager";

const profileAreas = [
  { icon: Globe2, title: "Business context", text: "Website, products, services, industry, location, and the objectives that should guide content decisions." },
  { icon: Users, title: "Audience definition", text: "Priority segments, needs, questions, objections, and the language each audience actually uses." },
  { icon: Target, title: "Individual strategy", text: "Business-specific pillars, channel roles, formats, frequency, campaigns, and seasonal opportunities." },
  { icon: LockKeyhole, title: "Separated operations", text: "Dedicated brand profiles, social connections, content, publishing history, and verified performance data." },
];

export default function BusinessesPage() {
  return (
    <>
      <PageHeader
        eyebrow="Business profiles"
        title="A separate world for every brand."
        description="Business records are persisted in PostgreSQL and scoped to your active workspace. Each business can have its own brand profile, website analysis, research, strategies, and later its own accounts and analytics."
        status="Persistence active"
      />

      <BusinessManager />

      <div className="mt-10">
        <p className="eyebrow">Profile architecture</p>
        <h2 className="mt-3 font-display text-3xl text-ink">More than a name and logo</h2>
        <div className="mt-5 grid gap-px overflow-hidden rounded-[1.4rem] border border-line bg-line md:grid-cols-2 xl:grid-cols-4">
          {profileAreas.map((area) => {
            const Icon = area.icon;
            return (
              <Panel key={area.title} className="rounded-none border-0 p-6">
                <Icon className="h-5 w-5 text-teal" strokeWidth={1.4} aria-hidden="true" />
                <h3 className="mt-5 font-display text-2xl text-ink">{area.title}</h3>
                <p className="mt-3 text-xs leading-6 text-secondary">{area.text}</p>
              </Panel>
            );
          })}
        </div>
      </div>

      <Panel className="mt-5 border-sage/35 bg-mint/35 p-6">
        <p className="text-[0.6rem] font-bold uppercase tracking-[0.14em] text-teal">Tenant boundary</p>
        <p className="mt-3 max-w-4xl text-xs leading-6 text-secondary">
          Every Phase 3 route validates the session directly from the request cookie and database session record, then checks workspace membership before any read or write. Business, brand, research, strategy, task, usage, and notification queries all filter by the active workspace ID. Dedicated automated tenant-isolation tests remain scheduled for Phase 8.
        </p>
      </Panel>
    </>
  );
}
