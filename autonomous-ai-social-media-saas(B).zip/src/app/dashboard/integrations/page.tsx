import type { ComponentType } from "react";
import { ArrowUpRight, Bot, Images, KeyRound, Search, ShieldCheck } from "lucide-react";
import { FacebookIcon, InstagramIcon, LinkedInIcon } from "@/components/brand/social-icons";
import { PageHeader } from "@/components/ui/page-header";
import { Panel } from "@/components/ui/panel";
import { Badge } from "@/components/ui/badge";
import { ButtonLink } from "@/components/ui/button";

export const dynamic = "force-dynamic";

const integrations: Array<{
  name: string;
  category: string;
  phase: string;
  envVar?: string;
  description: string;
  requirement: string;
  docs: string;
  icon: ComponentType<{ className?: string }>;
}> = [
  {
    name: "Instagram", category: "Social publishing", phase: "Phase 5",
    description: "Official authorization and supported publishing for eligible professional accounts. OAuth is not implemented yet.",
    requirement: "Meta developer app, professional account, publishing permissions, app review where required, and verified publishing tests.",
    docs: "https://developers.facebook.com/docs/instagram-platform/", icon: InstagramIcon,
  },
  {
    name: "Facebook Pages", category: "Social publishing", phase: "Phase 5",
    description: "Authorized Page management without requesting a customer's Facebook password. OAuth is not implemented yet.",
    requirement: "Meta developer app, Page access, required permissions, token lifecycle handling, and applicable app review.",
    docs: "https://developers.facebook.com/docs/pages-api/", icon: FacebookIcon,
  },
  {
    name: "LinkedIn", category: "Social publishing", phase: "Phase 5",
    description: "Member or organization publishing where approved LinkedIn products and account roles allow it. OAuth is not implemented yet.",
    requirement: "LinkedIn developer app, approved API products, OAuth scopes, eligible roles, and a real publishing test.",
    docs: "https://learn.microsoft.com/en-us/linkedin/marketing/", icon: LinkedInIcon,
  },
  {
    name: "Gemini", category: "AI provider", phase: "Phase 3", envVar: "GEMINI_API_KEY",
    description: "Primary AI adapter for business interpretation and strategy drafts, with eligible backup fallback on provider failures.",
    requirement: "Server-side key, supported model and project quota. A credential probe alone does not prove generation is available; inspect actual task outcomes in AI Engine.",
    docs: "https://ai.google.dev/gemini-api/docs", icon: Bot,
  },
  {
    name: "Groq", category: "AI provider", phase: "Phase 3", envVar: "GROQ_API_KEY",
    description: "An independent AI provider that can serve as primary or backup through the same task interface.",
    requirement: "Server-side key, supported model, organization quota, and successful structured-output generation. The Free Plan is distinct from the paid Developer plan.",
    docs: "https://console.groq.com/docs/overview", icon: Bot,
  },
  {
    name: "Tavily", category: "Research provider", phase: "Phase 3", envVar: "TAVILY_API_KEY",
    description: "Basic web search that preserves returned source titles, URLs, snippets, and provider provenance.",
    requirement: "Server-side key and remaining credits. Basic Search has a documented cost of one credit; search results are not treated as verified factual claims.",
    docs: "https://docs.tavily.com/", icon: Search,
  },
  {
    name: "Unsplash", category: "Optional stock photo provider", phase: "Phase 4", envVar: "UNSPLASH_ACCESS_KEY",
    description: "Stock search and credited linked-photo selection are implemented, but live use is pending its Access Key and real provider testing.",
    requirement: "Free Demo app (50 JSON requests/hour), production approval for 1,000/hour, required hotlinking, photographer/Unsplash attribution, and download tracking. No user OAuth or Secret Key is needed for public photo search.",
    docs: "https://unsplash.com/documentation", icon: Images,
  },
  {
    name: "Pexels", category: "Media provider candidate", phase: "Phase 4",
    description: "Not selected for the initial Studio adapter: the current API homepage says new API key issuance is paused. Manual uploads and local graphic exports remain available.",
    requirement: "Recheck the official API homepage before planning on a new key. Existing keys and rate-limit eligibility are separate; no working Pexels connection is claimed.",
    docs: "https://www.pexels.com/api/documentation/", icon: Images,
  },
];

export default function IntegrationsPage() {
  const presentKeys = integrations.filter((item) => item.phase === "Phase 3" && item.envVar && Boolean(process.env[item.envVar])).length;

  return (
    <>
      <PageHeader
        eyebrow="Integration Center"
        title="Every connection, explicit and inspectable."
        description="Provider credentials stay in server-side environment variables. Key presence below is not a health or generation claim; inspect current probes, task outcomes, and usage in the AI Engine. Social publishing is still pending Phase 5."
        status="Runtime configuration"
      >
        <ButtonLink href="/dashboard/ai" variant="secondary" arrow>Open AI Engine</ButtonLink>
      </PageHeader>

      <Panel className="mb-8 flex flex-col gap-5 border-sage/35 bg-mint/35 p-6 sm:flex-row sm:items-center">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-sage/35 bg-white/55 text-forest">
          <KeyRound className="h-5 w-5" strokeWidth={1.4} aria-hidden="true" />
        </span>
        <div className="flex-1">
          <div className="flex flex-wrap items-center gap-3">
            <h2 className="font-display text-2xl text-ink">{presentKeys} of 3 Phase 3 provider keys present</h2>
            <Badge tone={presentKeys === 3 ? "sage" : "amber"}>{presentKeys === 3 ? "Keys configured" : "Setup incomplete"}</Badge>
          </div>
          <p className="mt-2 max-w-4xl text-xs leading-6 text-secondary">
            Gemini and Groq handle model requests; Tavily handles basic search. OpenAI and Brave remain optional paid/metered providers and are not needed for these tests. Keep paid-provider authorization off unless you explicitly intend to permit charges. Health probes do not consume a generation request or verify every operation.
          </p>
        </div>
      </Panel>

      <div className="grid gap-5 xl:grid-cols-2">
        {integrations.map((integration) => {
          const Icon = integration.icon;
          const hasKey = Boolean(integration.envVar && process.env[integration.envVar]);
          return (
            <Panel key={integration.name} className="flex flex-col p-6 sm:p-7">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-4">
                  <span className="grid h-11 w-11 place-items-center rounded-full border border-line bg-pale text-forest"><Icon className="h-5 w-5" /></span>
                  <div>
                    <p className="text-[0.55rem] font-bold uppercase tracking-[0.13em] text-sage-dark">{integration.category}</p>
                    <h2 className="mt-1 font-display text-2xl text-ink">{integration.name}</h2>
                  </div>
                </div>
                <Badge tone={hasKey ? "sage" : "neutral"}>{hasKey ? "Key present" : integration.envVar ? "Key missing" : "Not implemented"}</Badge>
              </div>
              <p className="mt-5 text-xs leading-6 text-secondary">{integration.description}</p>
              <div className="mt-5 rounded-xl bg-pale/65 p-4">
                <p className="text-[0.56rem] font-bold uppercase tracking-[0.12em] text-teal">Requirements · {integration.phase}</p>
                <p className="mt-2 text-[0.66rem] leading-5 text-secondary">{integration.requirement}</p>
              </div>
              <a href={integration.docs} target="_blank" rel="noreferrer" className="mt-auto inline-flex items-center gap-2 pt-6 text-[0.62rem] font-bold uppercase tracking-[0.11em] text-teal hover:text-forest">
                Official documentation <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
              </a>
            </Panel>
          );
        })}
      </div>

      <Panel className="mt-5 flex gap-4 p-6">
        <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-teal" strokeWidth={1.4} aria-hidden="true" />
        <div>
          <h2 className="text-xs font-semibold text-ink">Provider key values are never displayed</h2>
          <p className="mt-2 max-w-5xl text-[0.68rem] leading-6 text-secondary">
            This page reports only whether a key is present. Environment variable values remain on the server. Review docs/PHASE-3.md for AI requirements and docs/PHASE-4.md for media setup, readiness limits, and current test results.
          </p>
        </div>
      </Panel>
    </>
  );
}
