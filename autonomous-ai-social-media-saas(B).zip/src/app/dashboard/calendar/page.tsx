import { CalendarBoard } from "@/components/dashboard/calendar-board";
import { PageHeader } from "@/components/ui/page-header";
import { ButtonLink } from "@/components/ui/button";

export default function CalendarPage() {
  return <><PageHeader eyebrow="Content calendar · Phase 4" title="Make room for the right moment." description="Actual approved draft schedules, separated by business and shown in your chosen time zone. These are saved editorial plans; social authorization and publishing workers arrive in Phases 5 and 6." status="Saved plans"><ButtonLink href="/dashboard/studio" arrow>Open Content Studio</ButtonLink></PageHeader><CalendarBoard /></>;
}
