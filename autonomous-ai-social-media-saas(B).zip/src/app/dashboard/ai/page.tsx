import { PageHeader } from "@/components/ui/page-header";
import { AIEngine } from "@/components/dashboard/ai-engine";

export default function AIEnginePage() {
  return (
    <>
      <PageHeader
        eyebrow="AI engine"
        title="Fallback without guesswork."
        description="Inspect provider eligibility, health, quota cooldowns, recorded usage, paused tasks, and interruption notifications. Free providers are tried first; paid providers require explicit authorization; work is preserved when all eligible providers are unavailable."
        status="Hybrid architecture active"
      />
      <AIEngine />
    </>
  );
}
