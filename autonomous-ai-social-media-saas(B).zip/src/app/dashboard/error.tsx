"use client";

import { AlertCircle, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function DashboardError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="flex min-h-[65vh] items-center justify-center">
      <div className="max-w-md text-center" role="alert">
        <span className="mx-auto grid h-14 w-14 place-items-center rounded-full border border-[#dfcfb6] bg-[#f7f2e8] text-[#735c32]">
          <AlertCircle className="h-5 w-5" strokeWidth={1.5} aria-hidden="true" />
        </span>
        <h1 className="mt-6 font-display text-3xl text-ink">The workspace could not be displayed.</h1>
        <p className="mt-3 text-sm leading-6 text-secondary">
          No account action was taken. Try rendering this view again; if the problem continues, review the application error log.
        </p>
        <Button type="button" onClick={reset} className="mt-6">
          <RotateCcw className="h-4 w-4" aria-hidden="true" />
          Try again
        </Button>
      </div>
    </div>
  );
}
