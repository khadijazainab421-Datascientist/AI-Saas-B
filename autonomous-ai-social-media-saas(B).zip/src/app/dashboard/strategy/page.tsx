import { PageHeader } from "@/components/ui/page-header";
import { StrategyWorkspace } from "@/components/dashboard/strategy-workspace";

export default function StrategyPage() {
  return (
    <>
      <PageHeader
        eyebrow="Content strategy"
        title="Give every post a reason to exist."
        description="Configure a brand profile, extract the business website, collect attributed research, and run an evidence-bounded strategy task. AI generation requires an eligible configured provider; otherwise the task is paused with its work preserved."
        status="Engine structure active"
      />
      <StrategyWorkspace />
    </>
  );
}
