import { BarChart3, Eye, MousePointer2, TrendingUp } from "lucide-react";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { Panel } from "@/components/ui/panel";
import { Badge } from "@/components/ui/badge";

const measures = [
  { icon: Eye, title: "Reach and exposure", text: "Platform-defined reach, impressions, and audience measures, labeled with their source and reporting period." },
  { icon: MousePointer2, title: "Response and action", text: "Available interactions, clicks, saves, shares, and other supported signals without combining incompatible definitions." },
  { icon: TrendingUp, title: "Patterns over time", text: "Comparisons only where enough verified data exists, with platform limitations and missing intervals made visible." },
];

export default function AnalyticsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Performance intelligence"
        title="Evidence before conclusions."
        description="Analytics will be separated by business and social account, sourced from supported platform insights, and used to inform recommendations. No illustrative numbers are presented as account performance."
        status="Verified data only"
      >
        <Badge tone="neutral">No data sources</Badge>
      </PageHeader>

      <Panel className="p-5 sm:p-6">
        <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-[0.6rem] font-bold uppercase tracking-[0.14em] text-teal">Performance overview</p>
            <h2 className="mt-2 font-display text-2xl text-ink">Awaiting a verified source</h2>
          </div>
          <Badge tone="neutral">All businesses · All channels</Badge>
        </div>
        <div className="fine-grid rounded-[1.25rem] border border-line bg-pale/35 p-3 sm:p-5">
          <EmptyState
            icon={BarChart3}
            title="No performance data to chart"
            description="Connect an eligible social account in Phase 5 and ingest supported insights in Phase 7 to populate this view. Until then, there are no values, trends, comparisons, or recommendations to report."
            className="min-h-[23rem] border-0 bg-soft-white/80"
          />
        </div>
      </Panel>

      <div className="mt-5 grid gap-5 md:grid-cols-3">
        {measures.map((measure) => {
          const Icon = measure.icon;
          return (
            <Panel key={measure.title} className="p-6">
              <Icon className="h-5 w-5 text-teal" strokeWidth={1.4} aria-hidden="true" />
              <h2 className="mt-5 font-display text-2xl text-ink">{measure.title}</h2>
              <p className="mt-3 text-xs leading-6 text-secondary">{measure.text}</p>
            </Panel>
          );
        })}
      </div>

      <Panel className="mt-5 bg-forest p-6 text-white sm:p-7">
        <p className="text-[0.58rem] font-bold uppercase tracking-[0.14em] text-sage">The learning boundary</p>
        <h2 className="mt-3 max-w-xl font-display text-3xl leading-tight">A pattern is a prompt for investigation, not proof of causation.</h2>
        <p className="mt-4 max-w-4xl text-xs leading-6 text-white/60">
          The autonomous agent may use real performance data to identify recurring patterns and recommend changes. It should retain the underlying evidence, acknowledge platform limitations, and avoid presenting correlation as a guaranteed outcome.
        </p>
      </Panel>
    </>
  );
}
