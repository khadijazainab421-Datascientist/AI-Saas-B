import { Suspense } from "react";
import type { Metadata } from "next";
import { ContentStudio } from "@/components/studio/content-studio";
import { DashboardSkeleton } from "@/components/ui/skeleton";

export const metadata: Metadata = { title: "Content studio" };
export default function StudioPage() {
  return <Suspense fallback={<DashboardSkeleton />}><ContentStudio /></Suspense>;
}
