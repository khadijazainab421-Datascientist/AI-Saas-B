import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { DM_Serif_Display, Manrope } from "next/font/google";
import "./globals.css";

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
  display: "swap",
});

const dmSerif = DM_Serif_Display({
  subsets: ["latin"],
  weight: "400",
  style: ["normal", "italic"],
  variable: "--font-dm-serif",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Serein — Social media, thoughtfully autonomous",
    template: "%s · Serein",
  },
  description:
    "A calm, intelligent workspace for researching, planning, creating, and managing social media with an AI agent under your direction.",
};

export const viewport: Viewport = {
  themeColor: "#FAFCFB",
  colorScheme: "light",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${manrope.variable} ${dmSerif.variable}`}>
      <body className="bg-soft-white font-sans text-ink antialiased">{children}</body>
    </html>
  );
}
