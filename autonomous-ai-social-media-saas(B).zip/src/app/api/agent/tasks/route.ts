import { NextResponse, type NextRequest } from "next/server";
import { eq, and, desc } from "drizzle-orm";
import { db } from "@/db";
import { aiTasks } from "@/db/schema";
import { requireTenant } from "@/lib/tenant";
import { resumePausedTasks } from "@/lib/ai/orchestrator";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;
  const tasks = await db
    .select()
    .from(aiTasks)
    .where(eq(aiTasks.workspaceId, auth.context.workspaceId))
    .orderBy(desc(aiTasks.createdAt))
    .limit(50);
  return NextResponse.json({ tasks });
}

export async function POST(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;

  let body: { taskId?: unknown } = {};
  try {
    body = (await request.json()) as { taskId?: unknown };
  } catch {
    // An empty body means "resume all eligible paused tasks".
  }
  const taskId = typeof body.taskId === "number" ? body.taskId : undefined;

  if (taskId) {
    const [task] = await db
      .select()
      .from(aiTasks)
      .where(and(eq(aiTasks.id, taskId), eq(aiTasks.workspaceId, auth.context.workspaceId)))
      .limit(1);
    if (!task) return NextResponse.json({ error: "Task not found in this workspace" }, { status: 404 });
  }

  const results = await resumePausedTasks(
    auth.context.workspaceId,
    auth.context.userId,
    taskId,
  );
  return NextResponse.json({ results });
}
