import { NextResponse, type NextRequest } from "next/server";
import { eq, and } from "drizzle-orm";
import { db } from "@/db";
import { businesses, workspaceSettings } from "@/db/schema";
import { requireTenant } from "@/lib/tenant";
import { analyzeWebsite, getWebsiteAnalyses } from "@/lib/research/engine";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;
  const raw = request.nextUrl.searchParams.get("businessId");
  const businessId = raw ? Number(raw) : null;
  const analyses = await getWebsiteAnalyses(auth.context.workspaceId, businessId);
  return NextResponse.json({ analyses });
}

export async function POST(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const businessId = Number(body.businessId);
  const url = typeof body.url === "string" ? body.url.trim() : "";
  if (!businessId || !url) {
    return NextResponse.json({ error: "businessId and url are required" }, { status: 400 });
  }
  if (!/^https?:\/\//i.test(url)) {
    return NextResponse.json({ error: "Include https:// or http:// in the URL" }, { status: 400 });
  }

  const [business] = await db
    .select()
    .from(businesses)
    .where(and(eq(businesses.id, businessId), eq(businesses.workspaceId, auth.context.workspaceId)))
    .limit(1);
  if (!business) {
    return NextResponse.json({ error: "Business not found in this workspace" }, { status: 404 });
  }

  const [settings] = await db
    .select()
    .from(workspaceSettings)
    .where(eq(workspaceSettings.workspaceId, auth.context.workspaceId))
    .limit(1);

  const result = await analyzeWebsite({
    workspaceId: auth.context.workspaceId,
    userId: auth.context.userId,
    businessId,
    url,
    allowPaid: settings?.allowPaidProviders ?? false,
  });
  return NextResponse.json(result, { status: result.aiStatus === "not_attempted" ? 422 : 200 });
}
