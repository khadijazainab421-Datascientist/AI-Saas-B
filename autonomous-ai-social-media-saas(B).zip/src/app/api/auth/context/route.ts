import { NextResponse, type NextRequest } from "next/server";
import { standalonePreviewOrigin } from "@/lib/preview-origin";
import { previewSessionsEnabled, PREVIEW_SESSION_TTL_SECONDS } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Public capability/routing metadata only; never user data or an authenticated token. */
export function GET(request: NextRequest) {
  return NextResponse.json({
    application: "serein",
    standaloneOrigin: standalonePreviewOrigin(request.headers),
    previewSessionAvailable: previewSessionsEnabled(),
    previewSessionMaxAgeSeconds: PREVIEW_SESSION_TTL_SECONDS,
  }, { headers: { "Cache-Control": "private, no-store", "X-Serein-Application": "serein" } });
}
