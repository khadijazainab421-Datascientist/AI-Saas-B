import type { NextRequest } from "next/server";
import { revokeSession } from "@/lib/auth-server";
import { hashSessionToken, requestSessionToken } from "@/lib/auth";
import { authError, authResponse, clearSessionCookie, originError } from "@/lib/auth-http";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const rejected = originError(request);
  if (rejected) return rejected;
  try {
    const token = requestSessionToken(request);
    if (token) await revokeSession(hashSessionToken(token));
    return clearSessionCookie(request, authResponse(request, { ok: true }));
  } catch {
    return clearSessionCookie(request, authError("The browser cookie was cleared, but server-side sign-out could not be confirmed. Please retry.", 503, "LOGOUT_UNCONFIRMED"));
  }
}
