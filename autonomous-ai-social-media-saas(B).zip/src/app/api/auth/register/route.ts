import { findUserByEmail, normalizeEmail, registerWithWorkspace } from "@/lib/auth-server";
import { authBody, authError, authResponse, databaseErrorCode, originError } from "@/lib/auth-http";
import { previewSessionsEnabled } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const rejected = originError(request);
  if (rejected) return rejected;
  const body = await authBody(request);
  const email = typeof body?.email === "string" ? normalizeEmail(body.email) : "";
  const password = typeof body?.password === "string" ? body.password : "";
  const name = typeof body?.name === "string" ? body.name.trim() : "";
  const requestedWorkspace = typeof body?.workspaceName === "string" ? body.workspaceName.trim() : "";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return authError("Enter a valid email address.", 400, "INVALID_INPUT");
  }
  if (password.length < 8 || Buffer.byteLength(password, "utf8") > 72) {
    return authError("Use a password of at least 8 characters and no more than 72 UTF-8 bytes.", 400, "INVALID_INPUT");
  }
  if (!name || name.length > 100 || requestedWorkspace.length > 120) {
    return authError("Enter your name (up to 100 characters) and a workspace name up to 120 characters.", 400, "INVALID_INPUT");
  }
  try {
    if (await findUserByEmail(email)) {
      return authError("An account with this email already exists. Sign in instead of creating it again.", 409, "ACCOUNT_EXISTS");
    }
    const result = await registerWithWorkspace({ email, password, name, workspaceName: requestedWorkspace || `${name}'s workspace` });
    return authResponse(request, {
      user: { id: result.user.id, email: result.user.email, name: result.user.name },
      workspace: { id: result.workspace.id, name: result.workspace.name, slug: result.workspace.slug },
      expiresAt: result.expiresAt,
      sessionTransport: "cookie",
      previewSessionAvailable: previewSessionsEnabled(),
    }, result.token, 201);
  } catch (error) {
    if (databaseErrorCode(error) === "23505") {
      return authError("An account with this email already exists. Please sign in.", 409, "ACCOUNT_EXISTS");
    }
    return authError("Registration could not be completed. Please retry; no partial registration was saved.", 503, "AUTH_UNAVAILABLE");
  }
}
