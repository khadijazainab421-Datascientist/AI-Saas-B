import { verifyPassword, findUserByEmail, createSessionAndToken, firstWorkspaceForUser, normalizeEmail } from "@/lib/auth-server";
import { authBody, authError, authResponse, originError } from "@/lib/auth-http";
import { previewSessionsEnabled } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const rejected = originError(request);
  if (rejected) return rejected;
  const body = await authBody(request);
  const email = typeof body?.email === "string" ? normalizeEmail(body.email) : "";
  const password = typeof body?.password === "string" ? body.password : "";
  const previewRequested = body?.sessionTransport === "preview";
  if (previewRequested && (!previewSessionsEnabled() || request.headers.get("x-serein-preview-fallback") !== "1")) {
    return authError("Cookie-free preview sessions are not enabled for this deployment.", 403, "PREVIEW_SESSION_DISABLED");
  }
  if (!email || email.length > 254 || !password || password.length > 1024) {
    return authError("Enter your account email and password.", 400, "INVALID_INPUT");
  }
  try {
    const user = await findUserByEmail(email);
    if (!user || !(await verifyPassword(password, user.passwordHash))) {
      return authError("Email or password is incorrect. Use the credentials from Serein's Create your workspace form.", 401, "INVALID_CREDENTIALS");
    }
    const workspaceId = await firstWorkspaceForUser(user.id);
    const { token, expiresAt } = await createSessionAndToken(user.id, workspaceId, undefined, { transport: previewRequested ? "preview" : "cookie" });
    return authResponse(request, {
      user: { id: user.id, email: user.email, name: user.name }, workspaceId, expiresAt,
      sessionTransport: previewRequested ? "preview" : "cookie",
      previewSessionAvailable: previewSessionsEnabled(),
    }, token);
  } catch {
    return authError("Sign-in is temporarily unavailable. Please retry; your account has not been removed.", 503, "AUTH_UNAVAILABLE");
  }
}
