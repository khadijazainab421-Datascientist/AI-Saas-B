import type { NextRequest } from "next/server";
import { requireUser } from "@/lib/tenant";
import { getWorkspacesForUser } from "@/lib/auth-server";
import { authError, authResponse } from "@/lib/auth-http";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const auth = await requireUser(request);
  if (!auth.ok) return auth.response;
  try {
    const { user } = auth.session;
    const memberships = await getWorkspacesForUser(user.id);
    return authResponse(request, {
      user: { id: user.id, email: user.email, name: user.name, emailVerified: user.emailVerified, createdAt: user.createdAt },
      activeWorkspaceId: auth.session.workspaceId,
      sessionTransport: auth.session.transport ?? "cookie",
      expiresAt: auth.session.expiresAt,
      workspaces: memberships.map(({ workspace, role }) => ({ id: workspace.id, name: workspace.name, slug: workspace.slug, role })),
    });
  } catch {
    return authError("Workspace information is temporarily unavailable. Please retry.", 503, "WORKSPACE_UNAVAILABLE");
  }
}
