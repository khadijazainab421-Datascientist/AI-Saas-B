import type { NextRequest } from "next/server";
import { getWorkspaceMembership, rotateSessionWorkspace } from "@/lib/auth-server";
import { requireUser } from "@/lib/tenant";
import { authBody, authError, authResponse } from "@/lib/auth-http";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const auth = await requireUser(request);
  if (!auth.ok) return auth.response;
  const body = await authBody(request);
  const workspaceId = body?.workspaceId;
  if (typeof workspaceId !== "number" || !Number.isSafeInteger(workspaceId) || workspaceId < 1) {
    return authError("Choose a valid workspace.", 400, "INVALID_INPUT");
  }
  try {
    if (!(await getWorkspaceMembership(workspaceId, auth.session.user.id))) {
      return authError("You are not a member of this workspace.", 403, "FORBIDDEN");
    }
    const rotated = await rotateSessionWorkspace(auth.session.id, auth.session.user.id, workspaceId, auth.session.transport ?? "cookie");
    if (!rotated) return authError("Your session changed. Please sign in again.", 401, "UNAUTHENTICATED");
    return authResponse(request, { workspaceId, expiresAt: rotated.expiresAt }, rotated.token);
  } catch {
    return authError("Could not switch workspaces. Please retry.", 503, "WORKSPACE_UNAVAILABLE");
  }
}
