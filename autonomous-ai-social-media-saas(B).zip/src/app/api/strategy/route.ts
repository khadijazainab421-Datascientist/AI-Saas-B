import { NextResponse, type NextRequest } from "next/server";
import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { contentStrategies } from "@/db/schema";
import { requireTenant } from "@/lib/tenant";
import { getStrategyContext, generateStrategy } from "@/lib/strategy/generate";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;
  const raw = request.nextUrl.searchParams.get("businessId");
  const businessId = raw ? Number(raw) : null;
  if (businessId) {
    const context = await getStrategyContext(auth.context.workspaceId, businessId);
    if (!context) {
      return NextResponse.json({ error: "Business not found in this workspace" }, { status: 404 });
    }
    return NextResponse.json({ context });
  }
  const strategies = await db
    .select()
    .from(contentStrategies)
    .where(eq(contentStrategies.workspaceId, auth.context.workspaceId))
    .orderBy(desc(contentStrategies.createdAt))
    .limit(30);
  return NextResponse.json({ strategies });
}

export async function POST(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const businessId = Number(body.businessId);
  if (!businessId) {
    return NextResponse.json({ error: "businessId is required" }, { status: 400 });
  }

  const result = await generateStrategy({
    workspaceId: auth.context.workspaceId,
    userId: auth.context.userId,
    businessId,
  });
  return NextResponse.json(result);
}
