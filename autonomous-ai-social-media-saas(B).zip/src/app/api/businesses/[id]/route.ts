import { NextResponse, type NextRequest } from "next/server";
import {
  getBusinessByIdAndWorkspace,
  updateBusiness,
} from "@/lib/auth-server";
import { requireTenant } from "@/lib/tenant";

export const runtime = "nodejs";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;
  const { id } = await params;
  const business = await getBusinessByIdAndWorkspace(Number(id), auth.context.workspaceId);
  if (!business) return NextResponse.json({ error: "Business not found" }, { status: 404 });
  return NextResponse.json({ business });
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;
  const { id } = await params;
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const [updated] = await updateBusiness(Number(id), auth.context.workspaceId, {
    name: typeof body.name === "string" ? body.name : undefined,
    website: typeof body.website === "string" ? body.website : null,
    industry: typeof body.industry === "string" ? body.industry : null,
    description: typeof body.description === "string" ? body.description : null,
    targetAudience: typeof body.targetAudience === "string" ? body.targetAudience : null,
    brandVoice: typeof body.brandVoice === "string" ? body.brandVoice : null,
  });
  if (!updated) return NextResponse.json({ error: "Business not found" }, { status: 404 });
  return NextResponse.json({ business: updated });
}
