import { NextResponse, type NextRequest } from "next/server";
import {
  getBusinessesForWorkspace,
  createBusiness,
} from "@/lib/auth-server";
import { requireTenant } from "@/lib/tenant";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;
  const businesses = await getBusinessesForWorkspace(auth.context.workspaceId);
  return NextResponse.json({ businesses });
}

export async function POST(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const name = typeof body.name === "string" ? body.name.trim() : "";
  if (!name) {
    return NextResponse.json({ error: "Business name is required" }, { status: 400 });
  }

  const [business] = await createBusiness(auth.context.workspaceId, {
    name,
    website: typeof body.website === "string" ? body.website.trim() || null : null,
    industry: typeof body.industry === "string" ? body.industry.trim() || null : null,
    description: typeof body.description === "string" ? body.description.trim() || null : null,
    targetAudience: typeof body.targetAudience === "string" ? body.targetAudience.trim() || null : null,
    brandVoice: typeof body.brandVoice === "string" ? body.brandVoice.trim() || null : null,
  });

  return NextResponse.json({ business }, { status: 201 });
}
