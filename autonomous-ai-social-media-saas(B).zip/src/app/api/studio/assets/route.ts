import { NextResponse, type NextRequest } from "next/server";
import { requireTenant } from "@/lib/tenant";
import { uploadAsset, linkStockAsset } from "@/lib/studio/media";
import { positiveId, studioBody, studioFailure, StudioError } from "@/lib/studio/errors";

export const runtime = "nodejs";
export async function POST(request: NextRequest) {
  const auth = await requireTenant(request); if (!auth.ok) return auth.response;
  try {
    if (request.headers.get("content-type")?.startsWith("multipart/form-data")) return NextResponse.json({ asset: await uploadAsset(auth.context, request) }, { status: 201 });
    const body = await studioBody(request);
    if (typeof body.photoId !== "string") throw new StudioError("Choose a stock photo ID.");
    return NextResponse.json({ asset: await linkStockAsset(auth.context, positiveId(body.businessId, "business"), body.photoId) }, { status: 201 });
  } catch (error) { return studioFailure(error); }
}
