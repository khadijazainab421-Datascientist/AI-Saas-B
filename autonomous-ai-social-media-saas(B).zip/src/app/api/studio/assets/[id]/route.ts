import { NextResponse, type NextRequest } from "next/server";
import { requireTenant } from "@/lib/tenant";
import { ownAsset } from "@/lib/studio/media";
import { positiveId, studioFailure, StudioError } from "@/lib/studio/errors";

export const runtime = "nodejs";
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(request); if (!auth.ok) return auth.response;
  try {
    const asset = await ownAsset(auth.context.workspaceId, positiveId((await params).id));
    if (!asset.body) throw new StudioError("This is a linked stock asset. Use its credited provider URL rather than rehosting the image.", 409);
    return new NextResponse(new Uint8Array(asset.body), { headers: { "Content-Type": asset.mimeType, "Content-Length": String(asset.body.length), "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff", "Content-Security-Policy": "default-src 'none'; sandbox" } });
  } catch (error) { return studioFailure(error); }
}
