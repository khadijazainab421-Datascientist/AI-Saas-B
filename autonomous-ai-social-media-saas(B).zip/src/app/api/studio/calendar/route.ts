import { NextResponse, type NextRequest } from "next/server";
import { requireTenant } from "@/lib/tenant";
import { calendarPosts } from "@/lib/studio/repository";
import { positiveId, studioFailure, StudioError } from "@/lib/studio/errors";

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request); if (!auth.ok) return auth.response;
  try {
    const start = new Date(request.nextUrl.searchParams.get("start") || ""); const end = new Date(request.nextUrl.searchParams.get("end") || "");
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start || end.getTime() - start.getTime() > 64 * 86400000) throw new StudioError("Choose a calendar range of up to 64 days.");
    const business = request.nextUrl.searchParams.get("businessId");
    return NextResponse.json({ posts: await calendarPosts(auth.context, start, end, business ? positiveId(business, "business") : undefined), publishingEnabled: false }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) { return studioFailure(error); }
}
