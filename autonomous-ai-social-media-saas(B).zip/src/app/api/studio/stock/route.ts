import { NextResponse, type NextRequest } from "next/server";
import { requireTenant } from "@/lib/tenant";
import { searchStock } from "@/lib/studio/unsplash";
import { studioFailure } from "@/lib/studio/errors";

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request); if (!auth.ok) return auth.response;
  try { return NextResponse.json(await searchStock(request.nextUrl.searchParams.get("q") || ""), { headers: { "Cache-Control": "private, no-store" } }); }
  catch (error) { return studioFailure(error); }
}
