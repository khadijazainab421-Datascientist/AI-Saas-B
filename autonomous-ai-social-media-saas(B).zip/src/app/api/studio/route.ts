import { NextResponse, type NextRequest } from "next/server";
import { requireTenant } from "@/lib/tenant";
import { studioBootstrap, createDraft, saveBrandStyle } from "@/lib/studio/repository";
import { positiveId, studioBody, studioFailure } from "@/lib/studio/errors";

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request); if (!auth.ok) return auth.response;
  try { const id = request.nextUrl.searchParams.get("businessId"); return NextResponse.json(await studioBootstrap(auth.context, id ? positiveId(id, "business") : undefined), { headers: { "Cache-Control": "private, no-store" } }); }
  catch (error) { return studioFailure(error); }
}
export async function POST(request: NextRequest) {
  const auth = await requireTenant(request); if (!auth.ok) return auth.response;
  try {
    const body = await studioBody(request); const businessId = positiveId(body.businessId, "business");
    if (body.action === "brand_style") return NextResponse.json({ style: await saveBrandStyle(auth.context, businessId, body.style) });
    return NextResponse.json({ post: await createDraft(auth.context, businessId, body.document) }, { status: 201 });
  } catch (error) { return studioFailure(error); }
}
