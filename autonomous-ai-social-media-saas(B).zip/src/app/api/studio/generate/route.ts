import { NextResponse, type NextRequest } from "next/server";
import { requireTenant } from "@/lib/tenant";
import { generateStudio } from "@/lib/studio/generate";
import { positiveId, studioBody, studioFailure, StudioError } from "@/lib/studio/errors";

export const runtime = "nodejs";
export const maxDuration = 120;
export async function POST(request: NextRequest) {
  const auth = await requireTenant(request); if (!auth.ok) return auth.response;
  try {
    const body = await studioBody(request);
    if (typeof body.kind !== "string" || (body.brief !== undefined && typeof body.brief !== "string")) throw new StudioError("Choose a generation type and a text brief.");
    return NextResponse.json(await generateStudio(auth.context, positiveId(body.businessId, "business"), body.kind, body.postId ? positiveId(body.postId, "draft") : undefined, typeof body.brief === "string" ? body.brief.slice(0, 4000) : ""));
  } catch (error) { return studioFailure(error); }
}
