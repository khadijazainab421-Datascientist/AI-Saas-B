import { NextResponse, type NextRequest } from "next/server";
import { requireTenant } from "@/lib/tenant";
import { draftDetail, mutateDraft } from "@/lib/studio/repository";
import { positiveId, studioBody, studioFailure } from "@/lib/studio/errors";

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(request); if (!auth.ok) return auth.response;
  try { return NextResponse.json(await draftDetail(auth.context, positiveId((await params).id)), { headers: { "Cache-Control": "private, no-store" } }); }
  catch (error) { return studioFailure(error); }
}
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(request); if (!auth.ok) return auth.response;
  try { return NextResponse.json(await mutateDraft(auth.context, positiveId((await params).id), await studioBody(request))); }
  catch (error) { return studioFailure(error); }
}
