import { NextResponse, type NextRequest } from "next/server";
import { requireTenant } from "@/lib/tenant";
import { ownPost, ownBusiness, brandStyle } from "@/lib/studio/repository";
import { exportGraphics } from "@/lib/studio/graphics";
import { positiveId, studioFailure } from "@/lib/studio/errors";

export const runtime = "nodejs";
export const maxDuration = 60;
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(request); if (!auth.ok) return auth.response;
  try {
    const post = await ownPost(auth.context.workspaceId, positiveId((await params).id));
    const business = await ownBusiness(auth.context.workspaceId, post.businessId);
    const style = await brandStyle(auth.context.workspaceId, post.businessId);
    const result = await exportGraphics(auth.context.workspaceId, business.name, post.document, style, request.nextUrl.searchParams.get("bundle") === "1");
    return new NextResponse(new Uint8Array(result.bytes), { headers: { "Content-Type": result.mimeType, "Content-Disposition": `attachment; filename="${result.filename}"`, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
  } catch (error) { return studioFailure(error); }
}
