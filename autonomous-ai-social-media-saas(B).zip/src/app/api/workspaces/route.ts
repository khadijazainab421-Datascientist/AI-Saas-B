import type { NextRequest } from "next/server";
import { getWorkspacesForUser, createWorkspace } from "@/lib/auth-server";
import { requireUser } from "@/lib/tenant";
import { authBody, authError, authResponse } from "@/lib/auth-http";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const auth = await requireUser(request);
  if (!auth.ok) return auth.response;
  const memberships = await getWorkspacesForUser(auth.session.user.id);
  return authResponse(request, {
    activeWorkspaceId: auth.session.workspaceId,
    workspaces: memberships.map(({ workspace, role }) => ({ id: workspace.id, name: workspace.name, slug: workspace.slug, role })),
  });
}

export async function POST(request: NextRequest) {
  const auth = await requireUser(request);
  if (!auth.ok) return auth.response;
  const body = await authBody(request);
  const name = typeof body?.name === "string" ? body.name.trim() : "";
  if (!name || name.length > 120) return authError("Enter a workspace name of 1–120 characters.", 400, "INVALID_INPUT");
  try {
    const workspace = await createWorkspace(auth.session.user.id, name);
    return authResponse(request, { workspace }, undefined, 201);
  } catch {
    return authError("Workspace creation could not be completed. Please retry.", 503, "WORKSPACE_UNAVAILABLE");
  }
}
