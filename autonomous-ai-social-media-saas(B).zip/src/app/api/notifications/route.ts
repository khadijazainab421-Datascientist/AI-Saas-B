import { NextResponse, type NextRequest } from "next/server";
import { eq, and, desc, inArray } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { requireTenant } from "@/lib/tenant";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;
  const items = await db
    .select()
    .from(notifications)
    .where(eq(notifications.workspaceId, auth.context.workspaceId))
    .orderBy(desc(notifications.createdAt))
    .limit(50);
  return NextResponse.json({ notifications: items, unread: items.filter((item) => !item.read).length });
}

export async function POST(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;

  let body: Record<string, unknown> = {};
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  if (body.all === true) {
    await db
      .update(notifications)
      .set({ read: true })
      .where(eq(notifications.workspaceId, auth.context.workspaceId));
    return NextResponse.json({ ok: true });
  }

  const ids = Array.isArray(body.ids)
    ? body.ids.filter((id): id is number => typeof id === "number")
    : [];
  if (ids.length === 0) {
    return NextResponse.json({ error: "Provide ids or all: true" }, { status: 400 });
  }
  await db
    .update(notifications)
    .set({ read: true })
    .where(and(eq(notifications.workspaceId, auth.context.workspaceId), inArray(notifications.id, ids)));
  return NextResponse.json({ ok: true });
}
