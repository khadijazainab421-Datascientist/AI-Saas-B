import { NextResponse, type NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { workspaceSettings } from "@/db/schema";
import { requireTenant, getOrCreateSettings } from "@/lib/tenant";
import { getWorkspaceMembership } from "@/lib/auth-server";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;
  const settings = await getOrCreateSettings(auth.context.workspaceId);
  return NextResponse.json({ settings });
}

export async function POST(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;

  const membership = await getWorkspaceMembership(
    auth.context.workspaceId,
    auth.context.userId,
  );
  if (!membership || !["owner", "admin"].includes(membership.role)) {
    return NextResponse.json(
      { error: "Only workspace owners and admins can change provider authorization" },
      { status: 403 },
    );
  }

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const updates: Record<string, unknown> = { updatedAt: new Date() };
  if (typeof body.allowPaidProviders === "boolean") {
    updates.allowPaidProviders = body.allowPaidProviders;
  }
  if (typeof body.primaryProvider === "string" && ["gemini", "groq", "openai"].includes(body.primaryProvider)) {
    updates.primaryProvider = body.primaryProvider;
  }
  for (const key of ["dailyAiRequestLimit", "dailyResearchLimit"] as const) {
    if (typeof body[key] === "number" && Number.isInteger(body[key]) && (body[key] as number) >= 1 && (body[key] as number) <= 1000) {
      updates[key] = body[key];
    }
  }

  const settings = await getOrCreateSettings(auth.context.workspaceId);
  const [updated] = await db
    .update(workspaceSettings)
    .set(updates)
    .where(eq(workspaceSettings.id, settings.id))
    .returning();
  return NextResponse.json({ settings: updated });
}
