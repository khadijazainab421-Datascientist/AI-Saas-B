import { NextResponse, type NextRequest } from "next/server";
import { requireTenant } from "@/lib/tenant";
import { getResearch, runResearch } from "@/lib/research/engine";
import { getBusinessByIdAndWorkspace } from "@/lib/auth-server";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;
  const raw = request.nextUrl.searchParams.get("businessId");
  const businessId = raw ? Number(raw) : null;
  const data = await getResearch(auth.context.workspaceId, businessId);
  return NextResponse.json(data);
}

export async function POST(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const query = typeof body.query === "string" ? body.query.trim() : "";
  if (query.length < 3 || query.length > 400) {
    return NextResponse.json({ error: "Provide a research query between 3 and 400 characters" }, { status: 400 });
  }
  const businessId = typeof body.businessId === "number" ? body.businessId : null;
  if (businessId !== null && (!Number.isSafeInteger(businessId) || businessId < 1 ||
      !(await getBusinessByIdAndWorkspace(businessId, auth.context.workspaceId)))) {
    return NextResponse.json({ error: "Business not found in this workspace" }, { status: 404 });
  }
  const maxResults = typeof body.maxResults === "number" ? Math.min(Math.max(Math.floor(body.maxResults), 1), 10) : 5;

  const result = await runResearch({
    workspaceId: auth.context.workspaceId,
    userId: auth.context.userId,
    businessId,
    query,
    maxResults,
  });
  return NextResponse.json(result);
}
