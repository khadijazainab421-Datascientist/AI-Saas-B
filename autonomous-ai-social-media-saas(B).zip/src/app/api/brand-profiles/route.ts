import { NextResponse, type NextRequest } from "next/server";
import { eq, and } from "drizzle-orm";
import { db } from "@/db";
import { brandProfiles, businesses } from "@/db/schema";
import { requireTenant } from "@/lib/tenant";

export const runtime = "nodejs";

function stringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item): item is string => typeof item === "string")
    .map((item) => item.trim().slice(0, 300))
    .filter(Boolean)
    .slice(0, 30);
}

function optionalText(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim().slice(0, 4000) : null;
}

async function businessInWorkspace(businessId: number, workspaceId: number) {
  const [row] = await db
    .select({ id: businesses.id })
    .from(businesses)
    .where(and(eq(businesses.id, businessId), eq(businesses.workspaceId, workspaceId)))
    .limit(1);
  return Boolean(row);
}

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;
  const businessId = Number(request.nextUrl.searchParams.get("businessId"));
  if (!businessId) {
    return NextResponse.json({ error: "businessId is required" }, { status: 400 });
  }
  const [profile] = await db
    .select()
    .from(brandProfiles)
    .where(and(eq(brandProfiles.businessId, businessId), eq(brandProfiles.workspaceId, auth.context.workspaceId)))
    .limit(1);
  return NextResponse.json({ profile: profile ?? null });
}

export async function POST(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const businessId = typeof body.businessId === "number" ? body.businessId : Number(body.businessId);
  if (!businessId || !(await businessInWorkspace(businessId, auth.context.workspaceId))) {
    return NextResponse.json({ error: "Business not found in this workspace" }, { status: 404 });
  }

  const values = {
    workspaceId: auth.context.workspaceId,
    businessId,
    tone: optionalText(body.tone),
    voiceDescription: optionalText(body.voiceDescription),
    vocabulary: stringArray(body.vocabulary),
    audience: optionalText(body.audience),
    objectives: optionalText(body.objectives),
    claimsPolicy: optionalText(body.claimsPolicy),
    restrictedTopics: stringArray(body.restrictedTopics),
    styleExamples: stringArray(body.styleExamples),
    updatedAt: new Date(),
  };

  const [profile] = await db
    .insert(brandProfiles)
    .values(values)
    .onConflictDoUpdate({ target: brandProfiles.businessId, set: values })
    .returning();

  return NextResponse.json({ profile });
}
