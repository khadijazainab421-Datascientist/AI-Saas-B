import { NextResponse, type NextRequest } from "next/server";
import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { aiUsageEvents } from "@/db/schema";
import { requireTenant } from "@/lib/tenant";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;

  const events = await db
    .select()
    .from(aiUsageEvents)
    .where(eq(aiUsageEvents.workspaceId, auth.context.workspaceId))
    .orderBy(desc(aiUsageEvents.createdAt))
    .limit(100);

  const byProvider: Record<string, { requests: number; errors: number; inputTokens: number; outputTokens: number }> = {};
  for (const event of events) {
    const entry = byProvider[event.providerKey] ?? { requests: 0, errors: 0, inputTokens: 0, outputTokens: 0 };
    entry.requests += 1;
    if (event.status !== "success") entry.errors += 1;
    entry.inputTokens += event.inputTokens;
    entry.outputTokens += event.outputTokens;
    byProvider[event.providerKey] = entry;
  }

  return NextResponse.json({ events, byProvider, totalEvents: events.length });
}
