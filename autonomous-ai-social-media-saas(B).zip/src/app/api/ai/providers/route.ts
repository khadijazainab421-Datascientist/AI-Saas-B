import { NextResponse, type NextRequest } from "next/server";
import { getProviderStatuses, runHealthChecks } from "@/lib/ai/orchestrator";
import { getOrCreateSettings, requireTenant } from "@/lib/tenant";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;
  const [providers, settings] = await Promise.all([
    getProviderStatuses(),
    getOrCreateSettings(auth.context.workspaceId),
  ]);
  return NextResponse.json({
    providers,
    settings: {
      allowPaidProviders: settings.allowPaidProviders,
      primaryProvider: settings.primaryProvider,
      dailyAiRequestLimit: settings.dailyAiRequestLimit,
      dailyResearchLimit: settings.dailyResearchLimit,
    },
  });
}

export async function POST(request: NextRequest) {
  const auth = await requireTenant(request);
  if (!auth.ok) return auth.response;
  const results = await runHealthChecks();
  return NextResponse.json({ results, checkedAt: new Date().toISOString() });
}
