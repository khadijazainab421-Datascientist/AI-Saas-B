import type { Metadata } from "next";
import { headers } from "next/headers";
import { AuthForm } from "@/components/auth/auth-form";
import { standalonePreviewOrigin } from "@/lib/preview-origin";

export const metadata: Metadata = { title: "Sign in" };
export const dynamic = "force-dynamic";

export default async function LoginPage() {
  return <AuthForm mode="login" standaloneOrigin={standalonePreviewOrigin(await headers())} />;
}
