# Serein — Autonomous social media workspace

Next.js App Router / TypeScript / Tailwind / PostgreSQL via Drizzle.

Current implementation: Phases 1–3 plus the **Phase 4 Content Creation Studio core**. This is not a production-readiness declaration. See [known issues](docs/KNOWN-ISSUES.md), especially the user-reported hosted-preview login issue, which remains open.

## Run locally after exporting or cloning

1. Install Node.js 22 and have a reachable PostgreSQL database.
2. Install dependencies with `npm install` (or `npm ci` when the generated lockfile is included).
3. Configure a private `.env.local` file in the project root. Use `.env.example` for variable names, not real secrets. Set a valid `DATABASE_URL`; preserve an existing working connection instead of copying a placeholder over it.
4. For a **fresh development database**, apply the schema with `npx drizzle-kit push --config=drizzle.config.ts`. Back up and review changes before applying anything to an existing database. Production should use reviewed/versioned migrations rather than an unreviewed push.
5. Start development with `npm run dev` and open the app's own localhost URL.
6. Verify production compatibility with `npx next typegen`, `npm exec tsc -- --noEmit --pretty false`, and `npm run build`.

Authentication uses random, hashed, DB-backed sessions. `AUTH_SECRET` is not required by the current implementation. The platform sandbox has a preview-only temporary in-memory transport for blocked cookies; normal deployments use HttpOnly cookies by default. Its local tests passing did not resolve the user's actual hosted-browser report—test the first-party deployment before claiming that.

## Server-side environment variables

| Variable | Required for |
| --- | --- |
| `DATABASE_URL` | Users, workspaces, drafts, media and all persistence |
| `GEMINI_API_KEY` | Optional configured primary AI provider |
| `GROQ_API_KEY` | Optional primary/backup AI provider |
| `TAVILY_API_KEY` | Phase 3 sourced research |
| `UNSPLASH_ACCESS_KEY` | Optional Phase 4 stock search/linked-photo selection |
| `APP_PUBLIC_ORIGIN` | Optional non-secret first-party deployment origin override |

OpenAI and Brave are optional paid/metered candidates and must not be enabled without explicit workspace authorization. No image-generation provider has been selected; local branded graphic rendering is deterministic Sharp/SVG processing, not an AI image API.

Do not prefix secrets with `NEXT_PUBLIC_`, paste them into source/frontend files, commit them, or send them in chat. Place deployment secrets in the hosting provider's server-side environment settings. `.env.example` contains no real keys.

## GitHub is version control, not the complete runtime

- Connecting/pushing a repository does **not** run a PostgreSQL instance or configure secrets.
- This app needs Node-capable Next.js hosting plus PostgreSQL; it is not a static GitHub Pages export.
- Repository export does not include database rows. Existing users/workspaces remain only if the same persisted database is used or its data is deliberately migrated. A new empty database needs fresh registration or an approved migration.
- Sandbox URLs and local sandbox PostgreSQL are not permanent production infrastructure.
- Keep `.env*` (except `.env.example`), `.backups`, test artifacts, `node_modules` and `.next` private/out of shared exports. Git ignore does not sanitize an arbitrary ZIP.
- No commit/push was performed in this phase.

## Phase 4 features

- Tenant/business-scoped saved drafts, version conflicts and revision restoration.
- User-triggered AI ideas, captions/channel adaptations, carousel copy and video scripts through the existing provider fallback/task system.
- Strict structured-output validation, separate generated suggestions, explicit apply, preserved raw output history.
- Magic-byte checked private image upload/normalization and metadata-only lists; authenticated image serving supports the app's shared API transport.
- Brand-kit settings, real PNG exports and multi-slide ZIP bundles.
- Owner/admin approval, claim acknowledgement, UTC/IANA scheduling and a calendar reading actual saved plans.
- No live social publisher/worker; scheduled rows are editorial plans only.
- Unsplash live stock search pending its Access Key; hotlinking/credit/tracking structure prepared.
- Video scripts supported, movie rendering/transcoding not configured.

## Tests

- `npx tsx scripts/check-phase4-unit.ts` — local schemas, escaping, timezone/DST, output history and actual PNG/ZIP validation; no provider request.
- With the managed/local app running: `npx tsx scripts/check-phase4-flow.ts --run --browser` — isolated HTTP/Chromium workflow using temporary diagnostic accounts and cleanup.
- Adding `--live-ai` authorizes a real AI request using a temporary workspace configured with Groq primary and paid providers disabled. It consumes actual provider quota; do not run it accidentally or describe its result as free of all provider limits.

The normal browser runner needs Playwright Chromium and its Linux libraries (`npx playwright install --with-deps chromium`). It is testing tooling, not the product's video-processing feature.

## Documentation

- [Phase 4 report and media credential setup](docs/PHASE-4.md)
- [Current known issues](docs/KNOWN-ISSUES.md)
- [Phase 3 architecture](docs/PHASE-3.md)
- [Prior live provider observations](docs/PHASE-3-LIVE-TESTS.md)
- [Preview cookie follow-up](docs/OPTION-B-COOKIE-PERSISTENCE.md)

## Next gate

Phase 5 social OAuth/publishing is not implemented and will not start without explicit approval. Developer apps, account eligibility, API products, scopes, app review and real publishing tests must be disclosed and completed individually.
